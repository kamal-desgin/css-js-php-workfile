-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2020 at 08:12 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customers`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `BUSINESSNAME` varchar(255) NOT NULL,
  `CONTACT` varchar(15) NOT NULL,
  `CREATEDATE` date DEFAULT NULL,
  `CSTATUS` varchar(25) NOT NULL,
  `FOLLOWUP` date NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CID`, `BUSINESSNAME`, `CONTACT`, `CREATEDATE`, `CSTATUS`, `FOLLOWUP`) VALUES
(3, 'Lights and Hearts photography', '9552544552', '2019-03-14', 'Appointment', '2019-03-03'),
(4, 'Pe Aristi Engineering', '9552544552', '2019-03-14', 'Ignore', '2019-03-04'),
(5, 'Sree Thai sigichalayam', '9552544552', '2019-03-14', 'Call back', '2019-03-05'),
(6, 'BVT International Trust', '9552544552', '2019-03-14', 'Appointment', '2019-03-05'),
(7, 'GS Enterpris', '9552544552', '2019-03-14', 'Ignore', '2019-03-06'),
(8, 'Puvi Health Club', '9552544552', '2019-03-14', 'Call back', '2019-03-06'),
(9, 'Typstudio', '9552544552', '2019-03-14', 'Appointment', '2019-03-07'),
(10, 'Kuzhal', '9552544552', '2019-03-14', 'Ignore', '2019-03-07'),
(11, 'Go Indonesia', '9552544552', '2019-03-14', 'Call back', '2019-03-04'),
(12, 'I Office', '9552544552', '2019-03-14', 'Appointment', '2019-03-06'),
(13, 'Aabon Smit', '8885544422', '2019-03-14', 'Appointment', '2019-03-05'),
(14, 'amman', '5554466622', '2019-03-14', 'Call back', '2019-03-03'),
(21, 'kamal', '7418823014', '2019-03-28', 'Call back', '2019-03-28'),
(22, ' Anbu ', '9585667526', '2019-03-28', 'Call back', '2019-03-28');
