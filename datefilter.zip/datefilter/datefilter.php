<?php 
include "config.php";
?>
<!doctype html>
<html>
    <head>
        <title>jQuery Datepicker to filter records with PHP MySQL</title>

        <!-- CSS -->
        <link href='assets/js/datefilter/jquery-ui.min.css' rel='stylesheet' type='text/css'>
        <!-- Script -->
       <!-- <script src='assets/js/datefilter/jquery-3.3.1.js' type='text/javascript'></script>--->
        <script src='assets/js/datefilter/jquery-ui.min.js' type='text/javascript'></script>
        <script type='text/javascript'>
        $(document).ready(function(){
            $('.dateFilter').datepicker({
                dateFormat: "yy-mm-dd"
            });
        });
        </script>
    </head>
    <body >
        
        <!-- Search filter -->
        <form method='post' action=''>
            Start Date <input type='text' class='dateFilter' name='fromDate' 
				value='<?php if(isset($_POST['fromDate'])) echo $_POST['fromDate']; ?>'>
            
            End Date <input type='text' class='dateFilter' name='endDate' 
				value='<?php if(isset($_POST['endDate'])) echo $_POST['endDate']; ?>'>

            <input type='submit' name='but_search' value='Search'>
        </form>

        <!-- Employees List -->
        <div  >
            
            <table border='1' width='100%' style='border-collapse: collapse;margin-top: 20px;'>
                <tr>
                    <th>Name</th>
                    <th>Date of Join</th>
                    <th>Gender</th>
                    <th>Email</th>
                </tr>

                <?php
                $emp_query = "SELECT * FROM customers WHERE 1 ";

                // Date filter
                if(isset($_POST['but_search'])){
                    $fromDate = $_POST['fromDate'];
                    $endDate = $_POST['endDate'];

                    if(!empty($fromDate) && !empty($endDate)){
                        $emp_query .= " and FOLLOWUP between '".$fromDate."' and '".$endDate."' ";
                    }
                }

                // Sort
                $emp_query .= " ORDER BY FOLLOWUP DESC";
                $employeesRecords = mysqli_query($con,$emp_query);

                // Check records found or not
                if(mysqli_num_rows($employeesRecords) > 0){
                    while($empRecord = mysqli_fetch_assoc($employeesRecords)){
                        $CID = $empRecord['CID'];
                        $BUSINESSNAME = $empRecord['BUSINESSNAME'];
                        $CONTACT = $empRecord['CONTACT'];
                        $CSTATUS = $empRecord['CSTATUS'];
                        $FOLLOWUP = $empRecord['FOLLOWUP'];

                        echo "<tr>";
                        echo "<td>". $BUSINESSNAME ."</td>";
                        echo "<td>". $CONTACT ."</td>";
                        echo "<td>". $CSTATUS ."</td>";
                        echo "<td>". $FOLLOWUP ."</td>";
                        echo "</tr>";
                    }
                }
				
				
                ?>
            </table>
            
        </div>
    </body>
</html>