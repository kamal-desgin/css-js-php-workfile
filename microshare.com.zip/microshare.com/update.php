<?php	
	include "config.php";
	$sql = "update user set Businessname='{$_POST["addname"]}',Contactno='{$_POST["addcontact"]}',Status='{$_POST["addstatus"]}',Date='{$_POST["adddate"]}' where CID=".$_POST["id"];
	$con->query($sql);
?>
