-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2019 at 02:22 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customer`
--

-- --------------------------------------------------------

--
-- Table structure for table `lists`
--

CREATE TABLE IF NOT EXISTS `lists` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(256) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Startdate` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `lists`
--

INSERT INTO `lists` (`Id`, `Name`, `Phone`, `Startdate`, `Status`, `Date`) VALUES
(1, ' Kamal ', '9555433322', '2019-03-04', 'Call back', '2019-03-05'),
(3, 'Akash Fashions', '8887755566', '2019-03-04', 'Call back', '2019-03-29');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `Businessname` varchar(256) NOT NULL,
  `Contactno` varchar(50) NOT NULL,
  `Followup` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`CID`, `Businessname`, `Contactno`, `Followup`, `Status`, `Date`) VALUES
(1, '  Youth Child Trust', '  9094090940  ', '2019-03-04', 'Call back', '2019-03-05'),
(2, 'Akash Fashions', ' 9094025023 ', '2019-03-05', 'appointment', '2019-03-12'),
(3, 'Siva Tours and Travels', '   9552544552 ', '2019-03-04', 'appointment', '2019-03-05');
