// side menu
$(document).ready(function () {	
	$('#sidebarCollapse').on('click', function () {
		$('#sidebar').toggleClass('active');
		$(this).toggleClass('active');
	});
	
    // alert("Add customer data");
	$("#output").load("view.php"); 
	
	$('#add').click(function(){   
		$('#adddata')[0].reset();  
	});
	//Insert code
	$('#adddata').on("submit", function(event){  
		event.preventDefault();  
		if($('#addname').val() == "")  
		{  
			alert("Business Name is required");  
		}  
		else if($('#addcontact').val() == '')  
		{  
			alert("Contact no is required");  
		}  
		else if($('#addstatus').val() == '')  
		{  
			alert("Status is required");  
		}  
		else if($('#addfollow').val() == '')  
		{  
			alert("Followup Date is required");  
		}  
		else  
		{  
			var id=$("#id").val();
			if(id==0) 
			{
				$.ajax({  
					url:"insert.php",  
					type:"POST",  
					data:$('#adddata').serialize(),  
					 beforeSend:function(){  
						$('#addsave').val("save success");  
					},   
					success:function(data){  
						$('#adddata')[0].reset();  
						$('#addnewdata').modal('hide');
						$("#output").load("view.php");
						$("<tr></tr>").html(d).appendTo(".table");
						$("#id").val(0);  //data id reset used							  
					}  
				});
			}
			else
			{
				// alert("Confirm to updateinsert This");
				$.ajax({
					url: "updateinsert.php",
					type: "post",
					data: $("#adddata").serialize(),  //all data one by one store
					 beforeSend:function(){  
						$('#addsave').val("updated success");  
					}, 
					success:function(data)
					{
						$("#output").load("view.php");
						$("#adddata")[0].reset();  //form reset data used
						$("#id").val(0);  //data id reset used
						$('#addnewdata').modal('hide');
					}
				});
			}
		}  
	});
	
	//delete code
	$(document).on("click",".del", function() {
		var del=$(this);
		var id=$(this).attr("data-id");
		$.ajax({
			url: "delete.php",
			type: "post",
			data: {id:id},
			beforeSend:function(){  
				$('#del').val("delete"); 
				var result = confirm("Are you sure you want to delete this user?");
				if(!result) {
					e.preventDefault();
				}
			},
			success:function(data)
			{
				del.closest("tr").hide();				
			}
		});
	});
	
	//update code
	$(document).on("click",".edit", function() {
		var row=$(this);
		var id=$(this).attr("data-id");
		$("#id").val(id);
		
		// CID  td:eq(0) not calculated table
		
		var addname=row.closest("tr").find("td:eq(1)").text();
		$("#addname").val(addname);
		
		var addcontact=row.closest("tr").find("td:eq(2)").text();
		$("#addcontact").val(addcontact);
		
		var addstatus=row.closest("tr").find("td:eq(4)").text();
	    $('#addstatus').find('option:selected').val();
		
		var addfollow=row.closest("tr").find("td:eq(3)").text();
		$("#addfollow").val(addfollow);
		
		$("#addnewdata").modal("show");	 
		
		
	});	
	
    //View code
	$(document).on("click", ".view", function(){ 
		var row=$(this);
		var id=$(this).attr("data-id");  
		$.ajax({  
			url:"select.php",  
			type:"POST",  
			data:{id:id},  
			success:function(data){  
				$('#view_data').html(data);  
				$('#viewpopup').modal('show');  
			}  
		});  
	});
	
	
});

