<?php
	include "config.php";
?> 
<?php
	$timestamp = "2019-03-25 00:37:15";
	$start_date = date($timestamp);
	$expires = strtotime('+7 days', strtotime($timestamp));
	//$expires = date($expires);
	$date_diff=($expires-strtotime($timestamp)) / 86400;
	echo "Start: ".$timestamp."<br>";
	echo "Expire: ".date('Y-m-d H:i:s', $expires)."<br>";
	echo round($date_diff, 0)." days left";
?>
<br> <br>
<?php 
 $gettime = "2018-04-20";
$start_date = date($gettime);
// $exdate = strtotime('+3 months', strtotime($gettime));
$oneyear = strtotime('+1 years', strtotime($gettime));
// $now= mktime();

// $date_diff=($oneyear-$now) / 86400;

echo "Start: ".$gettime."<br>";
// echo "3 Month Expire: ".date('Y-m-d', $exdate)."<br>";
echo "one year Expire: ".date('Y-m-d', $oneyear)."<br>";
// echo round($date_diff, 0)." days left"; 
?>

<br><br>

<?php

$date_time = '2019-04-24 20:13:30';
echo date('Y-m-d', strtotime($date_time));

?>

<div class="table-responsive">
	<table id="example" class="display tabel table-hover table-bordered"  cellspacing="0" width="100%" >
		<thead>
			<tr>
				<th>Businessname</th>
				<th>Contact No</th>
				<th>Live Date</th>
				<th>Expiray Date</th>				
				<th>Status</th>															
				<th>oneyear</th>															
				<th>SSL Certificate</th>															
			</tr>
		</thead>
		 <tbody>
			<?php
				
			// $fetchqry = "SELECT * FROM hosting where CURDATE() > Hexpiry";    //Expired Date
			//$fetchqry = "SELECT * FROM hosting where CURDATE() <= Hexpiry";    //active Date
			//$fetchqry = "SELECT * FROM hosting where Hexpiry <= CURDATE()";    //Expired date
			 //$fetchqry = "SELECT * FROM hosting where Hexpiry <= CURDATE()";    //active date
			//$fetchqry = "SELECT * FROM hosting WHERE   Hdate <= DATE(NOW()) ";  // active and expired date
			$fetchqry = "SELECT * FROM hosting";  // active and expired date
			
			
			$result=mysqli_query($con,$fetchqry);
			$num=mysqli_num_rows($result);
			while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
				{ 
				?>
				   <tr>
						<td><?php echo $row['Hbusinessname'];?></td>
						<td><?php echo $row['Hcontact'];?></td>
						<td><?php echo $date1 =  $row['Hdate'];?></td>
						<td><?php echo $date2 = $row['Hexpiry'];?></td>
						
						<td><?php
								if(strtotime(date("Y/m/d")) < strtotime($date2))
									echo "Active"; 
								else 
									{
									 echo "Expired";
									 } 
							?></td>
						<td><?php
								$enddate = strtotime('+1 years', strtotime($date1));
								$now= mktime();
								$date_diff=($enddate-$now) / 86400;
									echo round($date_diff, 0)." days left";
						?></td>
						<td><?php 
								$enddate = strtotime('+90 days', strtotime($date1));
								echo "Renuwal last ".date('Y-m-d', $enddate)."<br>";
						?></td>
						
						<td> <?php 
						
						$expdate   = date('Y/m/d', strtotime('+3 years'));
						
						$one = strtotime('+1 years', strtotime($date1));
							echo "".date('Y-m-d', $one)."";
							?> </td>
						
				   </tr>	
				   
				 
				   
				  <?php 
				  } 
				  ?>
		</tbody>
	</table>
</div>


<!-- 
	https://www.youtube.com/watch?v=K9e12cgTzBM
	
	https://technopoints.co.in/expiration-date-in-php/
	
	
	--->