-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2020 at 08:18 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customers`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `BUSINESSNAME` varchar(255) NOT NULL,
  `CONTACT` varchar(15) NOT NULL,
  `CREATEDATE` date DEFAULT NULL,
  `CSTATUS` varchar(25) NOT NULL,
  `FOLLOWUP` date NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CID`, `BUSINESSNAME`, `CONTACT`, `CREATEDATE`, `CSTATUS`, `FOLLOWUP`) VALUES
(3, 'Lights and Hearts photography', '9552544552', '2019-03-14', 'Appointment', '2019-03-03'),
(4, 'Pe Aristi Engineering', '9552544552', '2019-03-14', 'Ignore', '2019-03-04'),
(5, 'Sree Thai sigichalayam', '9552544552', '2019-03-14', 'Call back', '2019-03-05'),
(6, 'BVT International Trust', '9552544552', '2019-03-14', 'Appointment', '2019-03-05'),
(7, 'GS Enterpris', '9552544552', '2019-03-14', 'Ignore', '2019-03-06'),
(8, 'Puvi Health Club', '9552544552', '2019-03-14', 'Call back', '2019-03-06'),
(9, 'Typstudio', '9552544552', '2019-03-14', 'Appointment', '2019-03-07'),
(10, 'Kuzhal', '9552544552', '2019-03-14', 'Ignore', '2019-03-07'),
(11, 'Go Indonesia', '9552544552', '2019-03-14', 'Call back', '2019-03-04'),
(12, 'I Office', '9552544552', '2019-03-14', 'Appointment', '2019-03-06'),
(13, 'Aabon Smit', '8885544422', '2019-03-14', 'Appointment', '2019-03-05'),
(14, 'amman', '5554466622', '2019-03-14', 'Call back', '2019-03-03'),
(21, 'kamal', '7418823014', '2019-03-28', 'Call back', '2019-03-28'),
(22, ' Anbu ', '9585667526', '2019-03-28', 'Call back', '2019-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE IF NOT EXISTS `emp` (
  `EMPNO` int(11) NOT NULL AUTO_INCREMENT,
  `EMPNAME` varchar(25) NOT NULL,
  `SAL` int(10) NOT NULL,
  PRIMARY KEY (`EMPNO`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`EMPNO`, `EMPNAME`, `SAL`) VALUES
(1, 'kamal', 12000),
(2, 'arun', 12000);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `address`, `gender`, `designation`, `age`) VALUES
(1, 'John Smith', '656 Edsel Road\r\nSherman Oaks, CA 91403', 'Male', 'Manager', 40),
(5, 'Clara Berry', '63 Woodridge Lane\r\nMemphis, TN 38138', 'Male', 'Programmer', 22),
(6, 'Barbra K. Hurley', '1241 Canis Heights Drive\r\nLos Angeles, CA 90017', 'Female', 'Service technician', 26),
(7, 'Antonio J. Forbes', '403 Snyder Avenue\r\nCharlotte, NC 28208', 'Male', 'Falling', 32),
(8, 'Charles D. Horst', '1636 Walnut Hill Drive\r\nCincinnati, OH 45202', 'Male', 'Financial investigator', 29),
(9, 'Beau L. Clayton', '3588 Karen Lane\r\nLouisville, KY 40223', 'Male', 'Extractive metallurgical engin', 33),
(10, 'Ramona W. Burns', '2170 Ocala Street\r\nOrlando, FL 32801', 'Female', 'Electronic typesetting machine operator', 27),
(11, 'Jennifer A. Morrison', '2135 Lakeland Terrace\r\nPlymouth, MI 48170', 'Female', 'Rigging chaser', 29),
(12, 'Susan Juarez', '3177 Horseshoe Lane\r\nNorristown, PA 19403', 'Male', 'Control and valve installe', 52),
(13, 'Ellan D. Downie', '384 Flynn Street\r\nStrongsville, OH 44136', 'Female', 'Education and training manager', 26),
(14, 'Larry T. Williamson', '1424 Andell Road\r\nBrentwood, TN 37027', 'Male', 'Teaching assistant', 30),
(15, 'Lauren M. Reynolds', '4798 Echo Lane\r\nKentwood, MI 49512', 'Female', 'Internet developer', 22),
(16, 'Joseph L. Judge', '3717 Junkins Avenue\r\nMoultrie, GA 31768', 'Male', 'Refrigeration mechanic', 35),
(17, 'Eric C. Lavelle', '1120 Whitetail Lane\r\nDallas, TX 75207', 'Male', 'Model', 21),
(18, 'Cheryl T. Smithers', '1203 Abia Martin Drive\r\nCommack, NY 11725', 'Female', 'Personal banker', 23),
(19, 'Tonia Diaz', '4724 Rocky Road\r\nPhiladelphia, PA 19107', 'Female', 'Facilitator', 29),
(20, 'Stephanie P. Lederman', '2117 Larry Street\r\nWaukesha, WI 53186', 'Female', 'Mental health aide', 27),
(21, 'Edward F. Sanchez', '2313 Elliott Street\r\nManchester, NH 03101', 'Male', 'Marine oilerp', 28),
(25, 'Peter Parker', '403 Snyder Avenue Charlotte, NC 28208', 'Male', 'Programmer', 28),
(27, 'John Smith', '384 Flynn Street Strongsville, OH 44136', 'Male', 'Web Developer', 25),
(28, 'Mark Boucher', '256, Olive Street, NY', 'Male', 'Techbical Assistance', 23);

-- --------------------------------------------------------

--
-- Table structure for table `expiration`
--

CREATE TABLE IF NOT EXISTS `expiration` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `registerdate` text NOT NULL,
  `expirationdate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expiration`
--

INSERT INTO `expiration` (`firstname`, `lastname`, `mail`, `registerdate`, `expirationdate`) VALUES
('Enrique ', 'Iglesias', 'enrique@iglesias.com', '2018/07/26', '2019/07/26'),
('John', 'Cena', 'john@cena.com', '2018/07/26', '2020/07/26'),
('Justin', 'Bieber', 'justin@bieber.com', '2018/07/26', '2017/07/26'),
('Kamal', 'k', 'kamal.microshare@gmail.com', '2019/03/21', '2022/03/21');

-- --------------------------------------------------------

--
-- Table structure for table `hosting`
--

CREATE TABLE IF NOT EXISTS `hosting` (
  `Hid` int(11) NOT NULL AUTO_INCREMENT,
  `Hbusinessname` varchar(255) NOT NULL,
  `Hcontact` varchar(15) NOT NULL,
  `Hdate` date NOT NULL,
  `Hexpiry` date NOT NULL,
  `Repayment` int(11) NOT NULL,
  PRIMARY KEY (`Hid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `hosting`
--

INSERT INTO `hosting` (`Hid`, `Hbusinessname`, `Hcontact`, `Hdate`, `Hexpiry`, `Repayment`) VALUES
(1, 'BVT India', '2147483647', '2018-03-22', '2019-03-22', 2800),
(2, 'GS Enterpris', '2147483647', '2018-04-20', '2019-04-20', 2800),
(3, 'Sree Thai sigichalayam', '2147483647', '2018-03-15', '2019-03-15', 2800),
(4, 'microshare', '2147483647', '2019-03-29', '0000-00-00', 2600),
(5, 'dayal sports', '9885556661', '2019-03-30', '0000-00-00', 2600),
(9, 'arun', '8887799955', '2019-03-30', '2020-03-30', 2600),
(10, 'batthu', '5556664455', '2019-03-30', '2020-03-30', 2600),
(11, 'sathish', '9688556675', '2019-04-01', '2020-04-01', 2600),
(12, 'dayalan', '5556664455', '2019-05-30', '1970-01-01', 2600),
(13, 'dayal sports', '8887799955', '2019-03-16', '1970-01-01', 2600),
(14, 'arun', '8887799955', '2019-04-04', '1970-01-01', 2600),
(15, 'microshare', '5556664455', '2019-06-07', '2020-06-07', 2600),
(16, 'sathishkumar', '74888556688', '2019-03-29', '2020-03-29', 2900),
(17, '', '', '0000-00-00', '2020-04-07', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lists`
--

CREATE TABLE IF NOT EXISTS `lists` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(256) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Startdate` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `lists`
--

INSERT INTO `lists` (`Id`, `Name`, `Phone`, `Startdate`, `Status`, `Date`) VALUES
(1, ' Kamal ', '9555433322', '2019-03-04', 'Call back', '2019-03-05'),
(3, 'Akash Fashions', '8887755566', '2019-03-04', 'Call back', '2019-03-29');

-- --------------------------------------------------------

--
-- Table structure for table `payment_complete`
--

CREATE TABLE IF NOT EXISTS `payment_complete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `number` varchar(30) NOT NULL,
  `bank` varchar(250) NOT NULL,
  `branch` varchar(250) NOT NULL,
  `payment` date NOT NULL,
  `modeofpayment` varchar(25) NOT NULL,
  `attachment` varchar(250) DEFAULT NULL,
  `transid` varchar(500) DEFAULT NULL,
  `amtremit` varchar(500) DEFAULT NULL,
  `payin` varchar(250) DEFAULT NULL,
  `formnumber` varchar(250) DEFAULT NULL,
  `balpayment` varchar(1500) DEFAULT NULL,
  `baldate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `payment_complete`
--

INSERT INTO `payment_complete` (`id`, `user_name`, `email`, `number`, `bank`, `branch`, `payment`, `modeofpayment`, `attachment`, `transid`, `amtremit`, `payin`, `formnumber`, `balpayment`, `baldate`) VALUES
(6, 'sangeetha', 'sangeethavajjiravel@gmail.com', '7358100311', 'indian', 'perambur', '2019-04-11', 'NETBANKING', '', '548', '522', 'PART', '5584122', '46255', '2019-04-10'),
(11, 'kamal', 'support@microshare.in', '07418823014', 'Axis', 'Chennai', '2019-04-17', 'NETBANKING', 'http://mulliganconcept.in/download.php?file=slider-6.jpg', '02528522', '2500', 'PART', '190001', '250', '2019-04-17'),
(10, 'kamal', 'kamal.microshare@gmail.com', '7418823014', 'Axis', 'chennai', '2019-04-17', 'NETBANKING', 'http://mulliganconcept.in/download.php?file=slider-6.jpg', '0005', '5000', 'PART', '2500', '5000', '2019-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=187 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `address`, `gender`, `designation`, `age`, `image`) VALUES
(1, 'Bruce Tom', '656 Edsel Road\r\nSherman Oaks, CA 91403', 'Male', 'Driver', 36, '1.jpg'),
(5, 'Clara Gilliam', '63 Woodridge Lane\r\nMemphis, TN 38138', 'Female', 'Programmer', 24, '2.jpg'),
(6, 'Barbra K. Hurley', '1241 Canis Heights Drive\r\nLos Angeles, CA 90017', 'Female', 'Service technician', 26, '3.jpg'),
(7, 'Antonio J. Forbes', '403 Snyder Avenue\r\nCharlotte, NC 28208', 'Male', 'Faller', 32, '4.jpg'),
(8, 'Charles D. Horst', '1636 Walnut Hill Drive\r\nCincinnati, OH 45202', 'Male', 'Financial investigator', 29, '5.jpg'),
(175, 'Ronald D. Colella', '1571 Bingamon Branch Road, Barrington, IL 60010', 'Male', 'Top executive', 32, '6.jpg'),
(174, 'Martha B. Tomlinson', '4005 Bird Spring Lane, Houston, TX 77002', 'Female', 'Systems programmer', 38, '7.jpg'),
(161, 'Glenda J. Stewart', '3482 Pursglove Court, Rossburg, OH 45362', 'Female', 'Cost consultant', 28, '8.jpg'),
(162, 'Jarrod D. Jones', '3827 Bingamon Road, Garfield Heights, OH 44125', 'Male', 'Manpower development advisor', 64, '9.jpg'),
(163, 'William C. Wright', '2653 Pyramid Valley Road, Cedar Rapids, IA 52404', 'Male', 'Political geographer', 33, '10.jpg'),
(178, 'Sara K. Ebert', '1197 Nelm Street\r\nMc Lean, VA 22102', 'Female', 'Billing machine operator', 50, ''),
(177, 'Patricia L. Scott', '1584 Dennison Street\r\nModesto, CA 95354', 'Female', 'Urban and regional planner', 54, ''),
(179, 'James K. Ridgway', '3462 Jody Road\r\nWayne, PA 19088', 'Female', 'Recreation leader', 41, ''),
(180, 'Stephen A. Crook', '448 Deercove Drive\r\nDallas, TX 75201', 'Male', 'Optical goods worker', 36, ''),
(181, 'Kimberly J. Ellis', '4905 Holt Street\r\nFort Lauderdale, FL 33301', 'Male', 'Dressing room attendant', 24, ''),
(182, 'Elizabeth N. Bradley', '1399 Randall Drive\r\nHonolulu, HI 96819', 'Female', ' Software quality assurance analyst', 25, ''),
(183, 'Steve John', '108, Vile Parle, CL', 'Male', 'Software Engineer', 29, ''),
(184, 'Marks Johnson', '021, Big street, NY', 'Male', 'Head of IT', 41, ''),
(185, 'Mak Pub', '1462 Juniper Drive\r\nBreckenridge, MI 48612', 'Male', 'Mental health counselor', 40, ''),
(186, 'Louis C. Charmis', '1462 Juniper Drive\r\nBreckenridge, MI 48612', 'Male', 'Mental health counselor', 40, '');

-- --------------------------------------------------------

--
-- Table structure for table `updatecustomers`
--

CREATE TABLE IF NOT EXISTS `updatecustomers` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `CID` int(11) NOT NULL,
  `BUSINESSNAME` varchar(255) NOT NULL,
  `CONTACT` varchar(15) NOT NULL,
  `CSTATUS` varchar(25) NOT NULL,
  `FOLLOWUP` date NOT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `updatecustomers`
--

INSERT INTO `updatecustomers` (`UID`, `CID`, `BUSINESSNAME`, `CONTACT`, `CSTATUS`, `FOLLOWUP`) VALUES
(1, 1, ' Siva Tours and Travels ', ' 9552544552 ', 'Appointment', '2019-04-30'),
(2, 1, ' Siva Tours and Travels ', ' 9552544552 ', 'Call back', '0000-00-00'),
(3, 1, ' Siva Tours and Travels ', ' 9552544552 ', 'Ignore', '2019-03-28'),
(4, 1, ' Siva Tours and Travels ', ' 9552544552 ', 'Ignore', '2019-03-23'),
(5, 15, ' Equinox Bahari Utama ', ' 9994445522 ', 'Ignore', '2019-03-16'),
(6, 57, ' Anbu ', ' 9585667526 ', 'Appointment', '2019-03-31'),
(7, 57, ' Anbu ', ' 9585667526 ', 'Ignore', '2019-04-01'),
(8, 58, ' central park it city ', ' 7894561232 ', 'Ignore', '2019-03-31'),
(9, 58, ' central park it city ', ' 7894561232 ', '', '2019-03-28'),
(10, 60, ' suganya ', ' 7418823014 ', 'Appointment', '2019-03-31'),
(11, 3, ' Lights and Hearts photography ', ' 9552544552 ', 'Call back', '2019-03-29'),
(12, 3, ' Lights and Hearts photography ', ' 9552544552 ', 'Appointment', '2019-03-28'),
(13, 6, ' BVT International Trust ', ' 9552544552 ', 'Appointment', '2019-03-30'),
(14, 7, ' GS Enterpris ', ' 9552544552 ', 'Call back', '2019-04-26'),
(15, 22, '  Anbarasu', ' 9585667526 ', 'Call back', '2019-04-10'),
(16, 4, ' Pe Aristi Engineering ', ' 9552544552 ', '', '0000-00-00'),
(17, 3, ' Lights &Hearts photography ', ' 9552544552 ', '', '0000-00-00'),
(18, 3, ' Lights & Hearts photography ', ' 9552544552 ', 'Call back', '2019-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `Businessname` varchar(256) NOT NULL,
  `Contactno` varchar(50) NOT NULL,
  `Followup` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`CID`, `Businessname`, `Contactno`, `Followup`, `Status`, `Date`) VALUES
(1, '', '', '2019-03-04', '', '0000-00-00'),
(2, 'Akash Fashions', ' 9094025023 ', '2019-03-05', 'appointment', '2019-03-12'),
(3, 'Siva Tours and Travels', '   9552544552 ', '2019-03-04', 'appointment', '2019-03-05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'kamal', 'smkamal.sm@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(9, 'kamal', 'kamal.microshare@gmail.com', '1233');
