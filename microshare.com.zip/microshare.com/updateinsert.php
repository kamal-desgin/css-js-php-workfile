<?php
	// print_r($_POST);
	include "config.php";
	
	    $Cid=$_POST["Cid"];
	    $addname=$_POST["addname"];
		$addcontact=$_POST["addcontact"];
		$addstatus=$_POST["addstatus"];
		$addfollow=$_POST["addfollow"];
	

		$sql="INSERT INTO updatecustomers (CID,BUSINESSNAME,CONTACT,CSTATUS,FOLLOWUP) values('{$Cid}','{$addname}','{$addcontact}','{$addstatus}','{$addfollow}')";
		$con->query($sql);
		
		$id=$con->insert_id;  //last insert data id to delete
		
		// appendTo function call		
		echo "<td>{$Cid}</td>";
		echo "<td>{$addname}</td>";
		echo "<td>{$addcontact}</td>";
		echo "<td>{$addstatus}</td>";
		echo "<td>{$addfollow}</td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
		
		/* if($con->query($sql))
			{
				echo "Data saved";
			} */
		
?>