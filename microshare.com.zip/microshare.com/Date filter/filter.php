<?php
	include "../config.php";
?> 
 <div class="table-responsive">
	<table id="example" class="display tabel table-hover table-bordered"  cellspacing="0" width="100%" >
		<thead>
			<tr>
				<th>S.no</th>
				<th>Business Name</th>
				<th>Contact No</th>
				<th>Status </th>
				<th>Followup </th>
			</tr>
		</thead>
		<tbody>
			<?php
			 if(isset($_POST["from_date"], $_POST["to_date"]))  
			  {
				
				//$sql="select * from customers ORDER BY CID DESC LIMIT 0,5";	
				 $sql = "SELECT * FROM customers WHERE FOLLOWUP BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'";  
				 $res=$con->query($sql);
				
				if(mysqli_num_rows($res) > 0)  
				  {  
					   while($row = mysqli_fetch_array($res))  
					   {  
						echo "<tr>";
							echo "<td> {$row["CID"]} </td>";
							echo "<td> {$row["BUSINESSNAME"]} </td>";
							echo "<td> {$row["CONTACT"]} </td>";
							echo "<td> {$row["CSTATUS"]} </td>";
							echo "<td> {$row["FOLLOWUP"]} </td>";							
						echo "</tr>";
					   }  
				  }  
			 }
			?>
		</tbody>
		  
	</table>
</div>