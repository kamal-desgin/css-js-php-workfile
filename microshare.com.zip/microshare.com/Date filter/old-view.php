<?php
	include "config.php";
?> 
<script>  
	$(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val();  
                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"filter.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date},  
                          success:function(data)  
                          {  
                               $('#example').html(data);  
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });  
      });  
 </script>

 
<script>
// datatable add
	$(document).ready(function() {
		var t = $('#example').DataTable();
		var counter = 1;

		$('#addRow').on( 'click', function () {
		t.row.add( [
		counter +'.1',
		counter +'.2',
		counter +'.3',
		counter +'.4',
		counter +'.5'
		] ).draw( false );

		counter++;
		} );

		// Automatically add a first row of data
		$('#addRow').click();
	});
</script>


<!-- Search filter -->

<div class="row">
	<div class="col-md-3">  
		 <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
		 </div>  
	<div class="col-md-3">  
		 <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
	</div>  
	<div class="col-md-5">  
		 <input type="button" name="filter" id="filter" value="Filter" class="btn btn-info" />  
	</div>  
</div> <br>



<div class="table-responsive">
	<table id="example" class="display tabel table-hover table-bordered"  cellspacing="0" width="100%" >
		<thead>
			<tr>
				<th>S.no</th>
				<th>Business Name</th>
				<th>Contact No</th>
				<th>Status </th>
				<th>Followup </th>
				<th>view </th>
				<th>Edit </th>
				<th>delete </th>											
			</tr>
		</thead>
		<tbody>
			<?php
				
				$sql="select * from customers ORDER BY CID DESC LIMIT 0,5";	
				$res=$con->query($sql);
				if($res->num_rows > 0){
					$i=0;
					while($row=$res->fetch_assoc()){
						$i++;  //use id now auto
						echo "<tr>";
						echo "<td> {$i} </td>";
						echo "<td> {$row["BUSINESSNAME"]} </td>";
						echo "<td> {$row["CONTACT"]} </td>";
						echo "<td> {$row["CSTATUS"]} </td>";
						echo "<td> {$row["FOLLOWUP"]} </td>";
						echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button></td>";
						echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
						echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
						echo "</tr>";
					}
				}
			?>
		</tbody>
		  
	</table>
</div>

