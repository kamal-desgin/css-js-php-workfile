<?php
	include "header.php";
?>
<section class="bg-white">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
					<i class="fa fa-users fa-big" aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p> Customers</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						
							<i class="fa fa-tasks fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p>  Hosting</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-globe fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p>Domain</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-pencil-square-o fa-big" aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p>G-suite</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-list-alt fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p> SSL Certificate</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-file-text-o fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p> Website Status</p>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-user-circle fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p> Notification</p>
					</div>
				</div>
			</div>					
			<div class="col-md-3">
				<div class="header_top item">
					<div class="icon">
						<i class="fa fa-folder-open fa-big"  aria-hidden="true"></i>
					</div>	
					<div class="info">
						<h2> 20 </h2>
						<p> Total</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="line"></div>


<div class="line"></div>

<?php
	include "footer.php";
?>

