<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		
        <title>Customer Contact Details</title>
		
		<!-- Bootstrap CSS CDN -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
		<!-- datatable-->
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">		
		 <!-- datefilter -->
        <link href='assets/js/datefilter/jquery-ui.min.css' rel='stylesheet' type='text/css'>
        
	</head>
  <body>
		
        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3><i class="fa fa-users"></i> Costromer</h3>
				</div>
				
                <ul class="list-unstyled components">
                    <p>Customer Details</p>
                    <li class="active"><a href="index.php">Home</a></li>
					
                    <li><a href="business.php">Customers</a></li>
                    <li><a href="hosting.php">Hosting</a></li>
                    <li><a href="">Domain</a></li>
                    <li><a href="">G-suite</a></li>
                    <li><a href="">SSL Certificate</a></li>
                    <li><a href="">Website Status</a></li>
					<!--<li> <a href="#pageSubmenu" data-toggle="collapse">Pages</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li><a href="#">Page 1</a></li>
                            <li><a href="#">Page 2</a></li>
                            <li><a href="#">Page 3</a></li>
						</ul>
					</li> -->
                   
				</ul>
			</nav>
			
            <!-- Page Content Holder -->
            <div id="content">				
                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
							</button>
							
							<button class="hidden-lg hidden-sm hidden-md btn btn-dark pull-right d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
								<i class="fa fa-user-circle"></i>
							</button>	
						</div>
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#">Register</a></li>
                                <li><a href="#">Login</a></li>
                                <li><a href="#">logout</a></li>
							</ul>
						</div>
					</div>
				</nav>