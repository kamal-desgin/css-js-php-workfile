<?php
	include "config.php";
?> 
<script>  
	//Date Filter
	$(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val();  
                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"view.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date},  
                          success:function(data)  
                          {  
							$('#example').html(data);
							$("<tr></tr>").html(d).appendTo(".table");
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });  
      });  
 </script>
 <script>
	// datatable add
		$(document).ready(function() {
			var t = $('#example').DataTable();
			var counter = 1;

			$('#addRow').on( 'click', function () {
			t.row.add( [
			counter +'.1',
			counter +'.2',
			counter +'.3',
			counter +'.4',
			counter +'.5'
			] ).draw( false );

			counter++;
			} );

			// Automatically add a first row of data
			$('#addRow').click();
		});
	</script>

 

<!-- Search filter -->
<div class="table-responsive">
	<table id="example" class="display tabel table-hover table-bordered"  cellspacing="0" width="100%" >
			<thead>
				<tr>
					<th>S.no</th>
					<th>Business Name</th>
					<th>Contact No</th>
					<th>Status </th>
					<th>Followup </th>
					<th>view </th>
					<th>Edit </th>
					<th>delete </th>											
				</tr>
			</thead>
			<tbody>
				<?php
					// Date filter           
					$sql = "SELECT * FROM customers WHERE 1";		
					if(isset($_POST["from_date"], $_POST["to_date"])) {	
						$fromDate = $_POST['from_date'];
						$endDate = $_POST['to_date'];

						if(!empty($fromDate) && !empty($endDate)){
							$sql .= " and FOLLOWUP between '".$fromDate."' and '".$endDate."' ";
						}
					}				
					// Sort
					$sql .= " ORDER BY CID DESC";
					$sql .= "  LIMIT 0,50";				
					$cus_records = mysqli_query($con,$sql);
						
					if(mysqli_num_rows($cus_records) > 0)  
					  {  
							$i=0;
						   while($row = mysqli_fetch_array($cus_records))  
						   {  
							 $i++;
							echo "<tr>";
								echo "<td> {$i} </td>";
								echo "<td> {$row["BUSINESSNAME"]} </td>";
								echo "<td> {$row["CONTACT"]} </td>";
								echo "<td> {$row["CSTATUS"]} </td>";
								echo "<td> {$row["FOLLOWUP"]} </td>";
								echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button></td>";
								echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
								echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["CID"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
							echo "</tr>";
						   }  
					  }
				?>
			</tbody>
		</table>
</div>

