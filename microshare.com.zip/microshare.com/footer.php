		
			</div> <!-- Page Content END -->
		</div> <!-- Sidebar Holder -->
		
        <!-- jQuery CDN -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!--<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>-->
		<!-- Bootstrap Js CDN -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<!---datatable-->
		<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>		
		<!---datatable Theme-->
		<script src="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.js"></script>
		<link rel="stylesheet" href="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.css">
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">	  
	  <!---datefilter-->
        <script src='assets/js/datefilter/jquery-ui.min.js' type='text/javascript'></script>	  
	  <!--Dynamic-->
		<script src="assets/js/javascript.js"></script>
	</body>
</html>
