<?php
	include "config.php";
?>				
<div class="table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>S.no</th>
			<th>Business Name</th>
			<th>Contact No</th>
			<th>Status </th>
			<th>Followup </th>
		</tr>
	</tr>
	<?php
		$sql="select * from updatecustomers where CID ='{$_POST["id"]}'";
		$result=$con->query($sql);
		
		if($result->num_rows > 0)
		{
			$i=0;
			while($row = $result->fetch_assoc())
			{
				echo "<tr>";
				echo "<td> {$row["CID"]} </td>";
				echo "<td> {$row["BUSINESSNAME"]} </td>";
				echo "<td> {$row["CONTACT"]} </td>";
				echo "<td> {$row["CSTATUS"]} </td>";
				echo "<td> {$row["FOLLOWUP"]} </td>";
				echo "</tr>";
			}
		}
	?>
</table>
</div>

<div id="Hexample">
<div class="table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>Business Name</th>
			<th>Contact No</th>
			<th>Hosting Date </th>
			<th>Expiry Date </th>
			<th>Payment </th>
		</tr>
	</tr>
<?php
	$sql="select * from hosting where Hid ='{$_POST["id"]}'";
	$result=$con->query($sql);		
	if($result->num_rows > 0)
	{
		while($row = $result->fetch_assoc())
		{
			echo "<tr>";
			echo "<td> {$row["Hbusinessname"]} </td>";
			echo "<td> {$row["Hcontact"]} </td>";
			echo "<td> {$row["Hdate"]} </td>";
			echo "<td> {$row["Hexpiry"]} </td>";
			echo "<td> {$row["Repayment"]} </td>";
			echo "</tr>";
		}
	}	
?>
</table>
</div>
</div>


