<?php
	// print_r($_POST);
	include "config.php";
	if(!empty($_POST))  
	{  
		$addname = mysqli_real_escape_string($con, $_POST["addname"]);
		$addcontact = mysqli_real_escape_string($con, $_POST["addcontact"]);
		$addstatus = mysqli_real_escape_string($con, $_POST["addstatus"]);
		$addfollow = mysqli_real_escape_string($con, $_POST["addfollow"]);
		
		
		$sql="INSERT INTO customers (BUSINESSNAME,CONTACT,CSTATUS,FOLLOWUP,CREATEDATE) values('{$addname}','{$addcontact}','{$addstatus}','{$addfollow}',CURDATE())";
		$con->query($sql);
		$message = 'Data Inserted';  
		
		$id=$con->insert_id;  //last insert data id to delete
		
		// appendTo function call		
		echo "<td>{$addname}</td>";
		echo "<td>{$addcontact}</td>";
		echo "<td>{$addstatus}</td>";
		echo "<td>{$addfollow}</td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-eye-open'></span> </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
		
		/* if($con->query($sql))
			{
			echo "Data saved";
		} */
	}
?>

<?php
if(!empty($_POST))  
	{  
		
		


		$Hostname = mysqli_real_escape_string($con, $_POST["Hostname"]);
		$Hostcontact = mysqli_real_escape_string($con, $_POST["Hostcontact"]);
		$Hostdate = mysqli_real_escape_string($con, $_POST["Hostdate"]);
		$Hostexpiray = date('Y/m/d', strtotime('+1 years', strtotime($Hostdate));
		$Hostrepay = mysqli_real_escape_string($con, $_POST["Hostrepay"]);
		
		
		$hosting="INSERT INTO hosting (Hbusinessname,Hcontact,Hdate,Hexpiry,Repayment) values('{$Hostname}','{$Hostcontact}','{$Hostdate}','{$Hostexpiray}','{$Hostrepay}')";
		$con->query($hosting);
		$message = 'Data Inserted';  
		
		$id=$con->insert_id;  //last insert data id to delete
		
		// appendTo function call		
		echo "<td>{$Hostname}</td>";
		echo "<td>{$Hostcontact}</td>";
		echo "<td>{$Hostdate}</td>";
		echo "<td>{$Hostexpiray}</td>";
		echo "<td>{$Hostrepay}</td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
		
		
	}
?>


<?php
/* if(!empty($_POST))  
	{  
		$Hostname = mysqli_real_escape_string($con, $_POST["Hostname"]);
		$Hostcontact = mysqli_real_escape_string($con, $_POST["Hostcontact"]);
		$Hostdate = mysqli_real_escape_string($con, $_POST["Hostdate"]);
		$Hostexpiray = strtotime('+1 years', strtotime($Hostdate));		
		$Hostrepay = mysqli_real_escape_string($con, $_POST["Hostrepay"]);
		
		
		$hosting="INSERT INTO hosting (Hbusinessname,Hcontact,Hdate,Hexpiry,Repayment) values('{$Hostname}','{$Hostcontact}','{$Hostdate}','{$Hostexpiray}','{$Hostrepay}')";
		$con->query($hosting);
		$message = 'Data Inserted';  
		
		$id=$con->insert_id;  //last insert data id to delete
		
		// appendTo function call		
		echo "<td>{$Hostname}</td>";
		echo "<td>{$Hostcontact}</td>";
		echo "<td>{$Hostdate}</td>";
		echo "<td>{$Hostexpiray}</td>";
		echo "<td>{$Hostrepay}</td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger view' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["$id"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
		
		
	} */
?>