<?php
	include "config.php";	
	
// Business talble Delete	
	$sql="delete from customers where CID=".$_POST["id"];
	$con->query($sql);


// Hosting talble Delete
	$sql="delete from hosting where Hid=".$_POST["id"];
	$con->query($sql);
?>