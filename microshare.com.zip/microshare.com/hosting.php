<?php
	include "header.php";
	include "config.php";
?>
				<div class="container">
					<div class="row">
						<div class="col-md-2 col-sm-2 col-xs-12 pull-right">
							<button type="button" id="add" class="btn btn-info" data-toggle="modal" data-target="#addHosting">Add Hosting</button>
							
							<!-- Add new data form start -->
							<div class="modal fade" id="addHosting" role="dialog">
								<div class="modal-dialog modal-sm">		
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h4 class="modal-title">Add Hosting Details</h4>
										</div>										
										<form action="" id="Hostdetails" method="post" required>  
											<div class="modal-body">
												<div class="row">
													<div class="col-md-12">
														<div class="form-group">
															<label for="Hostname">Business Name</label>
															<input type="text" class="form-control" name="Hostname" id="Hostname" placeholder="Enter Business name" data-required="true" data-error-message="Business Name is required" required="" />
														</div>
														<div class="form-group">
															<label for="Hostcontact">Contact No</label>														
															<input type="text"  class="form-control"  name="Hostcontact" id="Hostcontact" placeholder="Enter Mobile no" data-required="true" data-error-message="Mobile no required" required="" />
														</div>														
														<div class="form-group">
															<label for="Hostdate">Hosting Date</label>
															<input type="date" class="form-control"  name="Hostdate" id="Hostdate" placeholder="Enter date" required="" />
														</div>
														<div class="form-group">
															<label for="Hostrepay">Renewal Payment</label>
															<input type="text" class="form-control"  name="Hostrepay" id="Hostrepay" placeholder="Enter renewal payment" required="" />
														</div>	
														
													    <div class="form-group hidden">
															<label for="id"></label>
															<input type="text" name="Hid" class="form-control" id="id" value="0" placeholder="" required="" />
														</div>  
													</div>                  
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
												<input type="submit" name="submit"  id="Hostingsave" class="btn btn-success pull-right" value="Save">
											</div>
										</form>	
										
									</div>							  
								</div>
							</div> <!-- Add new data form END -->							
						</div> 
						
						<div class="col-md-10 col-sm-10 col-xs-12">
							<form>
								<div class="row">
									<div class="form-group col-md-3">
										<input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
									 </div>  
									<div class="form-group col-md-3">
										 <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
									</div>  
									<div class="form-group col-md-3">
										<input type="button" name="filter" id="filter" value="Date Filter" class="btn btn-success">  
									</div>  
								</div> 
							</form>
							<div id="Hostoutput">
								<!--data base to view-->
								<div class="table-responsive">
									<table id="example" class="display tabel table-hover table-bordered"  cellspacing="0" width="100%" >
										<thead>
											<tr>
												<th>S.no</th>
												<th>Name</th>
												<th>Contact</th>
												<th>Hexpiry Date </th>
												<th>Re-Days </th>
												<th>Repayment </th>
												<th>view </th>
												<th>Edit </th>
												<th>delete </th>											
											</tr>
										</thead>
																				
										 <tbody>
												<?php
													
												// $fetchqry = "SELECT * FROM hosting where CURDATE() > Hexpiry";    //Expired Date
												//$fetchqry = "SELECT * FROM hosting where CURDATE() <= Hexpiry";    //active Date
												//$fetchqry = "SELECT * FROM hosting where Hexpiry <= CURDATE()";    //Expired date
												//$fetchqry = "SELECT * FROM hosting WHERE   Hdate <= DATE(NOW()) ";  // active and expired date
												//$fetchqry = "SELECT * FROM hosting";  // active and expired date
												
												 $fetchqry = "SELECT * FROM hosting where Hexpiry > CURDATE()";    //active date												 
												 $fetchqry .= " ORDER BY Hdate ASC";
												$result=mysqli_query($con,$fetchqry);
												$num=mysqli_num_rows($result);
													$i=0;
												while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
													{ 
													$i++;
													?>
													   <tr>
															<td><?php echo $i ?></td>
															<td><?php echo $row['Hbusinessname'];?></td>
															<td><?php echo $row['Hcontact'];?></td>
															<td><?php echo $date1 =  $row['Hdate'];?></td>
															<td><?php
																	$enddate = strtotime('+1 years', strtotime($date1));
																	$now= mktime();
																	$date_diff=($enddate-$now) / 86400;
																		echo round($date_diff, 0)." days left";
																?></td>
															<td><?php echo $row['Repayment'];?></td>															
															<td><?php echo" <button type='button' class='btn btn-sm btn-danger view' data-id='{$row["Hid"]}'> <span class='glyphicon glyphicon-eye-open'></span></span>  </button>" ?></td>
															<td><?php echo" <button type='button' class='btn btn-sm btn-info edit' data-id='{$row["Hid"]}'> <span class='glyphicon glyphicon-edit'></span>  </button>" ?></td>
															<td><?php echo" <button type='button' class='btn btn-sm btn-danger del' data-id='{$row["Hid"]}'> <span class='glyphicon glyphicon-trash'></span>  </button>" ?></td>
													   </tr>	
													   <?php 
													  } 
													  ?>
											</tbody>
										
										
										
									</table>
								</div>

								
							</div>
						</div>
					</div> <!---row end-->
				</div><!---Container end-->
				
				<div class="line"></div>
				
				<!--select data view---> 
					<div class="container">	
						<div class="row">							
							<div class="modal fade" id="Host_viewmodal" role="dialog">
								<div class="modal-dialog modal-lg">					
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h4 class="modal-title">View data popupmodel</h4>
										</div>
										<div class="modal-body" id="Hosting">
											<div class="table-responsive">
												<table class="table table-bordered">
													<tr>
														<th>Business Name</th>
														<th>Contact No</th>
														<th>Hosting Date </th>
														<th>Expiry Date </th>
														<th>Payment </th>
													</tr>
												</tr>
												<?php
													$sql="select * from hosting where Hid ='{$_POST["id"]}'";
													$result=$con->query($sql);
													
													if($result->num_rows > 0)
													{
														while($row = $result->fetch_assoc())
														{
															echo "<tr>";
															echo "<td> {$row["Hbusinessname"]} </td>";
															echo "<td> {$row["Hcontact"]} </td>";
															echo "<td> {$row["Hdate"]} </td>";
															echo "<td> {$row["Hexpiry"]} </td>";
															echo "<td> {$row["Repayment"]} </td>";
															echo "</tr>";
														}
													}
												?>
												
												
											</table>
											</div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										</div>
									</div>					  
								</div>
							</div>
						</div>
					</div>	
					
				

				<div class="line"></div>
				
				
				
	<?php
		include "footer.php";
	?>
	
<!--- https://www.datatables.net/examples/plug-ins/range_filtering.html --->
				<script>
					/* Custom filtering function which will search data in column four between two values */
					$.fn.dataTable.ext.search.push(
						function( settings, data, dataIndex ) {
							var min = parseInt( $('#min').val(), 10 );
							var max = parseInt( $('#max').val(), 10 );
							var age = parseFloat( data[3] ) || 0; // use data for the age column
					 
							if ( ( isNaN( min ) && isNaN( max ) ) ||
								 ( isNaN( min ) && age <= max ) ||
								 ( min <= age   && isNaN( max ) ) ||
								 ( min <= age   && age <= max ) )
							{
								return true;
							}
							return false;
						}
					);
					 
					$(document).ready(function() {
						var table = $('#example').DataTable();
						 
						// Event listener to the two range filtering inputs to redraw on input
						$('#min, #max').keyup( function() {
							table.draw();
						} );
					} );
				</script>
				
				
				
<script>
	$(document).ready(function () {	
	
	
    // alert("Add customer data");

	$('#add').click(function(){   
		$('#Hostdetails')[0].reset();  
	});
	//Insert code
	$('#Hostdetails').on("submit", function(event){  
		event.preventDefault();  
		if($('#Hostname').val() == "")  
		{  
			alert("Business Name is required");  
		}  
		else if($('#Hostcontact').val() == '')  
		{  
			alert("Contact no is required");  
		}  
		else if($('#Hostdate').val() == '')  
		{  
			alert("Date is required");  
		}  
		else if($('#Hostrepay').val() == '')  
		{  
			alert("Renewal Payment is required");  
		}  
		else  
		{  
			var id=$("#id").val();
			if(id==0) 
			{
				$.ajax({  
					url:"insert.php",  
					type:"POST",  
					data:$('#Hostdetails').serialize(),  
					 beforeSend:function(){  
						$('#Hostingsave').val("save success");  
					},   
					success:function(data){  
						$('#Hostdetails')[0].reset();  
						$('#addHosting').modal('hide');
						$("#output").load("view.php");
						$("<tr></tr>").html(d).appendTo(".table");
						$("#id").val(0);  //data id reset used							  
					}  
				});
			}
			else
			{
				// alert("Confirm to updateinsert This");
				$.ajax({
					url: "updateinsert.php",
					type: "GET",
					data: $("#Hostdetails").serialize(),  //all data one by one store
					 beforeSend:function(){  
						$('#addsave').val("updated success");  
					}, 
					success:function(data)
					{
						$("#output").load("view.php");
						$("#Hostdetails")[0].reset();  //form reset data used
						$("#id").val(0);  //data id reset used
						$('#addHosting').modal('hide');
					}
				});
			}
		}  
	});
	
	//delete code
	$(document).on("click",".del", function() {
		var del=$(this);
		var id=$(this).attr("data-id");
		$.ajax({
			url: "delete.php",
			type: "post",
			data: {id:id},
			beforeSend:function(){  
				$('#del').val("delete"); 
				var result = confirm("Are you sure you want to delete this user?");
				if(!result) {
					e.preventDefault();
				}
			},
			success:function(data)
			{
				del.closest("tr").hide();				
			}
		});
	});
	
	//update code
	$(document).on("click",".edit", function() {
		var row=$(this);
		var id=$(this).attr("data-id");
		$("#id").val(id);
		
		// CID  td:eq(0) not calculated table
		
		var addname=row.closest("tr").find("td:eq(1)").text();
		$("#addname").val(addname);
		
		var addcontact=row.closest("tr").find("td:eq(2)").text();
		$("#addcontact").val(addcontact);
		
		var addstatus=row.closest("tr").find("td:eq(4)").text();
		$("#addstatus").val(addstatus);
		
		var addfollow=row.closest("tr").find("td:eq(3)").text();
		$("#addfollow").val(addfollow);
		
		$("#addHosting").modal("show");	 
	});	
	
    //View code
	$(document).on("click", ".view", function(){ 
		var row=$(this);
		var id=$(this).attr("data-id");  
		$.ajax({  
			url:"select.php",  
			type:"POST",  
			data:{id:id},  
			success:function(data){  
				$('#Hosting').html(data);  				
				$('#Host_viewmodal').modal('show');  
				
			}  
		});  
	});
	
	
});			
				</script>