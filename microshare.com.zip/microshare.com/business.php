<?php
	include "header.php";
?>
				<div class="container">
					<div class="row">
						<div class="col-md-2 col-sm-2 col-xs-12 pull-right">
							<button type="button" id="add" class="btn btn-info" data-toggle="modal" data-target="#addnewdata">Add New Data</button>
							
							<!-- Add new data form start -->
							<div class="modal fade" id="addnewdata" role="dialog">
								<div class="modal-dialog modal-sm">		
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h4 class="modal-title">Add Customer Details</h4>
										</div>
										
										<form id="adddata" method="POST">  
											<div class="modal-body">
												<div class="row">
													<div class="col-md-12">
														<div class="form-group">
															<label for="addname">Business Name</label>
															<input type="text" class="form-control" name="addname" id="addname" placeholder="Enter Business name" />
														</div>
														<div class="form-group">
															<label for="addcontact">Mobile no</label>														
															<input type="text"  class="form-control"  name="addcontact" id="addcontact" placeholder="Enter Mobile no"  />
														</div>														
														<div class="form-group">
															<label for="addstatus">Status</label>
															<select class="form-control" name="addstatus" id="addstatus" />
															<option value="">-- Select One --</option>
															<option value="Ignore">Ignore</option>
															<option value="Call back">Call back</option>
															<option value="Appointment">Appointment</option>
														</select>
													</div>
													<div class="form-group">
														<label for="addfollow">Followup</label>
														<input type="date" class="form-control"  name="addfollow" id="addfollow" placeholder="Enter date" />
													</div>													
													<div class="form-group hidden">
														<label for="id"></label>
														<input type="text" name="Cid" class="form-control" id="id" value="0" placeholder="" />
													</div>
												</div>                  
											</div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
											<input type="submit" name="submit" id="addsave" class="btn btn-success pull-right" value="Save">
										</div>
									</form>	
										
									</div>							  
								</div>
							</div> <!-- Add new data form END -->							
						</div> 
						
						<div class="col-md-10 col-sm-10 col-xs-12">
							<form>
								<div class="row">
									<div class="form-group col-md-3">
										<input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
									 </div>  
									<div class="form-group col-md-3">
										 <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
									</div>  
									<div class="form-group col-md-3">
										<input type="button" name="filter" id="filter" value="Date Filter" class="btn btn-success">  
									</div>  
								</div> 
							</form>
							<div id="output">
								<!--data base to view-->
							</div>
						</div>
					</div> <!---row end-->
				</div><!---Container end-->
				
				<div class="line"></div>
				
				<!--select data view---> 
					<div class="container">	
						<div class="row">							
							<div class="modal fade" id="viewpopup" role="dialog">
								<div class="modal-dialog modal-lg">					
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h4 class="modal-title">View data popupmodel</h4>
										</div>
										<div class="modal-body" id="view_data">
											<!-- select data view here-->
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										</div>
									</div>					  
								</div>
							</div>
						</div>
					</div>	
					
				

				<div class="line"></div>
				
	<?php
		include "footer.php";
	?>
		
      