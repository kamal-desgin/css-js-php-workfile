<?php
session_start();
include("wadmin/config.php");

$con = new mysqli($host,$user,$pass,$db_name) or die(mysql_error());

//Get Day from date
$day = date('D', strtotime($_SESSION['slot_date']));
$day = strtoupper($day);
$total = 0;

//Calc total cost
foreach($_SESSION['slot_time'] as $key => $val)
{
    $time = $_SESSION['slot_time'][$key];
    $court_id = $_SESSION['slot_court_id'][$key];

    $sel_cm = "select h$time from $court_cost_table where day='$day' and court_id='$court_id'";
    $res_cm = $con->query($sel_cm) or die(mysqli_error($con));
    $data_cm = $res_cm->fetch_array();

    $total += $data_cm["h$time"];
}

echo "<h6>".count($_SESSION['slot_time'])." Slots selected</h6>";
echo "<h4>Rs.".$total."</h4>";

?>
