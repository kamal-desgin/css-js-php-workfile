<?php
$host = "localhost"; 
$user = "root";
$pass = "";
$db_name = "kuzhal";

/* $host = "localhost"; 
$user = "new_kuzhal_user";
$pass = "d#uH-p(F8F;X";
$db_name = "new_kuzhal_db"; */
$con=mysqli_connect($host,$user,$pass,$db_name);


define("DBPRE",""); //DB prefix
// define("DBPRE","be"); //DB prefix
define("TITLE","KUZHAL"); //Title

$app_key = "k15486";

//Mail Configs
$mail_website_url = "https://www.kuzhal.co.in/";
$mail_bg = "url($mail_website_url/images/mail_bg.jpg) no-repeat"; //Image pah or color code
$mail_logo = "$mail_website_url/images/Kuzhal_isai_pattrai.png";
$mail_phone = "+91 984109001";
$mail_email = "admin@kuzhal.co.in";
$mail_copyright = "Kuzhal";
$mail_copyright_url = $mail_website_url;



	
date_default_timezone_set('Asia/Kolkata');

//Others
$default_slot_price = 2000;

//Tables
/*  $court_master_table = DBPRE."_court_master";
	$court_cost_table = DBPRE."_court_cost";
	$bookings_table = DBPRE."_bookings";
	$booking_schedule_table = DBPRE."_booking_schedule";
	$booking_slots_table = DBPRE."_bookings_slots";
	$branch_table = DBPRE."_branch";
	$gallery_table = DBPRE."_gallery_images";
	$players_table = DBPRE."_players";
	$slider_table = DBPRE."_slider_master";
	$settings_table = DBPRE."_settings"; */
	
//Tables



$court_master_table = DBPRE."book_master";
$court_cost_table = DBPRE."court_cost";
//$bookings_table = DBPRE."bookings";
$bookings_table = DBPRE."bookingform";
$booking_schedule_table = DBPRE."booking_schedule";
$booking_slots_table = DBPRE."bookings_slots";
$settings_table = DBPRE."settings";


$edays = array("MON","TUE","WED","THU","FRI","SAT","SUN");
$edays_full = array("MON"=>"Monday","TUE"=>"Tuesday","WED"=>"Wednesday","THU"=>"Thursday","FRI"=>"Friday","SAT"=>"Saturday","SUN"=>"Sunday");

function addOrdinalNumberSuffix($num)
{
	if (!in_array(($num % 100),array(11,12,13)))
	{
		switch ($num % 10)
		{
			// Handle 1st, 2nd, 3rd
			case 1:  return $num.'st';
			case 2:  return $num.'nd';
			case 3:  return $num.'rd';
		}
	}
	return $num.'th';
}

?>