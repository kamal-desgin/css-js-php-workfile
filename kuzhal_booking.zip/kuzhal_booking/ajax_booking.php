<link rel=stylesheet href=style.css>
<?php
session_start();
include("wadmin/config.php");

$con = new mysqli($host,$user,$pass,$db_name) or die(mysql_error());


				//Court Display (Menu)
				$sel_cm = "select * from $court_master_table where status='A' order by sno asc";
				$res_cm = $con->query($sel_cm) or die(mysqli_error($con));
				$c = 0;
				//echo "<ul class='wm_ul'>";
				while($data_cm = $res_cm->fetch_array())
				{
					/*$c++;
					if($c == $_GET['court_id'])
					{
						$_SESSION['court_id'] = $data_cm['id'];
						echo "<li><a onclick='clear_booking(".$data_cm['id'].");' class='wm_active'>$data_cm[name]</a></li>";
					}
					else
						echo "<li><a onclick='clear_booking(".$data_cm['id'].");'>$data_cm[name]</a></li>";*/
					$court_id_array[] = $data_cm['id'];
					$court_name_array[] = $data_cm['name'];
				}
				//echo "</ul>";
				?>

				<?php
				//Booking Slots CODE
				//echo $_SESSION['bslot_date'];
				if(isset($_GET['sdate']))
				{
					if($_GET['sdate'] != "")
					{
						$bd = explode("-",$_GET['sdate']);
						$s_date = $bd[2]."-".$bd[1]."-".$bd[0];
					}
					else
					{
						$sel_q = "select * from $settings_table where id=1";
						$sel_res = $con->query($sel_q) or die(mysqli_error($con));
						$sel_data = $sel_res->fetch_array();

						/*$d1 = explode("/",$sel_data['book_sdate']);
						$d2 = explode("/",$sel_data['book_edate']);

						$s_date = $d1[2]."-".$d1[1]."-".$d1[0];
						$e_date = $d2[2]."-".$d2[1]."-".$d2[0];*/

						$s_date = $sel_data['book_sdate'];
					}
				}
				else
				{
					$sel_q = "select * from $settings_table where id=1";
					$sel_res = $con->query($sel_q) or die(mysqli_error($con));
					$sel_data = $sel_res->fetch_array();

					/*$d1 = explode("/",$sel_data['book_sdate']);
					$d2 = explode("/",$sel_data['book_edate']);

					$s_date = $d1[2]."-".$d1[1]."-".$d1[0];
					$e_date = $d2[2]."-".$d2[1]."-".$d2[0];*/

					$s_date = $sel_data['book_sdate'];
				}

				$start_date = $s_date;

				//for($l=1;$l<=$display_days;$l++)
				foreach($court_id_array as $kk => $vv)
				{
					//$day = $l-1;
					//$next_day = date("Y-m-d", strtotime("+ $day day",$start_date));
					$next_day = $start_date;

					$select_query = "select * from $booking_schedule_table where booked_date='$next_day' and court_id='$vv'";
					$result = $con->query($select_query) or die(mysqli_error($con));
					if($result->num_rows > 0)
					{
						$data = $result->fetch_array();

						for($z=1;$z<=24;$z++)
						{
							$h[$vv][$z] = $data['h'.$z];
						}
					}
					else
					{
						for($z=1;$z<=24;$z++)
						{
							$h[$vv][$z] = 0;
						}
					}
				}

				//This week text
				/*$sdate = addOrdinalNumberSuffix(date('d'));
				$smonth = date('M');

				$edate = addOrdinalNumberSuffix((int)date("d", strtotime("+ $display_days day")));
				$emonth = date("M", strtotime("+ $display_days day"));

				$week_dates_text = $sdate." ".$smonth." - ".$edate." ".$emonth;*/
				?>

				<table class="wm_booking_tb">
					<tr>
						<th style="width:120px;" class="thead">Time</th>
						<?php
						foreach($court_id_array as $kk => $vv)
						{
							echo "<th class='thead'><span style='font-size:10.5px;'>$court_name_array[$kk]</span></th>";
						}
						?>
					</tr>
					<?php
					$clr = 1;
					for($i=0;$i<=23;$i++)
					{
						if($i == 0)
							$i = 24;

						if($i > 12 && $i != 24)
							$time = ($i-12).".00 PM";
						elseif($i == 12)
							$time = $i.".00 PM";
						elseif($i == 24)
							$time = ($i-12).".00 AM";
						else
							$time = $i.".00 AM";
						?>
						<tr class="bg_tr<?php echo $clr; ?>">
							<td style="text-align:center;"><?php echo $time; ?></td>
							<?php
							$clr *= -1;
							//for($l=1;$l<=$display_days;$l++)
							foreach($court_id_array as $kk => $vv)
							{
								if($i == 24)
									$icheck = 0;
								else
									$icheck = $i;

								if($icheck > date('H') || $s_date != date('Y-m-d'))
								{
									if($h[$vv][$i] == 0)
									{
										if(isset($_SESSION['slot_data']))
										{
											if (in_array($vv."_".$i, $_SESSION['slot_data']))
												echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="delete_slot('.$vv.','.$i.');"><img src="images/selected.png" class="wm_iicon"></a></td>';
											else
												echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="add_slot('.$vv.','.$i.');"><img src="images/available.png" class="wm_iicon"></a></td>';
										}
										else
											echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="add_slot('.$vv.','.$i.');"><img src="images/available.png" class="wm_iicon"></a></td>';
									}
									else
									{
										echo '<td><img src="images/booked.png" class="wm_iicon wm_ii_bo" title="Booked"></td>';
									}
								}
								else
								{
									echo '<td><img src="images/unavailable.png" class="wm_iicon wm_ii_bo" title="Booked"></td>';
								}
							}
							?>
						</tr>
						<?php
						if($i == 24)
							$i = 0;
					}
					?>
				</table>
