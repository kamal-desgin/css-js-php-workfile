<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">		
		<link href="https://kuzhal.co.in/datepicker/css/datepicker.min.css" rel="stylesheet" type="text/css">
  
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
  
	<section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          
		  <?php
		  error_reporting(0);
		  session_start();
		  include("config.php");

		$con = new mysqli($host,$user,$pass,$db_name) or die(mysql_error());

		if(isset($_POST['confirm_booking']))
		{
			//Inserting Table
			extract($_POST);
			
			$created_at = date('Y-m-d g:i:s');
			$status = "A";
			
			$sel_cm = "select cost from $settings_table where id='1'";
			$res_cm = $con->query($sel_cm) or die(mysqli_error($con));
			$data_cm = $res_cm->fetch_array();
			
			//Get Day from date
            $day = date('D', strtotime($_SESSION['slot_date']));
            $day = strtoupper($day);
            $total = 0;
			
			//Calc total cost
            foreach($_SESSION['slot_time'] as $key => $val)
            {
                $time = $_SESSION['slot_time'][$key];
                $court_id = $_SESSION['slot_court_id'][$key];
            
                $sel_cm = "select h$time from $court_cost_table where day='$day' and court_id='$court_id'";
                $res_cm = $con->query($sel_cm) or die(mysqli_error($con));
                $data_cm = $res_cm->fetch_array();
            
                $total += $data_cm["h$time"];
            }
            
			//$court_id = $_SESSION['court_id'];
			$bd = explode("-",$_POST['show_sdate']);
			$slot_date = $bd[2]."-".$bd[1]."-".$bd[0];
			
			
			//send to email
			$course_status = "Waiting";		
			$sname= $_POST['name'];
			$semail= $_POST['email'];
			$smobile= $_POST['mobile'];			
			$from_name = "$sname";
			$from_mail = "$semail";
			$user_email= "$semail";
			
			
			echo $insert_query = "insert into applicationform (seat_no,name,father_name,mother_name,dob,blood_group,education,course,experience,present_address,permanent_address,email,mobile,f_mobile,created_at,status) 
			values('$total','$name','$father_name','$mother_name','$dob','$blood_group','$education','$course','$experience','$present_address','$permanent_address','$email','$mobile','$f_mobile','$created_at','$status')";
			$insert_res = $con->query($insert_query) or die(mysqli_error($con));
			$booking_id = $con->insert_id;
			
			
			$dir_location = "register_files";
			$photo_ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
			$adhar_ext = pathinfo($_FILES['adhar']['name'], PATHINFO_EXTENSION);
			$photo_file = "photo_".$booking_id.".png";
			$adhar_file = "adhar_".$booking_id.".".$adhar_ext;
			$img = $_POST['photo']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';
			$img = str_replace('data:image/png;base64,', '', $img);
			$img = str_replace(' ', '+', $img);
			$data = base64_decode($img);
			file_put_contents($dir_location."/".$photo_file, $data);
			//file_put_contents($photo_file, base64_decode());
			//move_uploaded_file($_FILES['photo']['tmp_name'],$dir_location."/".$photo_file);
			move_uploaded_file($_FILES['adhar']['tmp_name'],$dir_location."/".$adhar_file);
			$update = "update $bookings_table set photo='$photo_file',adhar='$adhar_file' where id='$booking_id'";
			$con->query($update) or die(mysqli_error($con));
			
			 
			
			
			//Insert into booking slots
			foreach($_SESSION['slot_time'] as $key => $value)
			{
				//$slot_date = $_SESSION['slot_date'][$key];
				$slot_time = $_SESSION['slot_time'][$key];
				$slot_court_id = $_SESSION['slot_court_id'][$key];

				$insert_slots = "insert into $booking_slots_table(booking_id,court_id,booked_date,booked_time) 
											values('$booking_id','$slot_court_id','$slot_date','$slot_time')";
				$res_slots = $con->query($insert_slots) or die(mysqli_error($con));				
			}
			
			
			
			$_SESSION['payumoney_txnid'] = $booking_id;
			$_SESSION['payumoney_order_total'] = $total;
			//$_SESSION['payumoney_order_total'] = 1;
		    $_SESSION['customer_name'] = $name;
			$_SESSION['customer_email'] = $email;
			$_SESSION['customer_mobile'] = $mobile;
			echo "<script>window.location.href='payment.php';</script>";
							
			
			
			// Register Mail Send			
		
			$mail_bg = "url(https://kuzhal.co.in/images/inerpageslider1.jpg) no-repeat"; //Image pah or color code
			$mail_logo = "https://kuzhal.co.in/images/Kuzhal_isai_pattrai.png";
			$mail_phone = "+91 98410 70001,  98410 90001";
			$mail_email = "kuzhalisaipattarai@gmail.com";
			$mail_copyright = "Kuzhal Isai Pattarai";
			$mail_website_url = "https://kuzhal.co.in/";
			$mail_button_url = $mail_website_url;
			$mail_copyright_url = $mail_website_url;		
		    	
			
			$subject = "Booking Seat Received | kuzhal.co.in";
			$to_mail = $user_email;
			
			//Mail
					$mail_h4 = "Booking your class";
					$mail_h1 = "Kuzhal Isai Pattrai";
					$mail_main_msg = "<table width='50%' cellpadding='5'>					
										<tr><th>Seat No</th><th> : </th><td>$total</td></tr>
										<tr><th>Student Name</th><th> : </th><td>$sname</td></tr>
										<tr><th>Email</th><th> : </th><td>$semail</td></tr>
										<tr><th>Mobile</th><th> : </th><td>$smobile</td></tr>										
									</table>";
			
			$_SESSION['mail_main_msg'] = $mail_main_msg;
			
					//Headers
					$headers .= "Reply-To: The Sender <$from_mail>\r\n";
					$headers .= "Return-Path: $from_name <$from_mail>\r\n";
					$headers .= "From: $from_name <$from_mail>\r\n";

					$headers .= "Organization: Sender Organization\r\n";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					$headers .= "X-Priority: 3\r\n";
					$headers .= "X-Mailer: PHP". phpversion() ."\r\n";

					$htmlcontent = '<div style="background:'.$mail_bg.';width:100%;padding:50px 0;">
										<table style="color:#222;font-size:13px;width:80%;margin:0 auto;background: #ffffffc9;" cellpadding="12">
											<tr>
												<td colspan="2" style="width:150px;"><a href=""<img src="'.$mail_logo.'" width="100"></a></td>
												<td colspan="3" style="text-align:right;line-height:1.7"><b>Contact:</b> '.$mail_phone.' <br><b>Email:</b> '.$mail_email.'</td>
											</tr>
											<tr>
												<td colspan="5" style="padding:15px 0;text-align:center;color:#751d33;">
													<h4>'.$mail_h4.'</h4>
													<h1>'.$mail_h1.'</h1>
												</td>
											</tr>
											<tr>
												  <td colspan="5" style="padding:0px 25px 10px 25px;font-size:16px;font-family:Arial,sans-serif;text-align:center;vertical-align:top;color:#828282" align="center">
													<span style="font-size:22px;font-weight:bold;color: #0093ff;background-color: #fff;padding: 10px 20px;border-left: 3px solid #ff7e00;">Your booking is received! '.$course_status.' for Approval.</span>
												  </td>
												</tr>
											<tr>
												<td colspan="5">
													<center>'.$_SESSION['mail_main_msg'].'</center>
													<a href="'.$mail_button_url.'" style="background:#243F4F;color:#751d33;padding:15px 20px;text-decoration:none;font-weight:bold;margin:0 auto;display:table;border-radius:7px;">'.$mail_button.'</a>
												</td>
											</tr>
											<tr>
												<td colspan="5" style="padding:20px 0;">
													<p style="font-size:12px;color:#751d33;text-align:center;padding:0 30px;">This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message.</p>
													<p style="font-size:12px;color:#751d33;text-align:center;">Copyright &copy; 2018 <a href="'.$mail_copyright_url.'" style="text-decoration:none;font-weight:bold;color:#9c0606;">'.$mail_copyright.'</a></p>
												</td>
											</tr>
										</table>
									</div>';
			
			
		
			$mail_sent = mail($to_mail, $subject, $htmlcontent, $headers);
			if( $mail_sent ) {
				echo "<script type='text/javascript'>alert('Booking submitted successfully!')</script>";
			  }
			  else
			  {
				echo "<script type='text/javascript'>alert('Booking failed!')</script>";
			  }	
			
			//Register Mail Send
		}
		?>

		
		
		
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-md-offset-1 col-md-10 col-sm-12 col-xs-12 well well-sm">
							<div class="alert alert-success text-center">
								<h2>Kuzhal Isai Pattarai</h2>
								<h4>Book your Course & Classroom Seat</h4>
							</div>	
								
								<div class="col-md-6 col-sm-6 col-xs-12">
									<?php
									//Get Day from date
									$day = date('D', strtotime($_SESSION['slot_date']));
									$day = strtoupper($day);
									$total = 0;
									
									//Calc total cost
									foreach($_SESSION['slot_time'] as $key => $val)
									{
										$time = $_SESSION['slot_time'][$key];
										$court_id = $_SESSION['slot_court_id'][$key];
									
										$sel_cm = "select h$time from $court_cost_table where day='$day' and court_id='$court_id'";
										$res_cm = $con->query($sel_cm) or die(mysqli_error($con));
										$data_cm = $res_cm->fetch_array();
									
										$total += $data_cm["h$time"];
									}

									echo "<h6>".count($_SESSION['slot_time'])." Seat selected</h6>";
									echo "<h4>Seat No.".$total."</h4>";
									?>
								</div>
						
						<div class="col-md-12 col-sm-12 col-xs-12">
							<!---<form method="post" data-parsley-validate="" name=contact class="formcontact2">
								<div class=form-group1>
									<label>Name</label>
									<input type=text class=form-control name=name placeholder=Name required="" data-parsley-required-message="please insert Name">
									<input type=hidden name=show_sdate value="<?php echo $_POST['show_sdate']; ?>">
								</div>
								<div class=form-group1>
									<label>Mobile</label>
									<input type=text class=form-control name=mobile placeholder=Mobile required="" pattern="[789][0-9]{9}" data-parsley-required-message="please insert Phone No">
								</div>
								<div class=form-group1>
									<label>Email</label>
									<input type=email class=form-control name=email placeholder=Email required="" data-parsley-required-message="please insert Email">
								</div>
								<button type=submit class="btn btn-red" name="confirm_booking">Book</button>
								<div class=form-message></div>
							</form> --->
							<form method="post" data-parsley-validate="" name=contact class="formcontact2" enctype="multipart/form-data">	
										<div class="col-md-6 col-sm-6 col-xs-12">
											<fieldset>
												<div class="form-group">
													<label class="sr-only">Name *</label>
													<input type="text" class="form-control" name="name" placeholder="Your Name" required >
													<input type="hidden" name="show_sdate" value="<?php echo $_POST['show_sdate']; ?>">
												</div>
											 <div class="form-group">
													<label class="sr-only">Father Name *</label>
													<input type="text" class="form-control" name="father_name" placeholder="Name of Father / Guardian" required >
												</div>
												<div class="form-group">
													<label class="sr-only">Mother Name *</label>
													<input type="text" class="form-control" name="mother_name" placeholder="Mother's Name" required >
												</div>
												<div class="form-group">
													<label class="sr-only">Date of Birth *</label>
													<input type="text" name="dob" class="datepicker-here form-control" data-position="right top" data-language='en' placeholder="Date of Birth" required >
												</div> 												
												<div class="form-group">
													<label class="sr-only">Select Blood Group</label>
													<select name="blood_group" class="form-control" required >
														<option>A+</option>
														<option>A-</option>
														<option>B+</option>
														<option>B-</option>
														<option>O+</option>
														<option>O-</option>
														<option>AB+</option>
														<option>AB-</option>
													</select>
												</div>
												<div class="form-group">
													<label class="sr-only">Education Qualification *</label>
													<input type="text" class="form-control" name="education" placeholder="Education Qualification" required >
												</div>
											
												<label>Course Preferred</label>
												<div class="checkbox">
													<label class="checkbox-inline">
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Vocal" name="course[]"> Vocal</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Violin" name="course[]"> Violin</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Veena" name="course[]"> Veena</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Flute" name="course[]"> Flute</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Saxophone" name="course[]"> Saxophone</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Keyboard" name="course[]"> Keyboard</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Guitar" name="course[]"> Guitar</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Drums" name="course[]"> Drums</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Bharathanatiyam" name="course[]"> Bharathanatiyam</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Mridangam" name="course[]"> Mridangam</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Moharsing" name="course[]"> Moharsing</label>
														<label class="col-md-4 col-sm-4 col-xs-6"><input type="checkbox" value="Folk Dance" name="course[]"> Folk Dance</label>
														<label class="col-md-6 col-sm-6 col-xs-6"><input type="checkbox" value="Western Dance" name="course[]"> Western Dance</label>
													</label>	
												</div>																
												<div class="form-group">
													<label class="sr-only">Music Experience *</label>
													<input type="text" class="form-control" name="experience" placeholder="Previous Music Experience" required >
												</div>
											</fieldset>
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<fieldset>	
												<div class="form-group">
													<label class="sr-only">Present Address *</label>
													<textarea class="form-control" rows="3" name="present_address" placeholder="Present Address" required ></textarea>
												</div>
												<div class="form-group">
													<label class="sr-only">Permanent Address *</label>
													<textarea class="form-control" rows="3" name="permanent_address" placeholder="Permanent Address" required ></textarea>
												</div> 
																																					
												<div class="form-group">
													<label class="sr-only">Email Address * </label>
													<input type="email" class="form-control" name="email" placeholder="Email Address" required >
												</div>														
												<div class="form-group">
													<label class="sr-only">Personal Number *</label>
													<input type="text" class="form-control" name="mobile" placeholder="Personal Number" required >
												</div>
												<div class="form-group">
													<label class="sr-only">Father/Mother phone Number *</label>
													<input type="text" class="form-control" name="f_mobile"placeholder="Father/Mother/Guardian Phone Number" required >
												</div>
												<div class="form-group">
													<label>Photo (Maximum 2MB)</label>
													<input type="file" class="form-control" id="sample_input"  name="photo" required>
												</div>
												<div class="form-group">
													<label>Adhar Card (Maximum 2MB)</label>
													<input type="file" class="form-control" name="adhar" required>
													<span style="font-size:11px;">Only Upload Seperated Adhar Card<br> <a href="https://kuzhal.co.in/default_adhar/sample_adhar.jpg" target="_blank" style="color:blue;text-decoration: underline;">View Sample</a></span>
												</div>												
												<div class="form-group">
													<input type="submit" name="confirm_booking" id="submit" class="btn btn-success btn-block" value="Submit Application">
												</div>														
											</fieldset>
										</div>											
									</form><!-- END--->	
						</div>
					</div>
                </div>
            </div>
        </section>
        </div>
      </div>
    </section><!-- #about -->


  <!--==========================
    Footer
  ============================-->
 


    <!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Modal title</h4>
		  </div>
		  <div class="modal-body">
			 <iframe src="booking.php" id="modeliframe" style="zoom:0.60" frameborder="0" height="250" width="99.6%"></iframe>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<button type="button" class="btn btn-primary">Save changes</button>
		  </div>
		</div>
	  </div>
	</div>

	<script>
	$(document).ready(function(e) {
		$('.bootpopup').click(function(){
		  var frametarget = $(this).attr('href');
		  targetmodal = '#myModal'; 
				$('#modeliframe').attr("src", frametarget );   
		});
	});
	</script>

</body>
</html>
