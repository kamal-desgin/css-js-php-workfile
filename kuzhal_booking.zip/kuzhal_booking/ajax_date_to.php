<?php
session_start();

$date = $_GET['show_sdate'];
//date('d-m-Y', strtotime(your date variable));
$_SESSION['bdate'] = $date;

$bd = explode("-",$_SESSION['bdate']);
$_SESSION['bslot_date'] = $bd[2]."-".$bd[1]."-".$bd[0];

echo $date;
//echo date('d-m-Y', strtotime("+5 day", strtotime($date)));

?>