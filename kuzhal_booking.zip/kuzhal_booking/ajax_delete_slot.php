<?php
session_start();

include("wadmin/config.php");
$con = new mysqli($host,$user,$pass,$db_name) or die(mysql_error());

$sdate = $_GET['sdate'];
$court_id = $_GET['court_id'];
$time = $_GET['time'];

$key = array_search ($court_id."_".$time, $_SESSION['slot_data']);

unset($_SESSION['slot_data'][$key]);
unset($_SESSION['slot_time'][$key]);
unset($_SESSION['slot_court_id'][$key]);

?>

<?php
if(!isset($_GET['no_table']))
{
	?>
<table>
	<tr>
		<th>DATE</th>
		<th>START TIME</th>
		<th>END TIME</th>
		<th>PRICE</th>
	</tr>
	<?php
	$total_cost = 0;
	foreach($_SESSION['slot_data'] as $key => $add_slot)
	{
		$date = $_SESSION['slot_date'][$key];
		$adsl = $_SESSION['slot_time'][$key];
		
		if($adsl > 12 && $adsl != 24)
			$time = sprintf("%02d",($adsl-12)).".00 PM";
		elseif($adsl == 12)
			$time = sprintf("%02d", $adsl).".00 PM";
		elseif($adsl == 24)
			$time = sprintf("%02d",($adsl-12)).".00 AM";
		else
			$time = sprintf("%02d", $adsl).".00 AM";
		
		$stime = sprintf("%02d", $adsl)."00";
		
		$end_time = date('h:i A', strtotime($stime.'+1 hour'));
		
		echo "<tr>
				<td>$date</td>
				<td>$time</td>
				<td>$end_time</td>
				<td>Rs.$slot_price &nbsp;&nbsp; <a onclick='delete_slot(".$_SESSION['slot_date_no'][$key].",".$_SESSION['slot_time'][$key].");'><img src='images/booked.png' class='wm_iicon'></a></td>
			  </tr>";
		$total_cost += $slot_price;
	}
	?>
	<tr>
		<th colspan="2" style="text-align:left;padding:10px 50px;">TOTAL : </th>
		<th colspan="2" style="text-align:right;padding:10px 50px;">Rs.<?php echo $total_cost; ?></th>
	</tr>
</table>
	<?php
}
?>





