<?php
	//session_start();
	//error_reporting(0); 
	include"config.php";
	//$application_tb = "applicationform";
	//$dir_location = "register_files";
?>

<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">		
		<link rel="stylesheet" href="course_modal.css">
		<link href="https://kuzhal.co.in/datepicker/css/datepicker.min.css" rel="stylesheet" type="text/css">
		<!--- Script START --->		
		<script type="text/javascript">
			$(window).on('load',function(){
				$('#myModal').modal('show');
			});	
			$(document).ready(function(){
				//alert("hi");
				
				//checkbox validation
				$('#submit').click(function() {
					checked = $("input[type=checkbox]:checked").length;
					if(!checked) {
						alert("You must Book your seat left Box.");
						return false;
					}
				});	
				
				//only one checkbox select
				$('.seatcheck').click(function() {
					$(this).siblings('input:checkbox').prop('checked', false);
				});
				
			});
		</script>
		
		
		<!-- Date picker -->
        <script src="https://kuzhal.co.in/datepicker/js/datepicker.min.js"></script>
		<script src="https://kuzhal.co.in/datepicker/js/datepicker.en.js"></script>
		<script language="Javascript" type="text/javascript">
			$(document).ready(function(){
				$("#booking").load("booking.php"); 
			});
		
			function onlyNos(e, t) {
				try {
					if (window.event) {
						var charCode = window.event.keyCode;
					}
					else if (e) {
						var charCode = e.which;
					}
					else { return true; }
					if (charCode > 31 && (charCode < 48 || charCode > 57)) {
						return false;
					}
					return true;
				}
				catch (err) {
					alert(err.Description);
				}
			}
		</script>
		
	</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery Select box using</a>
					</div>
				</div>
			</nav>
		</header>
		


	
   
<form method="post" action="checkout.php">
<!-- Modal START-->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog modal-lg modal-xl" role="document">
		<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Book your Course</h4>
				  </div>
				  <div class="modal-body" id="modal-body">
				  <div class="row"><!--row start-->
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
						<div class="booking">
						<h3 class="text-center">Class Time</h3>
							<ul class="nav nav-pills nav-stacked" id="stacked-menu">
								<li class="active"><a data-toggle="collapse" data-parent="#stacked-menu" data-target="#vocal">Vocal Class Time<span class="caret"></span></a>
									<ul class="nav nav-pills nav-stacked collapse in" id="vocal">
										  <li ><a href="#">5am to 6am</a></li>
										  <li><a href="#">6am to 7am</a></li>
										  <li><a href="#">7am to 8am</a></li>
									</ul>
								</li>
								<li class="active"><a data-toggle="collapse" data-parent="#stacked-menu" data-target="#veena">Veena Class Time<span class="caret"></span></a>
									<ul class="nav nav-pills nav-stacked collapse out" id="veena">
										  <li ><a href="#">5am to 6am</a></li>
										  <li><a href="#">6am to 7am</a></li>
										  <li><a href="#">7am to 8am</a></li>
									</ul>
								</li>
								<li class="active"><a data-toggle="collapse" data-parent="#stacked-menu" data-target="#guiter">Guiter Class Time<span class="caret"></span></a>
									<ul class="nav nav-pills nav-stacked collapse out" id="guiter">
										 <li ><a href="#">5am to 6am</a></li>
										  <li><a href="#">6am to 7am</a></li>
										  <li><a href="#">7am to 8am</a></li>
									</ul>
								</li>						
							</ul>
						</div>
					</div> <!--col-md-2 END-->
					
				 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">				 
							<div class="col-md-12 col-sm-12 col-xs-12">										
										<div id="keyboard">
											<input type='checkbox' class="seatcheck" name='Seat' value='Guru' id="Seat0" disabled /><label for="Seat0"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat1"/><label for="Seat1"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat2"/><label for="Seat2"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat3"/><label for="Seat3"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat4"/><label for="Seat4"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat5"/><label for="Seat5"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat6"/><label for="Seat6"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat7"/><label for="Seat7"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat8"/><label for="Seat8"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat9"/><label for="Seat9"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat10"/><label for="Seat10"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat11"/><label for="Seat11"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat12"/><label for="Seat12"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat13"/><label for="Seat13"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat14"/><label for="Seat14"></label> 
											<input type='checkbox' class="seatcheck" name='Seat' value='valuable' id="Seat15"/><label for="Seat15"></label>
										</div>
										
										</div>
					<div id="booking"></div>
						 <!--- <iframe src="booking.php" id="modeliframe" style="zoom:0.60" frameborder="0" height="800px" width="99.6%"></iframe> -->
				  </div>
					
				 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
						<div class="booking">
							<h3>Instrument Syllabus</h3>
							<div class="col-md-6 box">
								<h4> Grade-1</h4>
								<ul class="list-unstyled"> 
									<li>1. Sarali Varisaigal</li>
									<li>2. Jandai Varisaigal</li>
									<li>3. Melsthayi Varisai</li>
									<li>4. Keel Swara Varisai</li>
									<li>5. Thattu Varisaigal - 2</li>
									<li>6. Alankarangal </li>
								</ul>
							</div>
							<div class="col-md-6 box">
								<h4> Grade-2</h4>
								<ul class="list-unstyled"> 
									<li>1. Sanchari Geetham - 2</li>
									<li>2. Jathiswaram - 1</li>
									<li>3. Swarajati - 1</li>
								</ul>
							</div>
							<div class="col-md-6 box">
								<h4> Grade-3</h4>
								<ul class="list-unstyled"> 
									<li>1. Sanchari Geetham - 2</li>
									<li>2. Jathiswaram</li>
									<li>3. Athi thala (Thana) Varnam</li>
								</ul>
							</div>
							<div class="col-md-6 box">
								<h4> Grade-4</h4>
								<ul class="list-unstyled"> 
									<li>1. Athi thala (Thana) Varnam - 2</li>
									<li>2. Krithis - 4</li>
									<li>3. Thevaram - 1</li>
									<li>4. Keerthanas - 4</li>
									<li>5. Thiruppugazh - 1</li>
								</ul>
							</div>
							<div class="col-md-6 box">
								<h4> Grade-5</h4>
								<ul class="list-unstyled"> 
									<li>1. Tana Varnam - 2</li>
									<li>2. Navaragamaliga Varnam - 1</li>
									<li>3. Keerthanas - 4</li>
									<li>4. Aazhvaar Pasuram</li>
									<li>5. Patriotic Songs - 2</li>
								</ul>
							</div>
							
						</div>
					</div>
				  </div> <!--row end-->
				  </div>
				  <div class="modal-footer">
					<div class="row">
						<div class="col-md-4 col-sm-4 col-xs-12">
							<ul class="text-left list-inline">
								<li><img src="checkbox/student_available.png" width="25" > <strong>Available</strong> </li>
								<li><img src="checkbox/student_selected.png" width="25" > <strong>Selected</strong> </li>
								<li><img src="checkbox/student_booked.png" width="25" > <strong>Booked</strong> </li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12">
							<div class="text-center" id="cart_price">
								<!--<h6>2 Slots selected</h6>
								<h4>Rs.500</h4>-->
							</div>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-12 text-center"> 
							<button type="submit" id="submit" class="btn btn-success">Book Now</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				  </div>
			</div>
	  </div>
	</div> <!-- Modal EMD-->
</form> <!-- Form END-->
	
	
<!---	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog modal-lg modal-xl" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Modal title</h4>
		  </div>
		  <div class="modal-body">
			 <iframe src="booking.php" id="modeliframe" style="zoom:0.60" frameborder="0" height="250" width="99.6%"></iframe>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<button type="button" class="btn btn-primary">Save changes</button>
		  </div>
		</div>
	  </div>
	</div> --->
	
	
    
	<script>
	$(document).ready(function(e) {
		$('.bootpopup').click(function(){
		  var frametarget = $(this).attr('href');
		  targetmodal = '#myModal';
		  $('#modeliframe').attr("src", frametarget );
		});
		
		//checkbox select
		$('.input_class_checkbox').each(function(){
			$(this).hide().after('<div class="class_checkbox" />');
		});

		$('.class_checkbox').on('click',function(){
			$(this).toggleClass('checked').prev().prop('checked',$(this).is('.checked'))
		});	
	});
	</script>

</body>
</html>