<?php
session_start();
if(isset($_SESSION['payumoney_txnid']))
{
	//require_once("wadmin/config.php");
?>
<script>
function submitPayment()
{
	var paymentForm = document.forms.paymentForm;
	paymentForm.submit();
}
</script>

<body onload="submitPayment()">
	Please wait...
	<form method="post" action="payumoney.php" name="paymentForm" style="display:none;">
		<input type="text" name="key" placeholder="key" value="<?php echo "9pHiFPlx"; ?>">
		<input type="text" name="txnid" placeholder="txnid" value="<?php echo $_SESSION['payumoney_txnid']; ?>">
		<input type="text" name="amount" placeholder="amount" value="<?php echo $_SESSION['payumoney_order_total']; ?>">
		<input type="text" name="productinfo" placeholder="productinfo" value="OMR - Football">
		<input type="text" name="firstname" placeholder="firstname" value="<?php echo $_SESSION['customer_name']; ?>">
		<input type="text" name="email" placeholder="email" value="<?php echo $_SESSION['customer_email']; ?>">
		<input type="text" name="phone" placeholder="phone" value="<?php echo $_SESSION['customer_mobile']; ?>">
		<input type="text" name="surl" placeholder="surl" value="https://omrsportsarena.com/success.php">
		<input type="text" name="furl" placeholder="furl" value="https://omrsportsarena.com/failure.php">
		<input type="text" name="hash" placeholder="hash" value="">
		<input type="text" name="service_provider" placeholder="service_provider" value="payu_paisa">
	</form>
</body>

<?php
}
else
{
	echo "<script>window.location.href='index.php'</script>";
}
?>