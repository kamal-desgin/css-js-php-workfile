<?php
//session_start();
include("config.php");

$con = new mysqli($host,$user,$pass,$db_name) or die(mysql_error());

//if(isset($_SESSION['slot_data']))
	//echo "<script>window.location.href='logout.php?booking=1';</script>";
?>
<script>
function book_hover(a,b)
{
	//alert(b);
	document.getElementById("book_td_"+a+"_"+b).innerHTML = "<img src='images/hold.png' class='wm_iicon wm_ii_sel'>";
}
function book_out(a,b)
{
	//alert(b);
	document.getElementById("book_td_"+a+"_"+b).innerHTML = "<img src='images/student_available.png' class='wm_iicon wm_ii_sel'>";
}

function add_slot(a,b)
{
	var sdate = document.getElementById("show_sdate").value;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("book_td_"+a+"_"+b).innerHTML = this.responseText;
			document.getElementById("book_td_"+a+"_"+b).innerHTML = "<a class='wm_ii_av' onclick='delete_slot("+a+","+b+");'><img src='checkbox/student_selected.png' width='20' class='wm_iicon wm_ii_sel'>";
			load_cart(a);
		}
	};
	xmlhttp.open("GET","ajax_add_slot.php?court_id="+a+"&time="+b+"&sdate="+sdate,true);
	xmlhttp.send();
}

function delete_slot(a,b)
{
	var sdate = document.getElementById("show_sdate").value;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			//document.getElementById("ccart_td").innerHTML = this.responseText;
			document.getElementById("book_td_"+a+"_"+b).innerHTML = "<a class='wm_ii_av' onclick='add_slot("+a+","+b+");'><img src='checkbox/student_available.png' width='20' class='wm_iicon wm_ii_sel'>";
			load_cart(a);
		}
	};
	xmlhttp.open("GET","ajax_delete_slot.php?court_id="+a+"&time="+b+"&sdate="+sdate+"&no_table=1",true);
	xmlhttp.send();
}

function clear_booking(court_id) {
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			//document.getElementById("booking_slots").innerHTML = this.responseText;
			document.getElementById("cart_price").innerHTML = "";
			load_booking(court_id);
		}
	};
	xmlhttp.open("GET","ajax_clear_booking.php",true);
	xmlhttp.send();
}
function load_booking(court_id)
{
	var sdate = document.getElementById("show_sdate").value;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("booking_slots").innerHTML = this.responseText;
		}
	};
	xmlhttp.open("GET","ajax_booking.php?court_id="+court_id+"&sdate="+sdate,true);
	xmlhttp.send();
}
function load_cart(court_id)
{
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("cart_price").innerHTML = this.responseText;
		}
	};
	
	xmlhttp.open("GET","ajax_cart.php?court_id="+court_id,true);
	xmlhttp.send();
}

function load_date_to()
{
	var val = document.getElementById("show_sdate").value;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("show_sdate").value = this.responseText;
		}
	};
	xmlhttp.open("GET","ajax_date_to.php?show_sdate="+val,true);
	xmlhttp.send();
}

function booking_slots_view()
{
	var sdate = document.getElementById("show_sdate").value;
	var edate = document.getElementById("show_edate").value;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("booking_slots").innerHTML = this.responseText;
		}
	};
	xmlhttp.open("GET","ajax_booking_slots.php?sdate="+sdate+"&edate="+edate,true);
	xmlhttp.send();
}
</script>
<!-- Blog Single Start Here -->

<!-- date -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.min.js"></script>
<script>
	$("input[type=date]").on("change", function() {
		this.setAttribute(
			"data-date",
			moment(this.value, "YYYY-MM-DD")
			.format( this.getAttribute("data-date-format") )
		)
	}).trigger("change")
</script>

<!-- date -->


<!-- FORM START HERE-->
				<div class="form-group">
					<?php
						$sel_cm = "select id from $court_master_table where status='A' order by sno asc limit 1";
						$res_cm = $con->query($sel_cm) or die(mysqli_error($con));
						$data_cm = $res_cm->fetch_array();
						$first_court_id = $data_cm['id'];
					?>
					
					<div class="col-md-12 col-sm-12 col-xs-12 mtb-10">
							<div class="form-group">
								<label class="col-md-2 control-label">Select Date </label>
								<div class="col-md-4 inputGroupContainer">								 
									<div class="input-group">									
										<input  type="date" data-date="" data-date-format="DD-MM-YYYY" class="form-control  boot-dp" name="show_sdate" id="show_sdate" placeholder="Select Date" autocomplete="off" value="<?php echo date('d-m-Y'); ?>" />
										<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
									</div>
								</div>
								<div class="col-md-2 inputGroupContainer">
									<div class="input-group">
										<a class="btn btn-success" onclick="load_date_to();clear_booking(<?php echo $first_court_id; ?>);">View Date</a>
									</div>
								</div>
								<label class="col-md-2 control-label">( S for Seat )</label>
							</div>
					</div>
					
				</div>
			
			<div id="booking_slots">
				<?php
				//Court Display (Menu)
				$sel_cm = "select * from $court_master_table where status='A' order by sno asc";
				$res_cm = $con->query($sel_cm) or die(mysqli_error($con));
				$c = 0;
				//echo "<ul class='wm_ul'>";
				while($data_cm = $res_cm->fetch_array())
				{
					/*$c++;
					if($c == 1)
					{
						$_SESSION['court_id'] = $data_cm['id'];
						echo "<li><a onclick='clear_booking(".$data_cm['id'].");' class='wm_active'>$data_cm[name]</a></li>";
					}
					else
						echo "<li><a onclick='clear_booking(".$data_cm['id'].");'>$data_cm[name]</a></li>";*/
					$court_id_array[] = $data_cm['id'];
					$court_name_array[] = $data_cm['name'];
				}
				//echo "</ul>";
				?>

				<?php
				//Booking Slots CODE
				$sel_q = "select * from $settings_table where id=1";
				$sel_res = $con->query($sel_q) or die(mysqli_error($con));
				$sel_data = $sel_res->fetch_array();

				/*$d1 = explode("/",$sel_data['book_sdate']);
				$d2 = explode("/",$sel_data['book_edate']);

				$s_date = $d1[2]."-".$d1[1]."-".$d1[0];
				$e_date = $d2[2]."-".$d2[1]."-".$d2[0];*/

				$s_date = date('Y-m-d');

				//for($l=1;$l<=$display_days;$l++)
				foreach($court_id_array as $kk => $vv)
				{
					//$day = $l-1;
					//$next_day = date("Y-m-d", strtotime("+ $day day",$start_date));
					$next_day = $s_date;

					$select_query = "select * from $booking_schedule_table where booked_date='$next_day' and court_id='$vv'";
					$result = $con->query($select_query) or die(mysqli_error($con));
					if($result->num_rows > 0)
					{
						$data = $result->fetch_array();

						for($z=1;$z<=24;$z++)
						{
							$h[$vv][$z] = $data['h'.$z];
						}
					}
					else
					{
						for($z=1;$z<=24;$z++)
						{
							$h[$vv][$z] = 0;
						}
					}
				}
			?>
			<div class="table table-responsive">
				<table class="table table-bordered">
					<tr>
						<th style="width:120px;" class="thead">Time</th>
						<?php
						foreach($court_id_array as $kk => $vv)
						{
							echo "<th class='thead'>$court_name_array[$kk]</th>";
						}
						?>
					</tr>
					<?php
					$clr = 1;
					for($i=0;$i<=20;$i++)
					{
						if($i == 0)
							$i = 5;

						if($i > 12 && $i != 24)
							$time = ($i-12).".00 PM";
						elseif($i == 12)
							$time = $i.".00 PM";
						elseif($i == 24)
							$time = ($i-12).".00 AM";
						else
							$time = $i.".00 AM";
						?>
						
						<tr class="bg_tr<?php echo $clr; ?>">
							<td style="text-align:center;"><?php echo $time; ?></td>
							<?php
							$clr *= -1;
							//for($l=1;$l<=$display_days;$l++)
							foreach($court_id_array as $kk => $vv)
							{
								if($i == 24)
									$icheck = 0;
								else
									$icheck = $i;

								if($icheck > date('H'))
								{
									if($h[$vv][$i] == 0)
									{
										if(isset($_SESSION['slot_data']))
										{
											if (in_array($vv."_".$i, $_SESSION['slot_data']))
												echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="delete_slot('.$vv.','.$i.');"><img src="checkbox/selected.png" width="20" class="wm_iicon"></a></td>';
											else
												echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="add_slot('.$vv.','.$i.');"><img src="checkbox/student_available.png" width="20" class="wm_iicon"></a></td>';
										}
										else
											echo '<td id="book_td_'.$vv.'_'.$i.'"><a  class="wm_ii_av" onclick="add_slot('.$vv.','.$i.');"><img src="checkbox/student_available.png" width="20" class="wm_iicon"></a></td>';
									}
									else
									{
										echo '<td><img src="checkbox/student_booked.png" class="wm_iicon wm_ii_bo" title="Booked"></td>';
									}
								}
								else
								{
									echo '<td><img src="checkbox/unavailable.png" width="20" class="wm_iicon wm_ii_bo" title="Booked"></td>';
								}
							}
							?>
						</tr>
						<?php
						if($i == 24)
							$i = 0;
					}
					?>
				</table>
			</div> <!--- table END--->
		</div>
		
  


	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
	
	<script type="text/javascript">
		// When the document is ready
		$(document).ready(function () {
			var date = new Date();
			date.setDate(date.getDate());
			$('.boot-dp').datepicker({
				format: "dd-mm-yyyy",
				autoclose: false,
				startDate: date
			});
		});
	</script>
