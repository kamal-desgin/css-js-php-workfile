<?php
session_start();

$sdate = $_GET['sdate'];
$court_id = $_GET['court_id'];
$time = $_GET['time'];

$_SESSION['slot_data'][] = $court_id."_".$time;
$_SESSION['slot_date'] = $_GET['sdate'];
$_SESSION['slot_time'][] = $time;
$_SESSION['slot_court_id'][] = $court_id;


?>