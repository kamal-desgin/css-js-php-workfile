<?php

// When we unzipped PHPMailer, it unzipped to
// public_html/PHPMailer_5.2.0

require("lib/PHPMailer/PHPMailerAutoload.php");
$mail = new PHPMailer();

// set mailer to use SMTP
$mail->IsSMTP();

// we are setting the HOST to localhost
$mail->Host = "mail.example.com";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication

// When sending email using PHPMailer, you need to send from a valid email address
// In this case, we setup a test email account with the following credentials:
$mail->Username = "user@gmail.com";  // SMTP username
$mail->Password = "password"; // SMTP password

$mail->From = "from@example.com";

// below we want to set the email address we will be sending our email to.
$mail->AddAddress("to@example.com", "To whom");

// set word wrap to 50 characters
$mail->WordWrap = 50;
// set email format to HTML
$mail->IsHTML(true);

$mail->Subject = "You have received feedback from your website!";
$message = "Text Message";
$mail->Body    = $message;
$mail->AltBody = $message;

if(!$mail->Send())
{
   echo "Message could not be sent. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}

echo "Message has been sent";
?>