<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  

	<style>
		.btn-success {
   background-color: #65B688;
   border-color: #65B688;
   }
   .btn-danger {
   color: #fff;
   background-color: #d9534f;
   border-color: #d43f3a;
   }
   .btn {
   color: white;
   display: inline-block;
   margin-bottom: 0;
   font-weight: 400;
   text-align: center;
   vertical-align: middle;
   cursor: pointer;
   background-image: none;
   border: 1px solid transparent;
   white-space: nowrap;
   padding: 6px 12px;
   font-size: 14px;
   line-height: 1.42857143;
   border-radius: 4px;
   -webkit-user-select: none;
   -moz-user-select: none;
   -ms-user-select: none;
   user-select: none;
   }
	</style>
  
  </head>
  <body>
	
	<div class="container">
		<div class="row">
			<div class='col-md-5'>
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>SNO</th>
							<th>REGNO</th>
							<th>NAME</th>
							<th>STATUS</th>
						</tr>
					</thead>						
				 <tbody>
					<?php
					$con=new mysqli("localhost","root","","dynamic");
					$fetchqry = "SELECT * FROM user";  // active and expired date
					
					
					$result=mysqli_query($con,$fetchqry);
					$num=mysqli_num_rows($result);
					while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
						{ 
						?>
						   <tr>
								<td><?php echo $row['id'];?></td>
								<td><?php echo $row['name'];?></td>
								<td><?php echo $row['email'];?></td>
								<td><i data="<?php echo $user['id'];?>" class="status_checks btn 
									 <?php echo ($row['status'])? 'btn-success' : 'btn-danger'?>">
									 <?php echo ($row['status'])? 'Active' : 'Inactive'?></i></td>
						   </tr>	
						  <?php 
						  } 
						  ?>
				</tbody>
			</div>
		</div>
	</div>
  
 
  
	<script type="text/javascript">
		$(document).on('click','.status_checks',function(){
			//alert("hi");
		
		  var status = ($(this).hasClass("btn-success")) ? '0' : '1';
		  var msg = (status=='0')? 'Deactivate' : 'Activate';
		  if(confirm("Are you sure to "+ msg)){
			var current_element = $(this);
			url = "ajax.php";
			$.ajax({
			  type:"POST",
			  url: url,
			  data: {id:$(current_element).attr('data'),status:status},
			  success: function(data)
			  {   
				location.reload();
			  }
			});
		  }      
		});
	</script>
  </body>
</html>