<?php
	$status = 'y';
?>
<div id="status">
	<a href="#" onClick="changestatus('<?php echo $status; ?>')">Deactive</a>
</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
	function changestatus(status) {
		var p_url= "post.php";
		jQuery.ajax({
			type: "GET",
			url: p_url,
			data: "status=" + status,
			success: function(data) {
				if(data == 1){
					$('#status').html('<a href="#" onClick="changestatus(\'n\')">Active</a>');
					} else {
					$('#status').html('<a href="#" onClick="changestatus(\'y\')">deactive</a>');
				}
			}
		});
	}
</script>