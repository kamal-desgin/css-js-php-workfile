<?php
$status = $_GET['status'];
if($status == 'y') {
echo "1";
} else {
echo " 0";
}
 
?>