//Quotation Section START
 $(document).ready(function(){
	
	 $("span").closest("ul").css({"color": "red", "border": "2px solid red"});
	// $(".invoiceItem").closest(".billing_table").css({"color": "red", "border": "2px solid red"});
	 $("table").closest(".invoiceItem").css({"color": "red", "border": "2px solid red"});


	$(document).on('click', '#checkAll', function() {          	
		$(".itemRow").prop("checked", this.checked);
	});	
	$(document).on('click', '.itemRow', function() {  	
		if ($('.itemRow:checked').length == $('.itemRow').length) {
			$('#checkAll').prop('checked', true);
		} else {
			$('#checkAll').prop('checked', false);
		}
	});  
	var count = $(".itemRow").length;
	$(document).on('click', '#addRows', function(event) { 
		event.preventDefault();
		count++;
		var htmlRows = '';
		htmlRows += '<tr>';
		htmlRows += '<td><input class="itemRow" type="checkbox"></td>';          
		htmlRows += '<td><input type="text" name="worksno[]" id="worksno_'+count+'" class="form-control" autocomplete="off"></td>';          
		htmlRows += '<td><input type="text" name="workName[]" id="workName_'+count+'" class="form-control" autocomplete="off"></td>';	
		htmlRows += '<td><input type="number" pattern= "[0-9]" name="quantity[]" id="quantity_'+count+'" class="form-control quantity" autocomplete="off"></td>';   		
		htmlRows += '<td><input type="number" pattern= "[0-9]" name="price[]" id="price_'+count+'" class="form-control" autocomplete="off"></td>';		 
		htmlRows += '<td><input type="number" pattern= "[0-9]" name="total[]" id="total_'+count+'" class="form-control total" autocomplete="off" readonly /></td>';          
		htmlRows += '<td hidden><input type="number" pattern= "[0-9]" name="Hprice[]" id="Hprice_'+count+'" class="form-control" autocomplete="off"></td>';		 
		htmlRows += '<td hidden><input type="number" pattern= "[0-9]" name="Htotal[]" id="Htotal_'+count+'" class="form-control total" autocomplete="off" readonly /></td>';          
		htmlRows += '<td hidden><input type="number" pattern= "[0-9]" name="Aprice[]" id="Aprice_'+count+'" class="form-control" autocomplete="off"></td>';		 
		htmlRows += '<td hidden><input type="number" pattern= "[0-9]" name="Atotal[]" id="Atotal_'+count+'" class="form-control total" autocomplete="off" readonly /></td>';          
		
		htmlRows += '</tr>';
		//$(this).append(htmlRows).closest('.invoiceItem').find('table');
		$('.invoiceItem').append(htmlRows).closest('.billing_table').find('table');
	}); 
	$(document).on('click', '#removeRows', function(){
		$(".itemRow:checked").each(function() {
			$(this).closest('tr').remove();
		});
		$('#checkAll').prop('checked', false);
		calculateTotal();
		HcalculateTotal();
		AcalculateTotal();
		
	});		
	$(document).on('blur', "[id^=quantity_]", function(){
		calculateTotal();
		HcalculateTotal();
		AcalculateTotal();
	});	
	$(document).on('blur', "[id^=price_]", function(){
		calculateTotal();
		HcalculateTotal();
		AcalculateTotal();
	});	
	$(document).on('blur', "#taxRate", function(){		
		calculateTotal();
		HcalculateTotal();
		AcalculateTotal();
	});		
});	

function calculateTotal(){
	var totalAmount = 0; 
	$("[id^='price_']").each(function() {
		var id = $(this).attr('id');
		id = id.replace("price_",'');
		var price = $('#price_'+id).val();
		var quantity  = $('#quantity_'+id).val();
		if(!quantity) {
			quantity = 1;
		}
		var total = price*quantity;
		$('#total_'+id).val(parseFloat(total));
		totalAmount += total;			
	});
	
	$('#subTotal').val(parseFloat(totalAmount));	
	var discount = $("#discount").val();
	var taxRate = $("#taxRate").val();
	var subTotal = $('#subTotal').val();	
	if(subTotal) {
		var taxAmount = subTotal*taxRate/100;
		//tax divide in Amount
		var taxDivision = taxAmount/2;
		var taxCgst =  taxDivision;
		$('#taxCgst').val(taxCgst);
		var taxSgst =  taxDivision;
		$('#taxSgst').val(taxSgst); 
		
		subTotal = parseFloat(subTotal)+ parseFloat(taxAmount);
		var subTotalRound = Math.round(subTotal);
		$('#totalAftertax').val(subTotalRound);	
	}
}
function HcalculateTotal(){
	var HtotalAmount = 0; 
	$("[id^='price_']").each(function() {
		var id = $(this).attr('id');
		id = id.replace("price_",'');
		var price = $('#price_'+id).val();
		var quantity  = $('#quantity_'+id).val();
		if(!quantity) {
			quantity = 1;
		}
		var quotationrate = price*quantity/100;
		var qotationrateAdd = quotationrate/8;
		
		HpriceAdd = parseFloat(price)+ parseFloat(qotationrateAdd);
		var Hprice = Math.round(HpriceAdd);
		$('#Hprice_'+id).val(parseFloat(Hprice));
		
		var total = Hprice *quantity;
		var Htotal = Math.round(total);
		$('#Htotal_'+id).val(parseFloat(Htotal));
		HtotalAmount += total;		
	});
	
	$('#HsubTotal').val(parseFloat(HtotalAmount));	
	var HtaxRate = $("#taxRate").val();
	$('#HtaxRate').val(HtaxRate);
	var HsubTotal = $('#HsubTotal').val();	
	if(HsubTotal) {
		var HtaxAmount = HsubTotal*HtaxRate/100;
		//tax divide in Amount
		var HtaxDivision = HtaxAmount/2;
		var HtaxCgst =  HtaxDivision;
		$('#HtaxCgst').val(HtaxCgst);
		var HtaxSgst =  HtaxDivision;
		$('#HtaxSgst').val(HtaxSgst); 
		
		HsubTotal = parseFloat(HsubTotal)+ parseFloat(HtaxAmount);
		var HsubTotalRound = Math.round(HsubTotal);
		$('#HtotalAftertax').val(HsubTotalRound);	
	}
}

function AcalculateTotal(){
	var AtotalAmount = 0; 
	$("[id^='price_']").each(function() {
		var id = $(this).attr('id');
		id = id.replace("price_",'');
		var price = $('#price_'+id).val();
		var quantity  = $('#quantity_'+id).val();
		if(!quantity) {
			quantity = 1;
		}
		var quotationrate = price*quantity/100;
		var qotationrateAdd = quotationrate/4;
		
		ApriceAdd = parseFloat(price)+ parseFloat(qotationrateAdd);
		var Aprice = Math.round(ApriceAdd);
		$('#Aprice_'+id).val(parseFloat(Aprice));
		
		var total = Aprice *quantity;
		var Atotal = Math.round(total);
		$('#Atotal_'+id).val(parseFloat(Atotal));
		AtotalAmount += total;		
	});
	
	$('#AsubTotal').val(parseFloat(AtotalAmount));	
	var AtaxRate = $("#taxRate").val();
	$('#AtaxRate').val(AtaxRate);
	var AsubTotal = $('#AsubTotal').val();	
	if(AsubTotal) {
		var AtaxAmount = AsubTotal*AtaxRate/100;
		//tax divide in Amount
		var AtaxDivision = AtaxAmount/2;
		var AtaxCgst =  AtaxDivision;
		$('#AtaxCgst').val(AtaxCgst);
		var AtaxSgst =  AtaxDivision;
		$('#AtaxSgst').val(AtaxSgst); 
		
		AsubTotal = parseFloat(AsubTotal)+ parseFloat(AtaxAmount);
		var AsubTotalRound = Math.round(AsubTotal);
		$('#AtotalAftertax').val(AsubTotalRound);	
	}
}



//Quotation Section END
