
CREATE TABLE IF NOT EXISTS `status_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `age` varchar(150) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
);
--
-- Dumping data for table `student`
--

INSERT INTO `status_check` (`id`, `name`, `age`, `contact`, `city`,`status`) VALUES
(1, 'kamal`', 28, '7418823014', 'Arni',1),
(2, 'sakthivel', 22, '8122385852', 'Arni',1),
(7, 'Akash', 20, '9094089458', 'Chennai',1),
(8, 'Arun', 28, '8122385852', 'Vellore',1);