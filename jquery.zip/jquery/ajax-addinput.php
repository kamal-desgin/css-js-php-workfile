<?php
$id = $_GET['id'];
$id++;

?>
<fieldset>
	<div class="form-group col-md-4">
		<label for="Name">Name</label>
		<input type="text" class="form-control"  />
	</div>
	<div class="form-group col-md-4">
		<label for="Name">Email</label>
		<input type="text" class="form-control"  />
	</div>
	<div class="form-group col-md-4">
		<label for="contact">Contact</label>
		<div class="input-group">
		   <div class="input-group-btn">
			   <button class="btn btn-danger" type="button" onclick="del_info(<?php echo $id-1;?>);"><i class="fa fa-minus"></i></button>
		   </div>	
		   <input type="text" class="form-control"  />
		</div>
	</div>
</fieldset>