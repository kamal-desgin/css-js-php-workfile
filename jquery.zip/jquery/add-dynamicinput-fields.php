<!DOCTYPE html>
<html lang="en">
	<head>
	  <title>Bootstrap Example</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
	  
	  <script>
		$(function() {
	  $('.datepicker').datepicker();
	});
	  </script>
	  
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">				
					<h3>Dynamic input field AJax Method </h3>
					<form>
						<?php
							for($i=1;$i<=5;$i++)
							{
							?>
								<div id="Adddynamic_div<?php echo $i; ?>">
								</div>
							<?php
							}
						?>
						
						<fieldset>
							<div class="form-group col-md-4">
								<label for="Name">Name</label>
								<input type="text" class="form-control"  />
							</div>
							<div class="form-group col-md-4">
								<label for="Name">Email</label>
								<input type="text" class="form-control"  />
							</div>
							<div class="form-group col-md-4">
								
							   <input type='hidden' name='Add_count' id="Add_count" value='1' /><!--Add Div Count-->
							   <label for="contact">Contact</label>
							   <div class="input-group">
								   <div class="input-group-btn">
									   <button class="btn btn-success" type="button"  id="Add_plus_1"  onclick="add_info(1);"><i class="fa fa-plus"></i></button>
								   </div>	
								   <input type="text" class="form-control"  />
							   </div>
						  	</div>
						</fieldset>
					  <button type="submit" class="btn btn-primary btn-md">Submit</button>
					</form>					
				</div>
				
				
				<script>
					function add_info()
					{
						var id = Number(document.getElementById("Add_count").value);
						if (window.XMLHttpRequest) {
							// code for IE7+, Firefox, Chrome, Opera, Safari
							xmlhttp = new XMLHttpRequest();
						} else {
							// code for IE6, IE5
							xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
						}
						xmlhttp.onreadystatechange = function() {
							if (this.readyState == 4 && this.status == 200) {
								document.getElementById("Adddynamic_div"+id+"").innerHTML = this.responseText;
								document.getElementById("Add_count").value = id+1;
							}
						};
						xmlhttp.open("GET","ajax-addinput.php?id="+id,true);
						xmlhttp.send();
					}
					function del_info(kid)
					{
						//dkid = kid - 1;
						document.getElementById("Adddynamic_div"+kid).innerHTML = "";
						if(Number(document.getElementById("Add_count").value)-1 == kid)
							document.getElementById("Add_plus_"+kid).style.display = "inline-table";
					}
				</script>
			</div>
		</div>
	</body>
</html>