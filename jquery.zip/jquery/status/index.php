<?php
    include('processing.php');
    $newobj = new processing();
?>
<html>
    <head>
        <title>Jquery Ajax select <tag> with PHP Mysql</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    </head>
    <body>
        <table border="1">
            <tr>
                <th>Id</th>
                <th>Product name</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php echo $newobj->display();?>
        </table>
        <script>
            $(document).ready(function(){
                $(".selectstatus").change(function(){
                    var statusname = $(this).val();
                    var getid = $(this).attr("status-id");
                    //alert(displid);

                    $.ajax({
                        type:'POST',
                        url:'ajaxreceiver.php',
                        data:{statusname:statusname,getid:getid},
                        success:function(result){
                           // $("#display").html(result);
							$("#display", $(this).parent().parent()).html(result);
							$("#display_" + getid).html(result);
                        }
                    });
                });
            });
        </script>
		<script>
		 /*  $(document).ready(function(){
					$(".selectstatus").change(function(){
						// make jquery object that make reference to select in which click event is clicked
						$this = $(this);
						var statusname = $(this).val();
						var getid = $(this).attr("status-id");
						//alert(displid);

						$.ajax({
							type:'POST',
							url:'ajaxreceiver.php',
							data:{statusname:statusname,getid:getid},
							success:function(result){
								// this refer to the ajax callback function so we have to use $this which is initialized before ajax call
								$($this).parents('tr').find("#display").html(result);
							}
						});
					});
				}); */
			</script>
    </body>
</html>