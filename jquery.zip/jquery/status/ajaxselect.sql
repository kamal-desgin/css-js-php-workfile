
CREATE TABLE IF NOT EXISTS `ajaxselect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
);
--
-- Dumping data for table `student`
--

INSERT INTO `ajaxselect` (`id`, `productname`, `status`) VALUES
(1, 'Jeera','Delivered'),
(2, 'Egg Rice','Cancelled'),
(7, 'pav bhaji','Cancelled'),
(8, 'girmit','Amount Paid');