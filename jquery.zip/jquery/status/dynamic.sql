-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2020 at 08:28 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dynamic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'user_ms', 'Microshare');

-- --------------------------------------------------------

--
-- Table structure for table `ajaxselect`
--

CREATE TABLE IF NOT EXISTS `ajaxselect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `ajaxselect`
--

INSERT INTO `ajaxselect` (`id`, `productname`, `status`) VALUES
(1, 'Jeera', 'Delivered'),
(2, 'Egg Rice', 'Delivered'),
(7, 'pav bhaji', 'Amount Paid'),
(8, 'girmit', 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `title`, `content`) VALUES
(1, 'Testing Ganjar', '<p>dscscdsc</p><p>sdcsdc</p><p>sdcsd</p><p>dscsdc</p><p>csdcsdcsdcsdcsdcsdcdsc</p>'),
(4, 'COba in testing', '<pre><i>sdcsdc<br></i><font color="#ff0000" style="background-color: yellow;">dscsdc<br></font>sdcsdc<br><b>sdcsd</b></pre><p>csdcsdcdsc</p><p>dscsd</p><p>dcsdcsdcsdcsdcsdc</p>'),
(5, 'Sains & Teknologi', '<p>Hallo Thank you for visitong <a href="http://teknosains.com" target="_blank">Sains &amp; Teknologi</a>&nbsp;</p><p>Have a nice day</p>'),
(6, 'Hold on kid, this girl is mine', '<p><b><font color="#311873">It is a long</font></b> established fact that a reader will be distracted by <b><font color="#ff0000">the readable content of a page</font></b> when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors <b>now use Lorem Ipsum</b> as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. <b><i>Various versions have</i></b> evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).&nbsp;</p><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', <i><u>making it look like readable English</u></i>. Many desktop publishing packages and web page editors now use <span style="background-color: rgb(255, 156, 0);">Lorem Ipsum </span>as their default model text, and a <font color="#ff9c00">search for ''lorem ipsum'' </font>will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).&nbsp;</p><p><font color="#ff0000">It is a long established fact that a reader</font> will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use<b> Lorem Ipsum as their default model text, </b>and a search for ''lorem ipsum'' will uncover many web sites still in their <a href="http://teknosains.com" target="_blank">infancy</a>. Various versions have evolved over the years, sometimes by accident, sometimes on purpose <b><font color="#ff00ff">(injected humour and the like).&nbsp;</font></b><br></p>'),
(7, 'Simon Si Peniup Salju', '<h3><span style="line-height: 1.42857143;">Holaaaaaaaaaaaa</span></h3><p><span style="line-height: 1.42857143;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. Various versions have evolved over the years, <b><font color="#9c00ff">sometimes by accident, sometimes on purpose (injected humour and the like).</font></b></span><br></p>');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(30) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`, `reg_date`) VALUES
(1, 'wedding', '2019-07-29 13:51:22'),
(2, 'birthday', '2019-07-29 13:51:22'),
(3, 'outdoor', '2019-07-29 13:51:44'),
(4, 'candid', '2019-07-29 13:51:44'),
(5, 'reception', '2019-07-29 13:52:36'),
(6, 'postwedding', '2019-07-29 13:52:36');

-- --------------------------------------------------------

--
-- Table structure for table `countrylist`
--

CREATE TABLE IF NOT EXISTS `countrylist` (
  `sno` int(10) NOT NULL AUTO_INCREMENT,
  `districts` varchar(265) NOT NULL,
  `state` varchar(265) NOT NULL,
  `country` varchar(265) NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `countrylist`
--

INSERT INTO `countrylist` (`sno`, `districts`, `state`, `country`) VALUES
(1, 'Ariyalur', 'Tamilnadu', 'India'),
(2, 'Karur', 'Tamilnadu', 'India'),
(3, 'Nagapattinam', 'Tamilnadu', 'India'),
(4, 'Perambalur', 'Tamilnadu', 'India'),
(5, 'Pudukkottai', 'TamilNadu', 'India'),
(6, 'Thanjavur', 'Tamilnadu', 'India'),
(7, 'Tiruchirappalli', 'Tamilnadu', 'India'),
(8, 'Tiruvarur', 'Tamilnadu', 'India'),
(9, 'Dharmapuri', 'Tamilnadu', 'India'),
(10, 'Coimbatore', 'Tamilnadu', 'India'),
(11, 'Erode', 'Tamilnadu', 'India'),
(12, 'Krishnagiri', 'Tamilnadu', 'India'),
(13, 'Namakkal', 'Tamilnadu', 'India'),
(14, 'The Nilgiris', 'Tamilnadu', 'India'),
(15, 'Salem', 'Tamilnadu', 'India'),
(16, 'Tiruppur', 'Tamilnadu', 'India'),
(17, 'Dindigul', 'Tamilnadu', 'India'),
(18, 'Kanyakumari', 'Tamilnadu', 'India'),
(19, 'Madurai', 'Tamilnadu', 'India'),
(20, 'Ramanathapuram', 'Tamilnadu', 'India'),
(21, 'Sivaganga', 'Tamilnadu', 'India'),
(22, 'Theni', 'Tamilnadu', 'India'),
(23, 'Thoothukudi', 'Tamilnadu', 'India'),
(24, 'Tirunelveli', 'Tamilnadu', 'India'),
(25, 'Virudhunagar', 'TamilNadu', 'India'),
(26, 'Chennai', 'Tamilnadu', 'India'),
(27, 'Cuddalore', 'Tamilnadu', 'India'),
(28, 'Kanchipuram', 'Tamilnadu', 'India'),
(29, 'Tiruvallur', 'Tamilnadu', 'India'),
(30, 'Tiruvannamalai', 'Tamilnadu', 'India'),
(31, 'Vellore', 'Tamilnadu', 'India'),
(32, 'Viluppuram', 'Tamilnadu', 'India'),
(33, 'Alappuzha', 'Kerala', 'India'),
(34, 'Ernakulam', 'Kerala', 'India'),
(35, 'Idukki', 'Kerala', 'India'),
(36, 'Kannur', 'Kerala', 'India'),
(37, 'Kasaragod', 'Kerala', 'India'),
(38, 'Kollam', 'Kerala', 'India'),
(39, 'Kottayam', 'Kerala', 'India'),
(40, 'Kozhikode', 'Kerala', 'India'),
(41, 'Malappuram', 'Kerala', 'i'),
(42, 'Palakkad', 'Kerala', 'India'),
(43, 'Pathanamthitta', 'Kerala', 'India'),
(44, 'Thiruvananthapuram', 'Kerala', 'India'),
(45, 'Thrissur', 'Kerala', 'India'),
(46, 'Wayanad', 'Kerala', 'India'),
(47, 'Bengaluru Urban', 'Bengaluru', 'India'),
(48, 'Bagalkot', 'Bengaluru', 'India'),
(49, 'Bellary', 'Bengaluru', 'India'),
(50, 'Chamarajanagar', 'Bengaluru', 'India'),
(51, 'Bengaluru Rural', 'Bengaluru', 'India'),
(52, 'Belgaum Bidar ', 'Bengaluru', 'India'),
(53, 'Chikkamagaluru', 'Bengaluru', 'India'),
(54, 'Chikkaballapur', 'Bengaluru', 'India'),
(55, 'Vijayapura', 'Bengaluru', 'India'),
(56, 'Kalaburagi', 'Bengaluru', 'India'),
(57, 'Dakshina Kannada', 'Bengaluru', 'India'),
(58, 'Chitradurga', 'Bengaluru', 'India'),
(59, 'Dharwad Koppal', 'Bengaluru', 'India'),
(60, 'Hassan', 'Bengaluru', 'India'),
(61, 'Davanagere', 'Bengaluru', 'India'),
(62, 'Gadag', 'Bengaluru', 'India'),
(63, 'Raichur Kodagu', 'Bengaluru', 'India'),
(64, 'Kolar', 'Bengaluru', 'India'),
(65, 'Haveri', 'Bengaluru', 'India'),
(66, 'Yadgir', 'Bengaluru', 'India'),
(67, 'Mandya', 'Bengaluru', 'India'),
(68, 'Ramanagara', 'Bengaluru', 'India'),
(69, 'Uttara Kannada', 'Bengaluru', 'India'),
(70, 'Mysuru', 'Bengaluru', 'India'),
(71, 'Shivamogga', 'Bengaluru', 'India'),
(72, 'Udupi', 'Bengaluru', 'India'),
(73, 'Tumakuru', 'Bengaluru', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `COURSE` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`ID`, `COURSE`) VALUES
(1, 'HTML'),
(2, 'HTMl'),
(3, 'CSS'),
(4, 'PHP'),
(5, 'Jquery'),
(6, 'java'),
(7, 'python'),
(8, 'check'),
(9, 'check');

-- --------------------------------------------------------

--
-- Table structure for table `crud`
--

CREATE TABLE IF NOT EXISTS `crud` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(65) NOT NULL,
  `AGE` int(10) NOT NULL,
  `CITY` varchar(65) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `crud`
--

INSERT INTO `crud` (`ID`, `NAME`, `AGE`, `CITY`) VALUES
(8, ' sakthivel', 28, '  Arni  '),
(9, ' Sathish ', 25, ' Arni '),
(11, ' anbu 2', 25, ' Arni '),
(12, 'abi ', 25, 'arni'),
(14, 'Kamal', 28, 'Arni'),
(17, 'akash', 22, 'chennai'),
(18, 'Raji', 20, 'Arni');

-- --------------------------------------------------------

--
-- Table structure for table `datas`
--

CREATE TABLE IF NOT EXISTS `datas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `logs` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `datas`
--

INSERT INTO `datas` (`id`, `comment`, `logs`) VALUES
(1, 'The Mulligan Concept method of manual therapy was discovered and developed by a physiotherapist from New Zealand. ', '2019-06-06 06:02:06'),
(3, 'The Mulligan concept has evolved over the years and is today taught as a separate course in various countries by accredited teachers certified', '2019-06-06 06:03:26'),
(4, 'he uniqueness of this method of treatment is the painless way in which the treatment is applied and the fast response of the symptoms to the treatment delivered.', '2019-06-06 06:03:36'),
(5, 'This method is not just for the therapeutic part but is also an effective diagnostic tool.', '2019-06-06 06:03:49'),
(6, 'The Mulligan concept has evolved over the years and is today taught as a separate course in various countries by', '2019-06-06 06:19:51'),
(7, ' treatment procedures. This method is not just for the therapeutic part but is also an effective diagnostic tool.', '2019-06-06 06:20:33');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `Sno` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(65) NOT NULL,
  `Age` int(10) NOT NULL,
  `Mail` varchar(65) NOT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `details`
--


-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE IF NOT EXISTS `districts` (
  `districts_id` int(10) NOT NULL AUTO_INCREMENT,
  `districts_name` varchar(265) NOT NULL,
  `state_id` int(10) NOT NULL,
  PRIMARY KEY (`districts_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`districts_id`, `districts_name`, `state_id`) VALUES
(1, 'Ariyalur', 1),
(2, 'Karur', 1),
(3, 'Nagapattinam', 1),
(4, 'Perambalur', 1),
(5, 'Pudukkottai', 1),
(6, 'Alappuzha', 2),
(7, 'Ernakulam', 2),
(8, 'Idukki', 2),
(9, 'Kannur', 2),
(10, 'Kasaragod', 2),
(11, 'Bengaluru Urban', 3),
(12, 'Bagalkot', 3),
(13, 'Bellary', 3),
(14, 'Chamarajanagar', 3),
(15, 'Bengaluru Rural', 3);

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE IF NOT EXISTS `emp` (
  `empno` int(11) NOT NULL DEFAULT '0',
  `empname` char(25) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `file` varchar(250) NOT NULL,
  PRIMARY KEY (`empno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`empno`, `empname`, `sal`, `file`) VALUES
(1, 'Kamal', 12000, ''),
(2, 'Arun', 12000, ''),
(3, 'Anbu', 15000, ''),
(4, 'Sathishkumar', 15000, ''),
(6, 'Ashok', 12000, '');

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE IF NOT EXISTS `employee_details` (
  `EmployeeID` int(10) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(65) NOT NULL,
  `LastName` varchar(65) NOT NULL,
  `Place` varchar(65) NOT NULL,
  `Country` varchar(65) NOT NULL,
  `PhoneNo` varchar(13) NOT NULL,
  PRIMARY KEY (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`EmployeeID`, `FirstName`, `LastName`, `Place`, `Country`, `PhoneNo`) VALUES
(1, 'Merbin', 'Joe', 'Mulagumoodu', 'India', '9094089451'),
(2, 'Ganesh', 'Kumar', 'Azagiyamandabam', 'India', '9094089452'),
(3, 'Franklin', 'Jose', 'Madurai', 'India', '9094089453'),
(4, 'Arul', 'Selva Raj', 'Chennai', 'India', '9094089454'),
(5, 'Meena', 'Kumari', 'Marthandam', 'India', '7943599609'),
(7, 'Anish', 'Kumar', 'Thuckalay', 'India', '6945590608'),
(8, 'Abishai', 'Raj', 'Alaska', 'United States', '9934522155'),
(9, 'Ely', 'Jak', 'Arizona', 'United States', '9845552786'),
(10, 'Jasmin', 'Pradeeba', 'London', 'United Kingdom', '4943494251'),
(11, 'Slayan', 'Kal', 'Sheffield', 'United Kingdom', '7943394205'),
(12, 'Satheesh', 'Kumar', 'Kollam', 'Afghanistan', '5434543445'),
(13, 'Thanka ', 'Raj', 'Kandahar', 'Afghanistan', '7142394201');

-- --------------------------------------------------------

--
-- Table structure for table `fileup_img`
--

CREATE TABLE IF NOT EXISTS `fileup_img` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fileup_img`
--

INSERT INTO `fileup_img` (`id`, `title`, `image`, `status`) VALUES
(1, 'check', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `general_details`
--

CREATE TABLE IF NOT EXISTS `general_details` (
  `GeneralID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(65) NOT NULL,
  `Age` int(10) NOT NULL,
  `IsTest` int(11) DEFAULT NULL,
  `TestRoomID` int(11) DEFAULT NULL,
  PRIMARY KEY (`GeneralID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `general_details`
--

INSERT INTO `general_details` (`GeneralID`, `Name`, `Age`, `IsTest`, `TestRoomID`) VALUES
(1, 'Rajesh', 21, 1, NULL),
(2, 'Reegan', 23, 1, 1),
(3, 'Alex', 21, NULL, 1),
(4, 'Helina', 33, 1, NULL),
(5, 'Heera', 17, NULL, NULL),
(6, 'John', 20, 1, 3),
(7, 'Keerthy', 33, 1, 4),
(8, 'Chanthil', 29, 1, 2),
(9, 'Craig', 26, 1, NULL),
(10, 'Uriah', 21, NULL, 6),
(11, 'Spencer', 23, 1, NULL),
(12, 'Tobias', 24, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `file_name`, `uploaded_on`, `status`) VALUES
(1, '111.JPG', '0000-00-00 00:00:00', '1'),
(2, '0 (1).jpeg', '0000-00-00 00:00:00', '1'),
(3, '0 (1).jpg', '0000-00-00 00:00:00', '1'),
(4, '0 (1).png', '0000-00-00 00:00:00', '1'),
(5, '0 (2).jpeg', '0000-00-00 00:00:00', '1'),
(6, '0 (2).jpg', '0000-00-00 00:00:00', '1'),
(7, '0 (2).png', '0000-00-00 00:00:00', '1'),
(8, '0 (3).jpeg', '0000-00-00 00:00:00', '1'),
(9, '0 (3).jpg', '0000-00-00 00:00:00', '1'),
(10, '0 (3).png', '0000-00-00 00:00:00', '1'),
(11, '0 (4).jpg', '0000-00-00 00:00:00', '1'),
(12, '0 (4).png', '0000-00-00 00:00:00', '1'),
(13, '0 (5).jpg', '0000-00-00 00:00:00', '1'),
(14, '0 (6).jpg', '0000-00-00 00:00:00', '1'),
(15, '0 (7).jpg', '0000-00-00 00:00:00', '1'),
(16, '0 (8).jpg', '0000-00-00 00:00:00', '1'),
(17, '0 (9).jpg', '0000-00-00 00:00:00', '1'),
(18, '0 (10).jpg', '0000-00-00 00:00:00', '1'),
(19, '0 (11).jpg', '0000-00-00 00:00:00', '1'),
(20, '0 (12).jpg', '0000-00-00 00:00:00', '1'),
(21, '0 (13).jpg', '0000-00-00 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE IF NOT EXISTS `marks` (
  `MID` int(20) NOT NULL AUTO_INCREMENT,
  `ID` int(20) NOT NULL,
  `MARK1` varchar(10) NOT NULL,
  `MARK2` varchar(20) NOT NULL,
  PRIMARY KEY (`MID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`MID`, `ID`, `MARK1`, `MARK2`) VALUES
(1, 1, '', ''),
(2, 2, '', ''),
(3, 3, '', ''),
(4, 4, '', ''),
(5, 5, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `meeting_details`
--

CREATE TABLE IF NOT EXISTS `meeting_details` (
  `MeetingID` int(10) NOT NULL AUTO_INCREMENT,
  `TimeFrom` varchar(10) NOT NULL,
  `TimeTo` varchar(10) NOT NULL,
  `RoomID` varchar(10) NOT NULL,
  `MeetingTitle` varchar(65) NOT NULL,
  `MeetingDate` date NOT NULL,
  PRIMARY KEY (`MeetingID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `meeting_details`
--

INSERT INTO `meeting_details` (`MeetingID`, `TimeFrom`, `TimeTo`, `RoomID`, `MeetingTitle`, `MeetingDate`) VALUES
(1, '3.30 PM', '4 PM', '1', 'Appraisal Meeting', '2018-11-06'),
(2, '10.30 AM', '12 PM', '2', 'Exit Meeting', '2018-11-07'),
(3, '11 AM', '12 PM', '3', 'Manager Change Meeting', '2018-11-08'),
(4, '4.15 PM', '5.30 PM', '2', 'Termination Meeting', '2018-11-09'),
(5, '4.30 PM', '5 PM', '5', 'Clearance Meeting', '2018-11-12'),
(6, '9.10 AM ', '11.30 AM', '3', 'New Project Meeting', '2018-11-07'),
(7, '2.30 PM', '4 PM', '3', 'Project Discussion Meeting', '2018-11-14'),
(8, '1.30 PM', '3.15 PM', '9', 'System Maintenance Meeting', '2018-11-15'),
(9, '1.30 PM', '3 PM', '7', 'Feastival Meeting', '2018-11-16'),
(10, '4 PM', '5 PM', '2', 'Appraisal Meeting', '2018-11-19'),
(11, '11.30 PM', '12.30 PM', '5', 'Branch Transfer Meeting', '2018-11-20'),
(12, '11 AM', '12 PM', '3', 'Manager Change Meeting', '2018-11-08'),
(13, '4.15 PM', '5.30 PM', '2', 'Termination Meeting', '2018-11-09'),
(14, '4.30 PM', '5 PM', '5', 'Clearance Meeting', '2018-11-12'),
(15, '9.10 AM ', '11.30 AM', '3', 'New Project Meeting', '2018-11-07'),
(16, '2.30 PM', '4 PM', '3', 'Project Discussion Meeting', '2018-11-14'),
(17, '1.30 PM', '3.15 PM', '9', 'System Maintenance Meeting', '2018-11-15'),
(18, '1.30 PM', '3 PM', '7', 'Feastival Meeting', '2018-11-16'),
(19, '4 PM', '5 PM', '2', 'Appraisal Meeting', '2018-11-19'),
(20, '11.30 PM', '12.30 PM', '5', 'Branch Transfer Meeting', '2018-11-17');

-- --------------------------------------------------------

--
-- Table structure for table `meeting_employees`
--

CREATE TABLE IF NOT EXISTS `meeting_employees` (
  `MemberID` int(10) NOT NULL AUTO_INCREMENT,
  `EmployeeID` int(10) NOT NULL,
  `MeetingID` int(10) NOT NULL,
  PRIMARY KEY (`MemberID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `meeting_employees`
--

INSERT INTO `meeting_employees` (`MemberID`, `EmployeeID`, `MeetingID`) VALUES
(1, 1, 2),
(2, 2, 2),
(3, 3, 2),
(4, 4, 3),
(5, 5, 3),
(6, 6, 2),
(7, 7, 2),
(8, 8, 3),
(9, 9, 3),
(10, 10, 3),
(11, 11, 2),
(12, 12, 2);

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `cpassword` varchar(250) NOT NULL,
  `phone` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `name`, `email`, `dob`, `password`, `cpassword`, `phone`) VALUES
(1, 'Kamal', 'kamal.microshare@gmail.com', '1990-06-07', 'kamal*123', 'kamal*123', '9094089458');

-- --------------------------------------------------------

--
-- Table structure for table `reguser`
--

CREATE TABLE IF NOT EXISTS `reguser` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `REG` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `CITY` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `reguser`
--

INSERT INTO `reguser` (`ID`, `REG`, `NAME`, `CITY`) VALUES
(1, 'A1001', 'Kamal', 'Arni'),
(2, 'A1002', 'Arun', 'Osur'),
(3, 'A1003', 'Sakthi', 'Arni'),
(4, 'A1004', 'John', 'Osur'),
(5, 'A1005', 'Arivoli', 'Karaikal');

-- --------------------------------------------------------

--
-- Table structure for table `room_details`
--

CREATE TABLE IF NOT EXISTS `room_details` (
  `RoomID` int(10) NOT NULL AUTO_INCREMENT,
  `RoomName` varchar(65) NOT NULL,
  `RoomSize` int(10) NOT NULL,
  PRIMARY KEY (`RoomID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `room_details`
--

INSERT INTO `room_details` (`RoomID`, `RoomName`, `RoomSize`) VALUES
(1, 'Guest Room', 20),
(2, 'Conference Room 1', 20),
(3, 'Conference Room 2', 20),
(4, 'Conference Room 3', 7),
(5, 'A/C Room', 9),
(6, 'Non A/C Room', 78),
(7, 'Meeting Room 1', 10),
(8, 'Meeting Room 2', 26),
(9, 'Meeting Room 3', 100),
(10, 'Meeting Room 4', 81),
(11, 'Test Room', 1000),
(12, 'Test Room', 800),
(13, 'Test Room', 500);

-- --------------------------------------------------------

--
-- Table structure for table `skeleton_loader`
--

CREATE TABLE IF NOT EXISTS `skeleton_loader` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` text,
  `post_url` varchar(255) DEFAULT NULL,
  `post_description` text,
  `post_image` varchar(255) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `skeleton_loader`
--

INSERT INTO `skeleton_loader` (`id`, `post_title`, `post_url`, `post_description`, `post_image`, `datetime`) VALUES
(1, 'What is Lorem Ipsum?', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-1.jpg', NULL),
(2, 'Why do we use it?', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-2.jpg', NULL),
(3, 'Where does it come from?', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-3.jpg', NULL),
(4, 'Where can I get some?', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-4.jpg', NULL),
(5, '1914 translation by H. Rackham', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-5.jpg', NULL),
(6, 'Generated 10 paragraphs, 731 words', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-6.jpg', NULL),
(7, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'http://localhost/skeleton-loader/index.html', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images-7.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `state_id` int(10) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(265) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(1, 'Tamilnadu'),
(2, 'Kerala'),
(3, 'Bengaluru');

-- --------------------------------------------------------

--
-- Table structure for table `status_check`
--

CREATE TABLE IF NOT EXISTS `status_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `age` varchar(150) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `status_check`
--

INSERT INTO `status_check` (`id`, `name`, `age`, `contact`, `city`, `status`) VALUES
(1, 'kamal`', '28', '7418823014', 'Arni', '0'),
(2, 'sakthivel', '22', '8122385852', 'Arni', '0'),
(7, 'Akash', '20', '9094089458', 'Chennai', '0'),
(8, 'Arun', '28', '8122385852', 'Vellore', '0');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `contact` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stud_id`, `name`, `age`, `contact`, `city`) VALUES
(1, 'kamal`', 28, '7418823014', 'Arni'),
(2, 'sakthivel', 22, '8122385852', 'Arni'),
(7, 'Akash', 20, '9094089458', 'Chennai'),
(8, 'Arun', 28, '8122385852', 'Vellore');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` varchar(30) NOT NULL,
  `sub_cat` varchar(30) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `cat_id`, `sub_cat`, `reg_date`) VALUES
(1, '1', 'arun-nithya', '2019-07-29 13:53:22'),
(2, '1', 'sam-jayanth', '2019-07-29 13:53:22'),
(3, '2', 'Ashok-anitha', '2019-07-29 13:54:10'),
(4, '2', 'ramchandran-gomathi', '2019-07-29 13:54:10'),
(5, '3', 'akash-harini', '2019-07-29 13:54:41'),
(6, '3', 'parthi-paramesh', '2019-07-29 13:54:41'),
(7, '4', 'sakthi-ratha', '2019-07-29 13:55:07'),
(8, '4', 'sathya-divya', '2019-07-29 13:55:07'),
(9, '5', 'magesh-uma', '2019-07-29 13:55:30'),
(10, '5', 'ranjith-jeya', '2019-07-29 13:55:30'),
(11, '6', 'Dinesh-ammu', '2019-07-29 13:56:16'),
(12, '6', 'sathish-sara', '2019-07-29 13:56:16');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `ID` int(8) NOT NULL AUTO_INCREMENT,
  `SUBJECT` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`ID`, `SUBJECT`) VALUES
(1, 'Tamil'),
(2, 'English'),
(3, 'Maths'),
(4, 'Socialscience'),
(5, 'Science'),
(6, 'Tamil'),
(7, 'Science'),
(8, 'Tamil'),
(9, 'English'),
(10, 'Maths'),
(11, 'Science'),
(12, 'Socialscience'),
(13, 'Tamil'),
(14, 'English'),
(15, 'Maths'),
(16, 'Science'),
(17, 'Socialscience'),
(18, 'Science'),
(19, 'Socialscience'),
(20, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=209 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `address`, `gender`, `designation`, `age`, `image`) VALUES
(1, 'Bruce Tom', '656 Edsel Road\r\nSherman Oaks, CA 91403', 'Male', 'Driver', 36, '1.jpg'),
(5, 'Clara Gilliam', '63 Woodridge Lane\r\nMemphis, TN 38138', 'Female', 'Programmer', 24, '2.jpg'),
(6, 'Barbra K. Hurley', '1241 Canis Heights Drive\r\nLos Angeles, CA 90017', 'Female', 'Service technician', 26, '3.jpg'),
(7, 'Antonio J. Forbes', '403 Snyder Avenue\r\nCharlotte, NC 28208', 'Male', 'Faller', 32, '4.jpg'),
(8, 'Charles D. Horst', '1636 Walnut Hill Drive\r\nCincinnati, OH 45202', 'Male', 'Financial investigator', 29, '5.jpg'),
(175, 'Ronald D. Colella', '1571 Bingamon Branch Road, Barrington, IL 60010', 'Male', 'Top executive', 32, '6.jpg'),
(174, 'Martha B. Tomlinson', '4005 Bird Spring Lane, Houston, TX 77002', 'Female', 'Systems programmer', 38, '7.jpg'),
(161, 'Glenda J. Stewart', '3482 Pursglove Court, Rossburg, OH 45362', 'Female', 'Cost consultant', 28, '8.jpg'),
(162, 'Jarrod D. Jones', '3827 Bingamon Road, Garfield Heights, OH 44125', 'Male', 'Manpower development advisor', 64, '9.jpg'),
(163, 'William C. Wright', '2653 Pyramid Valley Road, Cedar Rapids, IA 52404', 'Male', 'Political geographer', 33, '10.jpg'),
(178, 'Sara K. Ebert', '1197 Nelm Street\r\nMc Lean, VA 22102', 'Female', 'Billing machine operator', 50, ''),
(177, 'Patricia L. Scott', '1584 Dennison Street\r\nModesto, CA 95354', 'Female', 'Urban and regional planner', 54, ''),
(179, 'James K. Ridgway', '3462 Jody Road\r\nWayne, PA 19088', 'Female', 'Recreation leader', 41, ''),
(180, 'Stephen A. Crook', '448 Deercove Drive\r\nDallas, TX 75201', 'Male', 'Optical goods worker', 36, ''),
(181, 'Kimberly J. Ellis', '4905 Holt Street\r\nFort Lauderdale, FL 33301', 'Male', 'Dressing room attendant', 24, ''),
(182, 'Elizabeth N. Bradley', '1399 Randall Drive\r\nHonolulu, HI 96819', 'Female', ' Software quality assurance analyst', 25, ''),
(183, 'Steve John', '108, Vile Parle, CL', 'Male', 'Software Engineer', 29, ''),
(184, 'Marks Johnson', '021, Big street, NY', 'Male', 'Head of IT', 41, ''),
(185, 'Mak Pub', '1462 Juniper Drive\r\nBreckenridge, MI 48612', 'Male', 'Mental health counselor', 40, ''),
(186, 'Louis C. Charmis', '1462 Juniper Drive\r\nBreckenridge, MI 48612', 'Male', 'Mental health counselor', 40, ''),
(187, 'kamal', 'no 15', 'male', 'developer', 28, ''),
(188, 'kamal', 'no15', 'male', 'developer', 28, ''),
(189, 'kamal', 'no 15', 'male', 'developer', 28, ''),
(190, 'kamal', 'no 15', 'male', 'developer', 28, ''),
(191, 'kamal', 'no 15', 'male', 'developer', 28, ''),
(192, 'kamal', 'no 15', 'male', 'developer', 28, ''),
(193, 'kamal', 'no 15', 'male', 'ddd', 0, ''),
(194, 'kamal', 'no 15', 'male', 'ddd', 0, ''),
(195, 'kamal', 'no 15', 'male', 'ddd', 0, ''),
(196, '', '', 'male', '', 0, ''),
(197, '', '', 'male', '', 0, ''),
(198, '', '', 'male', '', 0, ''),
(199, '', '', 'male', '', 0, ''),
(200, '', '', 'male', '', 0, ''),
(201, '', '', 'male', '', 0, ''),
(202, '', '', 'male', '', 0, ''),
(203, '', '', 'male', '', 0, ''),
(204, '', '', 'male', '', 0, ''),
(205, 'kamal', '', '', '', 28, ''),
(206, '', '', '', '', 0, ''),
(207, 'kamal', '', '', '', 28, ''),
(208, '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `address`, `status`) VALUES
(1, 'kamal', 'smkamal.sm@gmail.com', 'No.38, Anna nagar, chennai', '0'),
(2, 'Arun', 'Arun@gmail.com', 'No.15, Poonamalli, chennai', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `posting_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `contactno`, `posting_date`) VALUES
(1, 'kamal', '', 'smkamal.sm@gmail.com', '0e70cc8dc0d805eb366281bb4db44357', '7418823014', '2018-09-29');

-- --------------------------------------------------------

--
-- Table structure for table `ws_yogaseat_reg_2019`
--

CREATE TABLE IF NOT EXISTS `ws_yogaseat_reg_2019` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reg_id` varchar(100) NOT NULL,
  `seat` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `aadhar` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `message` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL,
  `status` enum('A','D','E') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ws_yogaseat_reg_2019`
--

INSERT INTO `ws_yogaseat_reg_2019` (`id`, `reg_id`, `seat`, `name`, `email`, `mobile`, `aadhar`, `gender`, `age`, `address`, `message`, `created_at`, `status`) VALUES
(1, 'SET-1', 'seet-133', 'Arun', 'kamal.microshare@gmail.com', '7418823014', '101', 'Male', '25', 'NO 18/32', 'check', '2019-07-06 06:08:03', 'A'),
(2, 'SET-2', 'seet-190', 'Arun', 'kamal.microshare@gmail.com', '7418823014', '102', 'Male', '25', 'NO 18/32', 'check', '2019-07-06 06:13:39', 'A'),
(3, 'SET-3', 'seet-19', 'Arun', 'kamal.microshare@gmail.com', '7418823014', '103', 'Male', '25', 'NO 18/32', 'check', '2019-07-06 06:46:03', 'A'),
(4, 'SET-4', 'seat193', 'kamal', 'kamal.microshare@gmail.com', '7418823014', '104', 'Male', '25', 'NO 18/32', 'check', '2019-07-06 06:55:28', 'A'),
(5, 'SET-5', 'seat-18', 'Arun', 'kamal.microshare@gmail.com', '7418823014', '105', 'Male', '25', 'NO 18/32', 'check', '2019-07-06 06:56:50', 'A');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `reguser` (`ID`);
