function first()
{
	alert("This is Javascript");
}

function swap()
{
	var a,b,c;
	//swapping
	a=10;
	b=12;
	alert("Before swap: \n a= "+a+" \n b= "+b);
	c=a;
	a=b;
	b=c;
	alert("After swap: \n a= "+a+" \n b= "+b);
}

// Basic Addition		
function calme()
{
	var a,b,c;		
	a=Number(document.getElementById("a").value);
	b=Number(document.getElementById("b").value);
	c=a+b;
	document.getElementById("output").innerHTML="Total:" +c;
}
function clr()
{
	document.getElementById("output").innerHTML="";
	document.getElementById("a").value="";
	document.getElementById("b").value="";
}

//Arithmatic Operation
function add()
{
	var a,b,c;
	a=10;
	b=20;
	c=a+b;
	alert("Addition:" +c);
}
function sub()
{
	var a,b,c;
	a=10;
	b=20;
	c=a-b;
	alert("Addition:" +c);
}
function mul()
{
	var a,b,c;
	a=10;
	b=20;
	c=a*b;
	alert("Addition:" +c);
}
function div()
{
	var a,b,c;
	a=10;
	b=20;
	c=a/b;
	alert("Addition:" +c);
}

// Array 
function mon()
{
	var mo=new Array();
	mo[0]="JAN";
	mo[1]="FEB";
	mo[2]="MAR";
	mo[3]="APR";
	mo[4]="MAY";
	mo[5]="JUN";
	mo[6]="JUL";
	mo[7]="AUG";
	mo[8]="SEP";
	mo[9]="OCT";
	mo[10]="NOV";
	mo[11]="DEC";
	
	b="<select>";
	for(e in mo)
	{
		b+="<option>" +mo[e]+ "</option>"
	}
	b+="</select>";			
	document.getElementById("e").innerHTML= b;
}

// Date Function
var month= new Array(12);
month[0]="JANUARY	";
month[1]="FEBRUARY";
month[2]="MARCH";
month[3]="APRIL";
month[4]="MAY";
month[5]="JUNE";
month[6]="JULY";
month[7]="AUGUST";
month[8]="SEPTEMBER";
month[9]="OCTOBER";
month[10]="NOVEMBER";
month[11]="DECEMBER";

var days=new Array(7);
days[0]="Sunday";
days[1]="Monday";
days[2]="Tuesday";
days[3]="Wednesday";
days[4]="Thursday";
days[5]="Friday";
days[6]="Saturday";

function customdate(f)
{
	var day_words= days[f.getDay()];
	var the_date= f.getDate();
	var mon_words= month[f.getMonth()];
	var the_year= f.getYear()-100;
	
	// alert(day_words+ "" +the_date+ ""+mon_words+ "" +the_year  );
	return day_words+ " " +the_date+ " "+mon_words+ "   " +the_year;
}

// onclick function
function calc(g)
{
	if (g.elements[1].checked)
	{
		g.result.value=g.entry.value*2;
	}
	else
	{
		g.result.value=g.entry.value*g.entry.value;
	}
}

// onError Function


// form Uppercse/lowercase typeing
function check()
{
	var h=document.getElementById("upper").value;
	document.getElementById("upper").value= h.toUpperCase();
	
	var h=document.getElementById("lower").value;
	document.getElementById("lower").value= h.toLowerCase();
}

//calculator 
function calc(ch)
{
	if(ch=="=")
	{
		document.f1.t1.value=eval(document.f1.t1.value);
	}
	else
	{
		if(ch=="C")
		{
			document.f1.t1.value="";
		}
		else
		{
			document.f1.t1.value+=ch;
		}
	}
}

//Digital Clock
setInterval('disp()',1000)
 function disp()
 {
	dt= new Date();
	h=dt.getHours();
	m=dt.getMinutes();
	s=dt.getSeconds();
	
	document.f2.d1.value=h;
	document.f2.d2.value=m;
	document.f2.d3.value=s;
 }
 // Background Effect
 
 // Phone no validtion
 function ph()
 {
	 var str 
	 str=document.phone.number.value;
	 if(isNaN(parseInt(str)))
	 {
	 alert("Phone Number is invalid");
	 document.phone.number.value="";
	 document.phone.number.select();
	 }
 }
 
 // Email validtion
 