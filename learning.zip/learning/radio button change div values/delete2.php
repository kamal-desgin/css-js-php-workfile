<?php
	include("wadmin/config.php");
	$con = new mysqli($host, $user,$pass,$db_name);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <script src="js/jquery.min.js"></script>
</head>
<body>
 <div class="container">
        <div class="row col-md-4">
        <h2> Package Name </h2>
                    <ul>
						<?php												
							$sel_slider = "select * from in_package_name";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
								$package_name = $slider_data['package_name'];
							}
						?>
					  </ul>
				
        </div>
       <div class="row col-md-4">
        <h2> Package Price </h2>
            <ul class="">
						<?php												
							$sel_slider = "select * from in_hotel_star";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
                                
                                $Fivestar = $slider_data['Fivestar'];
                                $Fourstar = $slider_data['Fourstar'];
                                $Threestar = $slider_data['Threestar'];
                                
								
							}
						?>
					  </ul>
        </div>
        <div class="row col-md-4">
        <h2> Hotel list </h2>
            <ul>
						<?php												
							$sel_slider = "select * from in_hotel_price";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
								$Fivestar_hotel_name	= $slider_data['Fivestar_hotel_name'];								
								$Fivestar_hotel_price	= $slider_data['Fivestar_hotel_price'];								
								$Fivestar_hotel_star	= $slider_data['Fivestar_hotel_star'];								
								$Fivestar_hotel_place	= $slider_data['Fivestar_hotel_place'];								
								$Fourstar_hotel_name	= $slider_data['Fourstar_hotel_name'];								
								$Fourstar_hotel_price	= $slider_data['Fourstar_hotel_price'];								
								$Fourstar_hotel_star	= $slider_data['Fourstar_hotel_star'];								
								$Fourstar_hotel_place	= $slider_data['Fourstar_hotel_place'];								
								$Threestar_hotel_name	= $slider_data['Threestar_hotel_name'];								
								$Threestar_hotel_price	= $slider_data['Threestar_hotel_price'];								
								$Threestar_hotel_star	= $slider_data['Threestar_hotel_star'];								
								$Threestar_hotel_place	= $slider_data['Threestar_hotel_place'];								
							}
						?>
					  </ul>
        </div>
        
        
        <div class="row">
            <div class="col-lg-12">
				<h2><?php echo $package_name; ?></h2>
				<input type="radio" name="packagename" id="Fivestar" value="<?php echo $Fivestar; ?>"><b>Fivestar</b> 
				<input type="radio" name="packagename" id="Fourstar" value="<?php echo $Fourstar; ?>"><b>Fourstar</b>
				<input type="radio" name="packagename" id="Threestar" value="<?php echo $Threestar; ?>"><b>Threestar</b>
					
					<div class="div1">
						DIV1 Fivestar 

						<div class="card">
							<div class="card-headr"> 
								<h2 class="card-title"><?php echo $Fivestar; ?></h2>
							</div>
							<div class="card-body"> 
								<p>
								   <?php echo $Fivestar_hotel_name; ?> <br>
								   <?php echo $Fivestar_hotel_price; ?>  <br>
								   <?php echo $Fivestar_hotel_star; ?>  <br>
								   <?php echo $Fivestar_hotel_place; ?>  <br>
								</p>
							</div>						
						</div>
					</div>

					<div class="div2">
						DIV2 Fourstar	
						<div class="card">
							<div class="card-headr"> 
								<h2 class="card-title"><?php echo $Fourstar; ?></h2>
							</div>
							<div class="card-body"> 
								<p>
								   <?php echo $Fourstar_hotel_name; ?> <br>
								   <?php echo $Fourstar_hotel_price; ?>  <br>
								   <?php echo $Fourstar_hotel_star; ?>  <br>
								   <?php echo $Fourstar_hotel_place; ?>  <br>
								</p>
							</div>						
						</div>
					</div>
					
					<div class="div3">
						DIV3 Threestar
						<div class="card">
							<div class="card-headr"> 
								<h2 class="card-title"><?php echo $Threestar; ?></h2>
							</div>
							<div class="card-body"> 
								<p>
								   <?php echo $Threestar_hotel_name; ?> <br>
								   <?php echo $Threestar_hotel_price; ?>  <br>
								   <?php echo $Threestar_hotel_star; ?>  <br>
								   <?php echo $Threestar_hotel_place; ?>  <br>
								</p>
							</div>						
						</div>
					</div>
					
		    </div>
        </div>
    </div>
	<script>
		$(function() {
		 $('.div2, .div3').hide(); // hide div1 and div2 on page load
		  $('[name=packagename]').on('change', function() { // bind an onchange function to the inputs
			if ($('[name=packagename]:checked').val() == <?php echo $Fivestar; ?>) {
				$('.div1').show();        // show div1
			    $('.div2, .div3').hide(); // hide other divs
			  }
			  else if ($('[name=packagename]:checked').val() == <?php echo $Fourstar; ?>) {
				$('.div2').show();        // show div1
			    $('.div1, .div3').hide(); // hide other divs
			  } 
			  else {
				$('.div3').show();        // show div1
			    $('.div1, .div2').hide(); // hide other divs
			  }
		  });
		});
	</script>

<!-- refer link-->
<!--https://stackoverflow.com/questions/46294646/php-radiobutton-on-click-event-change -->

</body>
</html>
