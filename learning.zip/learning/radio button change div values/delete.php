<?php
	include("wadmin/config.php");
	$con = new mysqli($host, $user,$pass,$db_name);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
 <div class="container">
        <div class="row col-md-4">
        <h2> Package Name </h2>
                    <ul>
						<?php												
							$sel_slider = "select * from in_package_name";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
								?>
								<li><a href="gallery-category.php?gcat_id=<?php echo $slider_data['id']; ?>"><?php echo $slider_data['package_name']; ?> </a></li>
								<?php
							}
						?>
					  </ul>
				
        </div>
       <div class="row col-md-4">
        <h2> Package Price </h2>
            <ul class="">
						<?php												
							$sel_slider = "select * from in_hotel_star";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
                                
                                $Fivestar = $slider_data['Fivestar'];
                                $Fourstar = $slider_data['Fourstar'];
                                $Threestar = $slider_data['Threestar'];
                                
								
							}
						?>
					  </ul>
        </div>
        <div class="row col-md-4">
        <h2> Hotel list </h2>
            <ul>
						<?php												
							$sel_slider = "select * from in_hotel_price";
							$slider_res = $con->query($sel_slider) or die(mysqli_error($con));
							while($slider_data = $slider_res->fetch_array())
							{
								?>
								<li><a href="gallery-category.php?gcat_id=<?php echo $slider_data['id']; ?>"><?php echo $slider_data['Fivestar_hotel_name']; ?> </a></li>
								<?php
							}
						?>
					  </ul>
        </div>
        
        
        <div class="row">
            <div class="col-lg-12">
                <?php
                    $compare_value = $Fourstar;
                ?>
             <input type="radio" name="package" value="1" <?php if($Fivestar ==$compare_value) { echo 'checked';}?>>FIvestar
             <input type="radio" name="package" value="2" <?php if($Fourstar ==$compare_value) { echo 'checked';}?>> Fourstar
             <input type="radio" name="package" value="3" <?php if($Threestar ==$compare_value) { echo 'checked';}?>> Threestar
            </div>
        </div>
    </div>


</body>
</html>
