<!doctype html>
<html lang="en-us">
	<head>
		<title> Microshare Software Solutions Pvt Ltd.</title>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">			
			<!-- google font -->
			<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext'>
			<!---fontawesome link--->
			<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
			<!-- css stylesheet -->
			<link rel='stylesheet' href='assets/css/bootstrap.css'>
			<link rel="stylesheet" type="text/css" href="assets/css/style.css">
			<script src="assets/js/jquery.js"></script>
			<script src="assets/js/bootstrap.js"></script>
			
			<script src="https://code.jquery.com/jquery-3.3.1.slim.js"></script>
			<script src='https://www.google.com/recaptcha/api.js'></script>

			
	</head>
	<body>
		<header>
			<div class="top-header">
				<div class="top-header-left">
					<ul class="info">
						<li><a href="tel:1234567890"><span class="glyphicon glyphicon-earphone"></span> 1234567890</a></li>
						<li><a href="mailto:admin@gmail.com"><span class="glyphicon glyphicon-envelope"></span> admin@gmail.com</a></li>
					</ul>
				</div>
				<div class="top-header-right">
					<ul class="info">
						<li> <a href="#"><?php echo $_SESSION['name'];?></a></li>
						<li> <a href="logout.php">Log Out</a></li>
					</ul>
				</div>
				
			</div>
			
				<div class="example3">
				  <nav class="navbar navbar-inverse navbar-static-top">
					<div class="container">
					  <div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://www.microshare.in/"><img src="assets/images/logo.png" alt="Microshare software Development">
						</a>
					  </div>
					  <div id="navbar3" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
						  <li class="active"><a href="#">Home</a></li>
						  <li><a href="#">About</a></li>
						  <li><a href="#">Contact</a></li>
						  <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
							  <li><a href="#">Action</a></li>
							  <li><a href="#">Another action</a></li>
							  <li><a href="#">Something else here</a></li>
							  <li class="divider"></li>
							  <li class="dropdown-header">Nav header</li>
							  <li><a href="#">Separated link</a></li>
							  <li><a href="#">One more separated link</a></li>
							</ul>
						  </li>				   
						</ul>
					  </div> <!--/.nav-collapse -->
					</div> <!--/.container-fluid -->
				  </nav>
				</div> <!-- nav end -->
		</header>

		
<div class="jumbotron jumbotron-sm mt-20">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <h3 class="h2">Contact us</h3>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="well well-sm">
			  <form action="contactus.php" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
							<div class="form-group">
								<label for="name">Name</label>
								<input type="text" class="form-control" name="name" id="name" placeholder="Enter name" required="required" />
							</div>
							<div class="form-group">
								<label for="email">Email Address</label>
								<div class="input-group">
									<span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
									<input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required" />
								</div>
							</div>
							 <div class="form-group">
								<label for="phone">Contact No</label>
								<div class="input-group">
									<span class="input-group-addon"><span class="glyphicon glyphicon-earphone"></span></span>
									<input type="tel" name="phone" class="form-control" id="phone" placeholder="Enter contact no" required="required" />
								</div>
							 </div>
						 
						    <div class="form-group">
								<label for="subjects">Subject</label>
								<input type="text" class="form-control" name="subjects" id="subjects" placeholder="Enter subject" required="required" />
							</div>					 
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">  Message</label>
                            <textarea name="message" id="message" class="form-control" rows="6" cols="25" required="required" placeholder="Message"></textarea>
                        </div>
						<div class="form-group">
						  <div class="g-recaptcha" data-sitekey="6Ldhtm0UAAAAAIFYSHy7HrCo0f2sLUADPS4qye8n"></div>
					    </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="btnContactUs"> Send Message</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
		<div class="col-md-4">
            <form>
            <legend><span class="glyphicon glyphicon-globe"></span> Our office</legend>
            <address>
                <strong>Microshare Software Solutions Pvt Ltd</strong><br>
                No: 36/2 Gangai Amman Koil Street, <br>
				Jafferkhanpet, Ashok Nagar,<br>
				Chennai - 600 083.
			</address>
			<address>
                <strong>Phone </strong><br>
               <a href="tel:+919043091626"> +91 90430 91626,</a>
				<a href="tel:+919677191626"> +91 96771 91626</a>
            </address>
                
            </address>
            <address>
                <strong>Email </strong><br>
                <a href="mailto:admin@microshare.in">admin@microshare.in</a>
            </address>
            </form>
        </div>
    </div>
</div>
<?php
if(isset($_POST['submit'])):
    if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])):
        //your site secret key
        $secret = '6Ldhtm0UAAAAAL6LAHiyVHp0BdZdIGTHnWwwbSDt';
        //get verify response data
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if($responseData->success):
            //contact form submission code
            $name = !empty($_POST['name'])?$_POST['name']:'';
            $email = !empty($_POST['email'])?$_POST['email']:'';
            $phone = !empty($_POST['phone'])?$_POST['phone']:'';
            $subjects = !empty($_POST['subjects'])?$_POST['subjects']:'';
            $message = !empty($_POST['message'])?$_POST['message']:'';
            
            $to = 'kamal.microshare@gmail.com';
            $subject = 'Microshare Contact Enquiry Form';
            $htmlContent = "
                <h1>Contact request details</h1>
                <p><b>Name: </b>".$name."</p>
                <p><b>Email: </b>".$email."</p>
                <p><b>Contact no: </b>".$phone."</p>
                <p><b>Subject: </b>".$subjects."</p>
                <p><b>Message: </b>".$message."</p>
            ";
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            // More headers
            $headers .= 'From:'.$name.' <'.$email.'>' . "\r\n";
            //send email
            @mail($to,$subject,$htmlContent,$headers);
            
            //$succMsg = 'Your contact request have submitted successfully.';
			echo "<script>alert('Your contact request have submitted successfully.');</script>";
			echo "<script>window.location.href='contactus.php';</script>";
        else:
            //$errMsg = 'Robot verification failed, please try again.';
			echo "<script>alert('Robot verification failed, please try again.');</script>";
			echo "<script>window.location.href='contactus.php';</script>";
        endif;
    else:
        //$errMsg = 'Please click on the reCAPTCHA box.';
		echo "<script>alert('Please click on the reCAPTCHA box.');</script>";
		echo "<script>window.location.href='contactus.php';</script>";
    endif;
else:
    $errMsg = '';
    $succMsg = '';
endif;
?>

	
	
<footer>
	<p>&copy; 2018 <a href="http://www.microshare.in">www.microshare.in</a></p>
</footer>
	
</body>
</html> 