<h4>Varible</h4>
<?php
	$name= "kamal";
	$number= "7990";
	// print $name;    // only one Varible print
	// echo $name, $number; // Multiple Varible print
	echo $name, ' '. $number; //' '. this is text space 
?>

<h4>Arithmatic Operator</h4>
<?php
	$a= 10;
	$b= 8;
	$c = $a + $b; //first type
	echo $c;   
	//second type check
 /* $c = $a + $b. "<br>"; 
	$c. = $a - $b. "<br>";
	$c. = $a * $b. "<br>";
	$c. = $a / $b. "<br>";
	echo $c;*/ 
?>

<h4>Joining String</h4>
<?php
	$name1= "kamal";
	$name2= "sakthivel";
	$name = $name1.$name2; // dot (	.)join
	echo $name;
?>
<h4>Joining string another type</h4>
<?php
	$name= "kamal";
	$name.= ' ';
	$name.= "sakthivel";
	$name.= ' ';
	$name.= "Raji";
	echo $name;
?>
<h4>Array (print_r)</h4>
<?php
	$name= array ('kamal','sakthivel');
	print_r ($name);
?>
<h4>Array (echo) check error</h4>
<?php
	/*$name= ['kamal''sakthivel'];
	$name[]= 'firends';
	echo $name[1]; */
?> 

<h4>Associate array (string array) check error</h4>
<?php
	/*$name = ['name1' => 'brother', 'name2' => 'friend'];
	print_r ($name); */
?> 


<h4>Relational Operator</h4>
<?php
	$a =7;
	$b =2;
	if($a > $b)
	{
		echo "$a is greater than $b";
	}
	else 
	{
		echo "$b is greater than $a";
	}
?> 

<h4>Logical Operator</h4>
<?php
	// $a = 35;
	$a = 20;
	$b =35;
	if($a >=35 && $b>=35)
	{
		echo "pass";
	}
	else 
	{
		echo "fail";
	}
?> 
<h4>or  Operator (one variable to satisfye excute the variable)</h4>
<?php
	$a = 35;
	$b =20;
	if($a >=35 || $b>=35)
	{
		echo "pass";
	}
	else 
	{
		echo "fail";
	}
?> 

<h4>Increment Decrement Operator</h4>
<?php
	$value = 5;
	$value++;
	echo "Post Increment: $value";
?> 
<br>
<?php
	$value = 5;	$value++; ++$value;
	echo "Pre Increment: $value";
?> 
<br>

<?php
	$value = 5;	$value++; ++$value;
	$number = $value++ * 3;
	echo "Post increment another type: $number";
?> 
<br>
<?php
	$value = 5;	$value++; ++$value;
	$number = $value++ * 3;
	$number = ++$value * 3;
	echo "Pre increment another type: $number";
?> 


