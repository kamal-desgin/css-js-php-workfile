<?php
session_start();
include("checklogin.php");
check_login();
?>
<!doctype html>
<html lang="en-us">
	<head>
		<title> Web Page </title>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">			
			<!-- google font -->
			<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext'>
			<!-- css stylesheet -->
			<link rel='stylesheet' href='assets/css/bootstrap.css'>
			<link rel="stylesheet" type="text/css" href="assets/css/style.css">
			<script src="assets/js/jquery.js"></script>
			<script src="assets/js/bootstrap.js"></script>
			
			<script src="https://code.jquery.com/jquery-3.3.1.slim.js"></script>
			

			
	</head>
	<body>
		<header>
			<div class="top-header">
				<div class="top-header-left">
					<ul class="info">
						<li><a href="tel:1234567890"><span class="glyphicon glyphicon-earphone"></span> 1234567890</a></li>
						<li><a href="mailto:admin@gmail.com"><span class="glyphicon glyphicon-envelope"></span> admin@gmail.com</a></li>
					</ul>
				</div>
				<div class="top-header-right">
					<ul class="info">
						<li> <a href="#"><?php echo $_SESSION['name'];?></a></li>
						<li> <a href="logout.php">Log Out</a></li>
					</ul>
				</div>
				
			</div>
			
				<div class="example3">
				  <nav class="navbar navbar-inverse navbar-static-top">
					<div class="container">
					  <div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://www.microshare.in/"><img src="assets/images/logo.png" alt="Microshare software Development">
						</a>
					  </div>
					  <div id="navbar3" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
						  <li class="active"><a href="#">Home</a></li>
						  <li><a href="#">About</a></li>
						  <li><a href="#">Contact</a></li>
						  <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
							  <li><a href="#">Action</a></li>
							  <li><a href="#">Another action</a></li>
							  <li><a href="#">Something else here</a></li>
							  <li class="divider"></li>
							  <li class="dropdown-header">Nav header</li>
							  <li><a href="#">Separated link</a></li>
							  <li><a href="#">One more separated link</a></li>
							</ul>
						  </li>				   
						</ul>
					  </div> <!--/.nav-collapse -->
					</div> <!--/.container-fluid -->
				  </nav>
				</div> <!-- nav end -->
		</header>

		
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2> ABOUT US</h2>
					<p> MICROSHARE Software Solutions Pvt Ltd is a promising start up which was incorporated on 17th July, 2015 by two developers with a vision to provide high end IT solutions to clients such as asp.net, JAVA, and website designing. 					Having an experience of 4 years of working in an IT development company, we expanded our services to ERP, SEO, Domain transfer, Domain registration, web hosting services E-Commerce, Magento, Word press , Android App +IOS support with proper certification.</p>
						<h3> How do we plan and work</h3>
							<p> At MICROSHARE, we follow the best practices of the industry and give importance to planning and effective designing. Our team of engineers plans effectively to identify the necessary activities and set goals to be achieved. With our systematic and rational approach, our engineers convert the given information into a design and ensure smooth functioning of processes. <br>
									The development stage is one of the most crucial steps hence; we give value to blueprints and prototype to include modifications and views given by our esteemed clients. Our working procedures are highly systematic and methodical. <br>
										Our process stage renders importance of implementation, monitoring and feedback and redesigning. MICROSHARE has worked with over 200 clients and has won great appreciation for setting new standards in the industry. Our service packages are highly affordable and cater to all kinds of small and big clients.</p>

                        <h3> Why us?</h3>
							<p>We have the best team web designers and developers who are highly experienced in creating a unique website which is highly responsive and appealing to enhance the growth of the business. With a website, a business enhances its reach to find new customers, markets and lead generations. It is the best way to be globally visible and increase awareness about your business. <br>
								Our team of web developers gives significant importance to aesthetics, compatibility, and ease of navigation, optimization techniques, appeal, content, and maintenance of the website. If your website is responsive, it becomes easy to read and navigate on various devices. Our web developers ensure that the website reflects your organizational objectives and helps them to achieve it. <br>
									Website maintenance is an integral part of designing and development that avoids any glitches and operational issues of the website. The website development company in Chennai focuses on achieving client satisfaction by providing customized services and maintaining long term relationships. </p>
				</div>
			</div>
		</div>
		
	
	
<footer>
	<p>&copy; 2018 <a href="http://www.microshare.in">www.microshare.in</a></p>
</footer>
	
</body>
</html> 