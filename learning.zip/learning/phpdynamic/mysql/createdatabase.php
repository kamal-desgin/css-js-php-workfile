<html>
   <head>
	  <title> <?php echo TITLE;?></title>
   </head>
   
   <body>
	   <?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			// $databasename = 'kamal_microshare';		
			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			// Create database
			$sql = "CREATE DATABASE login";
			if ($conn->query($sql) === TRUE) {
				echo "Database created successfully";
			} else {
				echo "Error creating database: " . $conn->error;
			}
						
			// Connectin close
			$conn->close();	 
		?> 
   </body>
</html>