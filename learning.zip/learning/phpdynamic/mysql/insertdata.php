<?php
$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "silambu_kscheme";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `ks_enquiry` (`id`, `name`, `email`, `mobile`, `course`, `message`, `created_at`, `status`) VALUES
(1, 'gdfgd', 'gdfg@gmail.com', 23423423, '2', 'sdf', '', 'A'),
(2, 'gdfgd', 'gdfg@gmail.com', 23423423, '2', 'fdsf', '', 'A'),
(3, 'gdfgdvcxc', 'gdfg@gmail.com', 23423423, '2', 'fsdf', '', 'A'),
(10, 'dsvzcxzcz', 'fdsf@redi.com', 43234, '1', '', '', 'E'),
(12, 'fdsgdfgdf', 'dsfsdf@gdf.sdf', 423423423, '1', '4fdsgdfgdf', '', 'A'),
(13, 'poo', 'flowereye99@gmail.com', 2147483647, '1', 'want to join', '', 'A'),
(14, 'poo', 'flowereye99@gmail.com', 2147483647, '1', 'want to join', '', 'A'),
(15, 'wemade', 'flowereye99@gmail.com', 2147483647, '1', ' ghyfghifhbi', '', 'A'),
(16, 'ramesh', 'ramesh@gmail.com', 2147483647, '11', ' need details', '', 'A'),
(17, 'noor', 'isyednoormohammed@gmail.com', 2147483647, '10', ' iuhiug', '', 'A'),
(18, 'A. P. MEGAVARNAN ', 'megatnpsc4092290@gmail.com', 2147483647, '1', ' ', '', 'A'),
(19, 'Krishnamani Sugumar', 'krishnamansakthivel.p@gmail.com', 2147483647, 'Select Course', ' I want know about tet exam coaching', '', 'A'),
(20, 'Sanjai', 'Sanjai9622@gmail.com', 2147483647, '12', ' ', '', 'A'),
(21, 'A.DHANUSHYA', 'thanuanand97@gmail.com', 2147483647, '11', ' ', '', 'A'),
(22, 'A.DHANUSHYA', 'thanuanand97@gmail.com', 2147483647, '11', ' ', '', 'A'),
(23, 'Ruby', 'rubymarial91@gmail.com', 2147483647, '1', ' ', '', 'A'),
(24, 'Jishnu s', 'sjishnu1995@gmail.com', 2147483647, '15', ' Course fee \r\nTiming', '', 'A'),
(25, 'Vanitha', 'vanithababu94@gmail.com', 2147483647, '1', ' ', '', 'A'),
(26, 'VASANTHI ', 'vasa.2494@gmail.com', 2147483647, '11', 'Is free course available for ibps exam?', '', 'A'),
(27, 'Vidhyashree. B', 'vidyabaskar220@gmail.com', 2147483647, '11', ' I have to learn for bank exams', '', 'A'),
(28, 'E.Theja', 'theja411000@gmail.com', 2147483647, '20', ' ', '', 'A'),
(29, 'RAMKUMAR', 'prk000555@gmail.com', 2147483647, '11', 'bank coaching classes required', '', 'A'),
(30, 'Anbarasi.J', 'anbu.jana.aj@gmail.com', 2147483647, '1', ' ', '', 'A'),
(31, 'Debraj Roy', 'debrajroy787@gmail.com', 892717679, '15', ' ', '', 'A'),
(32, 'JAGADEESAN R', 'jagadeesan46@gmail.com', 2147483647, '11', 'I need fees structure and batches available for ibps', '', 'A'),
(33, 'vimal raj', 'vraj12378@gmail.com', 2147483647, '12', ' ', '', 'A'),
(34, 'ASLIN SHARMILA A K', 'jenisharmila97@gmail.com', 2147483647, '11', ' ', '', 'A'),
(35, 'Saran', 'seshansaran456@gmail.com', 2147483647, '11', ' ', '', 'A'),
(36, 'Swathy. V. C', 'swathy.veluthemanacheerakuzhi@gmail.com', 2147483647, '15', ' Crash course', '', 'A'),
(37, 'kuzhanthaivelu.m', 'mkvelubtechmech@gmail.com', 2147483647, '1', ' ', '', 'A'),
(38, 'B.PRIYA', 'priyasribhagavan@gmail.com', 2147483647, '1', ' ', '', 'A'),
(39, 'jagan', 'jaganbala0@gmail.com', 2147483647, '1', ' fees, timing', '', 'A'),
(40, 'm.ishwarya', 'dineshish96@gmail.com', 2147483647, '1', ' ', '', 'A'),
(41, 'Nalina S', 'nalinasankar5@gmail.com', 2147483647, '11', ' Can I know the fees details ', '', 'A'),
(42, 'mohammed', 'isyednoormohammed@gmail.com', 2147483647, '11', ' looking bank coaching', '', 'A'),
(43, 'shamim', 'shamim@gmail.com', 2147483647, '12', ' i want to join rrb ', '', 'A'),
(44, 'Nalina S', 'nalinasankar5@gmail.com', 2147483647, '11', ' Can i know the fees details.', '', 'A'),
(45, 'PMk', 'premkumari.mc@gmail.com', 877, '1', ' ', '', 'A'),
(46, 'Pradeep', 'pradeepselvan.ps@gmail.com', 2147483647, '20', ' ', '', 'A'),
(47, 'Nalina S', 'nalinasankar5@gmail.com', 2147483647, '11', ' Can i know the fees details for bank exam coaching', '', 'A'),
(48, 'V raja', 'vraja@gamil.com', 2147483647, '1', ' ', '', 'A'),
(49, 'V raja', 'vraja@gamil.com', 2147483647, '1', ' ', '', 'A'),
(50, 'N Balaji', 'nbalaji@gmail.com', 2147483647, '20', ' ', '', 'A'),
(51, 'V raja', 'vraja@gamil.com', 2147483647, '1', ' 123', '', 'A')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
