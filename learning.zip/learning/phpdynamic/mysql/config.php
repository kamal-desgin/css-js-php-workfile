<html>
   <head>
	  <title> <?php echo TITLE;?></title>
   </head>
   
   <body>
	   <?php
			$servername = "localhost";
			$username = "root";
			$password = "";				
			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			echo "Connected successfully";
			
			// Connectin close
			$conn->close();	 
		?> 
   </body>
</html>