
<h2>1. Employee_Details</h2>
 
<?php
	include "config.php";
	$sql = "SELECT * FROM employee_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>2. Employee_Details single row</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where employeeID=9";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>3. In Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where employeeID in (1,3,5,12)";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

 <h4>4. First Letter Check - M</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where FirstName like 'M%'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>5. End Letter Check - oodu</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where Place like '%oodu'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>6. Like Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where FirstName like 'S%'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]."  ".$row["FirstName"]."   ".$row["LastName"]."  ".$row["Place"]."  ".$row["Country"]."  ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>7. AND Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where Country='India' and FirstName like '%A%'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>8. OR Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where Country='India' or FirstName like '%M%'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>9. NOT Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM employee_details where NOT FirstName like '%M%'";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
<h4>10. Select Particular columns only</h4>
<?php
	// include "config.php";
	$sql = "SELECT FirstName,Place from employee_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["FirstName"]."   ".$row["Place"]."  <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
 
 <h4>11. between Operator</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM meeting_details where MeetingDate between '2018-11-06' and '2018-11-12' ";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]."  ".$row["TimeTo"]." ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>
 
<h4>12. distinct statement</h4>
<?php
	// include "config.php";
	$sql = "SELECT distinct Country FROM employee_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["Country"]."  <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>13. Order by DESC Clause</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM meeting_details order by MeetingID desc";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]."  ".$row["TimeTo"]." ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>14. Order by ASC Clause</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM meeting_details order by MeetingTitle asc";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]."  ".$row["TimeTo"]." ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>15. Ordering by both DESC and ASC Clause</h4>
<?php
	// include "config.php";
	$sql = "SELECT MeetingTitle,MeetingID FROM meeting_details order by MeetingTitle asc, MeetingDate desc";
	// $sql = "SELECT * FROM meeting_details order by MeetingID asc, MeetingTitle desc";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			// echo " ".$row["MeetingID"]." ".$row["MeetingTitle"]."  <br>";
			echo " ".$row["MeetingTitle"]." ".$row["MeetingID"]."  <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>16. Insert Statement</h4>
<?php
	// include "config.php";
	// $sql = "INSERT INTO room_details(RoomName,RoomSize) values('Test Room','500')";
	if ($con->query($sql) === TRUE) {
    echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $con->error;
	}
?>

<h4>17. Update Statement</h4>
<?php
	// include "config.php";
	// $sql = "UPDATE room_details set RoomSize=10 where RoomID=7";
	if ($con->query($sql) === TRUE) {
    echo "New record Update successfully";
	} else {
		echo "Error Updating Record: " . $con->error;
	}
?>

<h4>18. Delete Statement</h4>
<?php
	// include "config.php";
	// $sql = "DELETE FROM room_details where RoomID=21";
	if ($con->query($sql) === TRUE) {
    echo "Select record Deleted successfully";
	} else {
		echo "Error Deleteing Record: " . $con->error;
	}
?>

<h4>19. alias NAME (check no result)</h4>
<?php
	// include "config.php";
	// $sql = "SELECT FirstName as TestName FROM employee_details";
	   // $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "  ".$row["FirstName"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>20. is null (check (NULL Values only display)</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM general_details where IsTest IS NULL";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "  ".$row["GeneralID"]." ".$row["Name"]." ".$row["Age"]." ".$row["IsTest"]." ".$row["TestRoomID"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>21. is not null (check (NOT NULL Values no display)</h4>
<?php
	// include "config.php";
	$sql = "SELECT * FROM general_details where IsTest IS NOT NULL";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "  ".$row["GeneralID"]." ".$row["Name"]." ".$row["Age"]." ".$row["IsTest"]." ".$row["TestRoomID"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>22. Min() Function</h4>
<?php
	// include "config.php";
	$sql = "SELECT min(RoomSize) as RoomSize From room_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["RoomSize"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>23. Max() Function</h4>
<?php
	// include "config.php";
	$sql = "SELECT max(RoomSize) as RoomSize From room_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["RoomSize"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>24. Count() Function</h4>
<?php
	// include "config.php";
	$sql = "SELECT count(*) TotalCount From room_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["TotalCount"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>25. avg() Function</h4>
<?php
	// include "config.php";
	$sql = "SELECT avg(RoomSize) AverageRoomSize From room_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["AverageRoomSize"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>26. sum() Function</h4>
<?php
	// include "config.php";
	$sql = "SELECT sum(RoomSize) TotalRoomAvailable From room_details";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["TotalRoomAvailable"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>27. Joining Two Tables</h4>
<?php
	// include "config.php";
       // $sql = "SELECT * From meeting_employees join meeting_details";  // one row all row to call 
       $sql = "SELECT * From meeting_employees ME join meeting_details MD on MD.MeetingID=ME.MeetingID where ME.MeetingID=2"; //only specific id call
		$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MemberID"]." ".$row["EmployeeID"]." ".$row["MeetingID"]."  ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]." ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>28. Joining Three Tables</h4>
<?php
	// include "config.php";
       // $sql = "SELECT * From meeting_employees join meeting_details join employee_details";  // one row all row to call 
       // $sql = "SELECT * From meeting_employees ME join meeting_details MD on MD.MeetingID=ME.MeetingID join employee_details ED on ED.EmployeeID=ME.EmployeeID where ME.MeetingID=2"; //only specific id call
       $sql = "SELECT * From meeting_employees ME join meeting_details MD on MD.MeetingID=ME.MeetingID join employee_details ED on ED.EmployeeID=ME.EmployeeID where ME.MeetingID in (2,3)"; //only specific id call//in all data
		$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MemberID"]." ".$row["EmployeeID"]." ".$row["MeetingID"]."  ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]." ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]."  ".$row["EmployeeID"]." ".$row["FirstName"]."  ".$row["LastName"]." ".$row["Place"]." ".$row["Country"]." ".$row["PhoneNo"]."<br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>29. Join vs Left join-1 (check null values not display)</h4>
<?php
	// include "config.php";
       // $sql = "SELECT * From general_details GD join room_details RD on GD.TestRoomID=RD.RoomID";  // Define a table name 
       $sql = "SELECT * From general_details join room_details on TestRoomID=RoomID";  // Not define table name 
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["GeneralID"]." ".$row["Name"]." ".$row["Age"]."  ".$row["IsTest"]." ".$row["TestRoomID"]." ".$row["RoomID"]." ".$row["RoomName"]." ".$row["RoomSize"]."  <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>30. Join vs Left join-2  (check null values not display)</h4>
<?php
	// include "config.php";
       $sql = "SELECT * From general_details GD left join room_details RD on GD.GeneralID=RD.RoomID";  // Define a table name 
	   //$sql = "SELECT * From general_details GD right join room_details RD on GD.GeneralID=RD.RoomID";  //right join a table all name view
       // $sql = "SELECT * From general_details  left join room_details  on GeneralID=RoomID";  // Not define table name 
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["GeneralID"]." ".$row["Name"]." ".$row["Age"]."  ".$row["IsTest"]." ".$row["TestRoomID"]." ".$row["RoomID"]." ".$row["RoomName"]." ".$row["RoomSize"]."  <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>31. Self Join (check null values only view)</h4>
<?php
	// include "config.php";
       $sql = "SELECT * From general_details GD1 join general_details GD2 where GD1.GeneralID=GD2.TestRoomID";  // compare two columns in table
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["GeneralID"]." ".$row["Name"]." ".$row["Age"]."  ".$row["IsTest"]." ".$row["TestRoomID"]." <br>";
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>32. Union Operator (First Two Row not in Database only in view)</h4>
<?php
	// include "config.php";
       $sql = "SELECT 0 MeetingID, '1PM' TimeFrom, '1PM' TimeTo, 0 RoomID, 'Test1' MeetingTitle, '2018-11-18' MeetingDate From meeting_details  
					UNION 
			   SELECT 0 MeetingID, '12PM' TimeFrom, '10PM' TimeTo, 10 RoomID, 'Test2' MeetingTitle, '2018-11-18' MeetingDate From meeting_details
			        UNION SELECT * FROM meeting_details";   //only view to include data
	   // $sql = "SELECT * FROM meeting_details";   //table datas
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>33. Union vs Union all-1  (not display duplicate row [distinct rows]</h4>
<?php
	// include "config.php";
       $sql = "SELECT * FROM meeting_details UNION SELECT * FROM meeting_details";   //only view to include data
	   // $sql = "SELECT * FROM meeting_details";   //table datas
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>34. Union vs Union all-2  (display duplicate [repeated 20 rows again]</h4>
<?php
	// include "config.php";
       $sql = "SELECT * FROM meeting_details UNION All SELECT * FROM meeting_details";   
	   // $sql = "SELECT * FROM meeting_details";   //table datas
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>


<h4>35. Count Function widthout group by (check no result)</h4>
<?php
	// include "config.php";
       // $sql = "SELECT count(RoomID), * FROM meeting_details";  
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			// echo "  ".$row["count(RoomID)"]." ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>36. Count Function width group by</h4>
<?php
	// include "config.php";
       $sql = "SELECT count(RoomID), RoomID, MeetingTitle, MeetingID FROM meeting_details group by roomid";  
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "  ".$row["count(RoomID)"]." ".$row["MeetingID"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>37. Having Clause (check no result)</h4>
<?php
	// include "config.php";
       $sql = "SELECT count(RoomID),* FROM meeting_details group by roomid having count(RoomID)>2";  
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "  ".$row["count(RoomID)"]." ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>

<h4>38. Exists Operator (check no result)</h4>
<?php
	// include "config.php";
       $sql = "SELECT * FROM meeting_details where exists(select * FROM room_details where RoomSize>80)";  
       // $sql = "SELECT * FROM meeting_details";  
       $result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo " ".$row["MeetingID"]." ".$row["TimeFrom"]." ".$row["TimeTo"]."  ".$row["RoomID"]." ".$row["MeetingTitle"]." ".$row["MeetingDate"]." <br>";
			
		}
	} 
	else {
		echo "0 results";
	}
?>











 
 <h2> Users</h2> 

<?php

	// include "config.php";
	$sql = "SELECT id, password FROM users";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
    // output data of each row
		while($row = $result->fetch_assoc()) {
			echo "id: " . $row["id"]. " " . $row["password"]. "<br>";
		}
	} 
	else {
		echo "0 results";
	} 
?> 