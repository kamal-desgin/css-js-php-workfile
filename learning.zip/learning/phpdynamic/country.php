<?php
 
 $con=new mysqli ("localhost", "root", "", "dynamic");
?>
<!doctype html>
<html>
	<head>
		<title> Country lesect </title>
		<style>
			.load {
				padding:15px;
				height:auto;
				width: 500px;
				margin: 25px auto;
				background: #eeeeee;
				margin-top:50px;
				border-top:50px;
				box-shadow: 10px 10px 5px 5xp gray;
			}
			#country{
			}
		</style>
	</head>
		<body>
			<div class="load">
				<h1> Dependent ListBox</h1>
				<label> Select state</label>
				<select id="country">
					<option value=""> select</option>
				<?php
				// single table value get select box
				// countrylist Table Name
				
				/* $sql="select * from countrylist";
					$res=$con->query($sql);
					while($row=$res->fetch_assoc())
					{
						echo "<option value='{$row["sno"]}'>{$row["state"]}</option>";
					} */
				?>
				
				 <?php
				 // TWO table value get select box
				 // districts Table Name
				 
				$sql="select * from state";
					$res=$con->query($sql);
					while($row=$res->fetch_assoc())
					{
						echo "<option value='{$row["state_id"]}'>{$row["state_name"]}</option>";
					} 
				?>
				
				
				</select> <br>
				 
				 <label> Select Districts </label>
				 <select id="state">
				 <option value=""> select</option>
				 </select> 
				 
				 <button id="cname">State Name</button>
				 <button id="cid">State ID</button>
				 
				 
		
			
					 
			<script src="assets/js/jquery.js"></script>
			<script src="assets/jquery.min.js"></script>
			<script>
				$(document).ready(function() {
					//State id
					$("#cid").click (function(){
						alert($("#country").val());
					});
					//state name
					$("#cname").click (function(){
						alert($("#country option:selected").text());
					});
					
					
					$("#country").change(function(){
						cid=$(this).val(); //country value stored cid 
						$.post("state.php", {id:cid}, function(data){
							$("#state").html(data);
						});	
					});
				});
			</script>
			
			
			</div>
		</body>
</html>

