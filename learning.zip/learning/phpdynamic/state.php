<?php
// single table value get select box
// countrylist Table Name
/*
$con=new mysqli ("localhost", "root", "", "dynamic");
$sql="select * from countrylist where sno ={$_POST["id"]}";
$res=$con->query ($sql);

echo "<option value=''>select </option>";
	while($row=$res->fetch_assoc())
	{
		echo "<option value='{$row["sno"]}'>{$row["state"]}</option>";
	}*/
?>


<?php
// Two table value get select box
// districts Table Name

$con=new mysqli ("localhost", "root", "", "dynamic");
$sql="select * from districts where state_id ={$_POST["id"]}";
$res=$con->query ($sql);

echo "<option value=''>select </option>";
	while($row=$res->fetch_assoc())
	{
		echo "<option value='{$row["districts_id"]}'>{$row["districts_name"]}</option>";
	}  
?>
