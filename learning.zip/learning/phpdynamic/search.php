



<!DOCTYPE html>
<html>
	<head>
		<title>Search</title>
	</head>
	<body>


<form action="" method="post">
  <input name="search" type="search" autofocus>
  <input type="submit" name="button">
</form>

<table>
  <tr>
	<td><b>First Name</td>
	<td></td>
	<td><b>Last Name</td>
</tr>



<?php
$con=mysql_connect('localhost', 'root', '');
$db=mysql_select_db('dynamic');


if(isset($_POST['button'])){    //trigger button click

  $search=$_POST['search'];

  $query=mysql_query("select * from crud where NAME like '%{$search}%' || CITY like '%{$search}%' ");

if (mysql_num_rows($query) > 0) {
  while ($row = mysql_fetch_array($query)) {
    echo "<tr><td>".$row['NAME']."</td><td></td><td>".$row['CITY']."</td></tr>";
  }
}else{
    echo "No employee Found<br><br>";
  }

}else{                          //while not in use of search  returns all the values
  $query=mysql_query("select * from crud");

  while ($row = mysql_fetch_array($query)) {
    echo "<tr><td>".$row['NAME']."</td><td></td><td>".$row['CITY']."</td></tr>";
  }
}

mysql_close(); 
?>

	</body>
</html>  


