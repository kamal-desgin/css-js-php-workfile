<!doctype html>
<html lang="en-us">
	<head>
		<title> Web Page </title>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">			
			<!-- google font -->
			<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext'>
			<!-- css stylesheet -->
			<link rel='stylesheet' href='assets/css/bootstrap.css'>
			<link rel="stylesheet" type="text/css" href="assets/css/style.css">
			<script src="assets/js/jquery.js"></script>
			<script src="assets/js/bootstrap.js"></script>
			
			<script src="https://code.jquery.com/jquery-3.3.1.slim.js"></script>
			<script src='https://www.google.com/recaptcha/api.js'></script>

			
	</head>
	<body>
		<header>
			<div class="top-header">
				<div class="top-header-left">
					<ul class="info">
						<li><a href="tel:1234567890"><span class="glyphicon glyphicon-earphone"></span> 1234567890</a></li>
						<li><a href="mailto:admin@gmail.com"><span class="glyphicon glyphicon-envelope"></span> admin@gmail.com</a></li>
					</ul>
				</div>
				<div class="top-header-right">
					<ul class="info">
						<li> <a href="#"><?php echo $_SESSION['name'];?></a></li>
						<li> <a href="logout.php">Log Out</a></li>
					</ul>
				</div>
				
			</div>
			
				<div class="example3">
				  <nav class="navbar navbar-inverse navbar-static-top">
					<div class="container">
					  <div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://www.microshare.in/"><img src="assets/images/logo.png" alt="Microshare software Development">
						</a>
					  </div>
					  <div id="navbar3" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
						  <li class="active"><a href="#">Home</a></li>
						  <li><a href="#">About</a></li>
						  <li><a href="#">Contact</a></li>
						  <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
							  <li><a href="#">Action</a></li>
							  <li><a href="#">Another action</a></li>
							  <li><a href="#">Something else here</a></li>
							  <li class="divider"></li>
							  <li class="dropdown-header">Nav header</li>
							  <li><a href="#">Separated link</a></li>
							  <li><a href="#">One more separated link</a></li>
							</ul>
						  </li>				   
						</ul>
					  </div> <!--/.nav-collapse -->
					</div> <!--/.container-fluid -->
				  </nav>
				</div> <!-- nav end -->
		</header>

		
<div class="jumbotron jumbotron-sm mt-20">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <h3 class="h2">Contact us <small>File upload</small></h3>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
			  <form action="contactus.php" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                                <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required" />
							</div>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <select id="subject" name="subjects" class="form-control" required="required">
                                <option value="" selected="">Choose One:</option>
                                <option value="service">General Customer Service</option>
                                <option value="suggestions">Suggestions</option>
                                <option value="product">Product Support</option>
                            </select>
                        </div>						 
						<div class="form-group">
							<label for="exampleInputFile">File Upload</label>
							<input type="file" class="form-control-file"name="fileToUpload" id="fileToUpload" aria-describedby="fileHelp">
							<small id="fileHelp" class="form-text text-muted">Please Slectet only JPG, JPEG, PNG & GIF.</small>
					    </div>					
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">  Message</label>
                            <textarea name="message" id="message" class="form-control" rows="6" cols="25" required="required" placeholder="Message"></textarea>
                        </div>
						<div class="form-group">
						  <div class="g-recaptcha" data-sitekey="6Ldhtm0UAAAAAIFYSHy7HrCo0f2sLUADPS4qye8n"></div>
					    </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="btnContactUs"> Send Message</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
if(isset($_POST['submit'])):
    if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])):
        //your site secret key
        $secret = '6Ldhtm0UAAAAAL6LAHiyVHp0BdZdIGTHnWwwbSDt';
        //get verify response data
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if($responseData->success):
            //contact form submission code
            $name = !empty($_POST['name'])?$_POST['name']:'';
            $email = !empty($_POST['email'])?$_POST['email']:'';
            $subjects = !empty($_POST['subjects'])?$_POST['subjects']:'';            
            $message = !empty($_POST['message'])?$_POST['message']:'';
			
			// php file upload validation
			$target_dir = "http://microsharetech.com/ms_work/uploads/";
			$target_file = "uploads/" . basename($_FILES["fileToUpload"]["name"]);
			$target_file_send = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			// $attachment = chunk_split(base64_encode(file_get_contents($_FILES['fileToUpload']['tmp_name'])));
			$uploadOk = 1;
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));			
			// Check if image file is a actual image or fake image
			$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				if($check !== false) {
					echo "File is an image - " . $check["mime"] . ".";
					$uploadOk = 1;
				} else {
					echo "File is not an image.";
					$uploadOk = 0;
				}
			
			// Check if file already exists
			if (file_exists($target_file)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}
			// Check file size
			if ($_FILES["fileToUpload"]["size"] > 500000) {
				echo "Sorry, your file is too large.";
				$uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" )
				{
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
				}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				
        	// php file upload validation
            
            $to = 'kamal.microshare@gmail.com';
            $subject = 'Microshare form upload Enquiry Form';
            $htmlContent = " <h1>Contact request details</h1>
							<p><b>Name: </b>".$name."</p>
							<p><b>Email: </b>".$email."</p>
							<p><b>Subject: </b>".$subjects."</p>
							<p><b>Message: </b>".$message."</p>
							<p><b>Attachment: </b>".$target_file_send."</p> ";							
		    
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            // More headers
            $headers .= 'From:'.$name.' <'.$email.'>' . "\r\n";
            //send email
            @mail($to,$subject,$htmlContent,$headers);
            
            //$succMsg = 'Your contact request have submitted successfully.';
			echo "<script>alert('Your contact request have submitted successfully.');</script>";
			echo "<script>window.location.href='contactus.php';</script>";
			
			} else {
					echo "Sorry, there was an error uploading your file.";
				}
			}
        else:
            //$errMsg = 'Robot verification failed, please try again.';
			echo "<script>alert('Robot verification failed, please try again.');</script>";
			echo "<script>window.location.href='contactus.php';</script>";
        endif;
    else:
        //$errMsg = 'Please click on the reCAPTCHA box.';
		echo "<script>alert('Please click on the reCAPTCHA box.');</script>";
		echo "<script>window.location.href='contactus.php';</script>";
    endif;
else:
    $errMsg = '';
    $succMsg = '';
endif;
?>

	
	
<footer>
	<p>&copy; 2018 <a href="http://www.microshare.in">www.microshare.in</a></p>
</footer>
	
</body>
</html> 