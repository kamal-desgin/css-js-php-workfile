<?php
	include "config.php";
?>
<!DOCTYPE html>
<html lang="en-us">
	<head>
		<title> Microshare Software Solutions Pvt Ltd.</title>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">			
			<!-- google font -->
			<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext'>
			
			<!-- css stylesheet -->
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
			
			
			<link rel="stylesheet" type="text/css" href="assets/font-awesome.min.css">
			
			
			<script src="https://code.jquery.com/jquery-3.3.1.slim.js"></script>
			<script src='https://www.google.com/recaptcha/api.js'></script>




	</head>
	<body>
		<header>
			<div class="top-header">
				<div class="top-header-left">
					<ul class="info">
						<li><a href="tel:1234567890"><span class="glyphicon glyphicon-earphone"></span> 1234567890</a></li>
						<li><a href="mailto:admin@gmail.com"><span class="glyphicon glyphicon-envelope"></span> admin@gmail.com</a></li>
					</ul>
				</div>
				<div class="top-header-right">
					<ul class="info">
						<!--<li> <a href="#"><?php echo $_SESSION['name'];?></a></li>-->
						<li> <a href="logout.php">Log Out</a></li>
					</ul>
				</div>
				
			</div>
			
				<div class="example3">
				  <nav class="navbar navbar-inverse navbar-static-top">
					<div class="container">
					  <div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://www.microshare.in/"><img src="assets/images/logo.png" alt="Microshare software Development">
						</a>
					  </div>
					  <div id="navbar3" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
						  <li class="active"><a href="#">Home</a></li>
						  <li><a href="#">About</a></li>
						  <li><a href="#">Contact</a></li>
						  <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
							  <li><a href="#">Action</a></li>
							  <li><a href="#">Another action</a></li>
							  <li><a href="#">Something else here</a></li>
							  <li class="divider"></li>
							  <li class="dropdown-header">Nav header</li>
							  <li><a href="#">Separated link</a></li>
							  <li><a href="#">One more separated link</a></li>
							</ul>
						  </li>				   
						</ul>
					  </div> <!--/.nav-collapse -->
					</div> <!--/.container-fluid -->
				  </nav>
				</div> <!-- nav end -->
		</header>

		
<div class="jumbotron jumbotron-sm mt-20">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <h3 class="h2">Dynamic Data Save & Saved Data to View</h3>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="well well-sm">
			<h4><span class='glyphicon glyphicon-edit'></span> ADD Data</h4>
			  <form id="frm" action="crud.php" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="name"> Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="age">Age</label>
                            
                                <input type="text" name="age" class="form-control" id="age" placeholder="Enter age" required="required" />
                        </div>
						 <div class="form-group">
                            <label for="city">city</label>
                                <input type="text" name="city" class="form-control" id="city" placeholder="Enter city" required="required" />
                        </div>
					   <div class="form-group">
                            <label for="city"></label>
                                <input type="hidden" name="id" class="form-control" id="id" value="0" placeholder="" required="required" />
                        </div>
											
                    </div>                   
                    <div class="col-md-12">
                        <button type="button" id="save" class="btn btn-success pull-right" name="submit" id="btnContactUs"> Save Data</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
		<div class="col-md-8" id="output">
				<!--- output view --->
           
        </div>
    </div>
</div>

	<script>
		 $(document).ready(function() {
			// alert("sdf");
			// $("#output").html("view.php");
			$("#output").load("view.php");
			$("#save").click(function(){
			// alert("sdf");	
			
			
			var id=$("#id").val();
			if(id==0) 
				{
					$.ajax({
						url: "insert.php",
						type: "post",
						data: $("#frm").serialize(),  //all data one by one store
						success:function(d)
						{
							$("#output").load("view.php");
							$("<tr></tr>").html(d).appendTo(".table");
							$("#frm")[0].reset();  //form reset data used
							$("#id").val(0);  //data id reset used
						}
					});
				}
				else
				{
					// alert("update");
					$.ajax({
						url: "update.php",
						type: "post",
						data: $("#frm").serialize(),  //all data one by one store
						success:function(d)
						{
							$("#output").load("view.php");
							$("#frm")[0].reset();  //form reset data used
							$("#id").val(0);  //data id reset used
						}
					});
				}
			});
			
			//delete code
			$(document).on("click",".del", function() {
			var del=$(this);
			var id=$(this).attr("data-id");
				// alert(id);
				$.ajax({
				url: "delete.php",
				type: "post",
				data: {id:id},
				success:function()
					{
						del.closest("tr").hide();
					}
				});
			});
			
			//update code
			$(document).on("click",".edit", function() {
			var row=$(this);
			var id=$(this).attr("data-id");
				$("#id").val(id);
				
				// id  td:eq(0) not calculated table
				
				var name=row.closest("tr").find("td:eq(1)").text();
				$("#name").val(name);
				
				var age=row.closest("tr").find("td:eq(2)").text();
				$("#age").val(age);
				
				var city=row.closest("tr").find("td:eq(3)").text();
				$("#city").val(city);
			});

	 });
   </script>

<footer>
	<p>&copy; 2018 <a href="http://www.microshare.in">www.microshare.in</a></p>
</footer>
	
	
	<script src="assets/jquery.min.js"></script>
</body>
</html> 