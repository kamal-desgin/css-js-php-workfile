<?php
 include "config.php";
  
	// print_r($_POST);
	

	    $name=$_POST["name"];
		$age=$_POST["age"];
		$city=$_POST["city"];

		$sql="INSERT INTO crud (NAME, AGE, CITY) values('{$name}','{$age}','{$city}')";
		$con->query($sql);	
		
		/* if($con->query($sql))
			{
				echo "Data saved";
			} */
		
		$id=$con->insert_id;  //insert data to delete
		
		echo "<td> {$name}</td>";
		echo "<td> {$age}</td>";
		echo "<td> {$city}</td>";
		echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["ID"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
		echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["ID"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
?> 