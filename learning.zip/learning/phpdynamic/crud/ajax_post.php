<script>
	 $(document).ready(function() {
		//alert('data');
		  $("#save").click(function(){
				$.ajax({
					url:"quotaion_ajax_action.php",
					dataType:"application/json",
					type:"POST",
					async: false,
					proccessData: false,
					data:$("#quotaion_form").serialize(),  
					success:function(response)
					{
						alert(response);
					},
					error:function(xhr, ajaxOptions, thrownError){alert(xhr.responseText); ShowMessage("??? ?? ?????? ??????? ????","fail");}
				})
		  });
	 });
</script>