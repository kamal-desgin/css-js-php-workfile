<?php
	include "config.php";
	
	$sql="delete from crud where id=" .$_POST["id"];
	$con->query($sql);
?>