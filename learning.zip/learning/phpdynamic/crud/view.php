				
				<?php
					include "config.php";
				?>
				
				<div class="table responsive">
					<table class="table table-bordered">
						<tr>
							<th>SNO</th>
							<th>NAME</th>
							<th>AGE</th>
							<th>CITY</th>
							<th>EDIT </th>
							<th>DELETE </th>
						</tr>
						
						<?php
							$sql="select * from crud";
							$result=$con->query($sql);
							
							if($result->num_rows > 0)
							{
								$i=0;
								while($row = $result->fetch_assoc())
								{
									 $i++;
									echo "<tr>";
									echo "<td> {$i} </td>";
									echo "<td> {$row["NAME"]} </td>";
									echo "<td> {$row["AGE"]} </td>";
									echo "<td> {$row["CITY"]} </td>";
									echo "<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["ID"]}'> <span class='glyphicon glyphicon-edit'></span>  </button></td>";
									echo "<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["ID"]}'> <span class='glyphicon glyphicon-trash'></span>  </button></td>";
									echo "</tr>";
								}
							}
						?>
						
					</table>
				</div>
				
		