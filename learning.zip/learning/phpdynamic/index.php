<?php session_start();
require_once('config.php');

//Code for Registration 
if(isset($_POST['signup']))
{
	$fname=$_POST['fname'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$contact=$_POST['contact'];
	$enc_password=md5($password);
	$a=date('Y-m-d');
	$msg=mysqli_query($con,"insert into users(fname,email,password,contactno,posting_date) values('$fname','$email','$enc_password','$contact','$a')");
	if($msg)
		{
			echo "<script>alert('Register successfully');</script>";
		}
}

// Code for login system
if(isset($_POST['login']))
{
$password=$_POST['password'];
$dec_password=md5($password);
$useremail=$_POST['uemail'];

$ret= mysqli_query($con,"SELECT * FROM users WHERE email='$useremail' and password='$dec_password'");
$num=mysqli_fetch_array($ret);
	if($num>0)
		{
		$extra="about.php";
		$_SESSION['login']=$_POST['uemail'];
		$_SESSION['id']=$num['id'];
		$_SESSION['name']=$num['fname'];
		$host=$_SERVER['HTTP_HOST'];
		$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		header("location:http://$host$uri/$extra");
		exit();
		}
	else
		{
		echo "<script>alert('Invalid username or password');</script>";
		$extra="index.php";
		$host  = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		//header("location:http://$host$uri/$extra");
		exit();
		}
}

// change Password system

if(isset($_POST['change']))
{
	//check fields
	$oldpassword =md5(@$_POST['oldpassword']);
	$newpassword = md5(@$_POST['newpassword']);
	$repeatnewpassword =md5(@$_POST['repeatnewpassword']);
	//check password against db
	//connect to db
	$queryget = mysqli_query ($con,"SELECT password FROM users WHERE id='$id'")or die ("Query didnt work");
	
	$row = mysqli_fetch_array($queryget);
	$oldpassworddb = $row ['password'];
	//check passwords
	if($oldpassword==$oldpassworddb)
		{
		//check the new password
			if ($newpassword==$repeatnewpassword)
				{
				//succes
				//change password in db
				$querychange = mysqli_query ($con,"UPTADE users SET password='$newpassword' WHERE fname='$fname'");
				session_destroy();
				die ("Your password has been changed.<a href='index.php'>Return </a>to the main page");
				}
		else 
			die ("New password dont match!");
		}
	else 
		die("Old password doesnt match!");
}


//Code for Forgot Password
/* if(isset($_POST) & !empty($_POST)){
	$femail = mysqli_real_escape_string($con,"select email,password from users where email='".$_POST['femail']."'");
	$sql = "SELECT * FROM `users` WHERE email = '$femail'";
	$res = mysqli_query($con, $sql);
	$count = mysqli_num_rows($res);
	if($count == 1){
		echo "Send email to user with password";
	}else{
		echo "User name does not exist in database";
	}
}*/

if(isset($_POST['send']))
	{
	$row1=mysqli_query($con,"select email,password from users where email='".$_POST['femail']."'");
	$row2=mysql_fetch_array($row1);
	if($row2>0)
		{
		$email = $row2['email'];
		$subject = "Information about your password";
		$password=$row2['password'];
		$message = "Your password is ".$password;
		mail($email, $subject, $message, "From: $email");
		echo  "<script>alert('Your Password has been sent Successfully');</script>";
		}
	else
		{
		echo "<script>alert('Email not register with us');</script>";	
		}
	} 
?>


<!doctype html>
<html lang="en-us">
	<head>
		<title> Web Page </title>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">			
			<!-- google font -->
			<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext'>
			<!-- css stylesheet -->
			<link rel='stylesheet' href='assets/css/bootstrap.css'>
			<link rel='stylesheet' href='assets/css/responsive.css'>
			<link rel="stylesheet" type="text/css" href="assets/css/style.css">
			<script src="assets/js/jquery.js"></script>
			<script src="assets/js/bootstrap.js"></script>
			
			<script src="https://code.jquery.com/jquery-3.3.1.slim.js"></script>
			

			
	</head>
	<body>
		<header>
			<div class="top-header">
				<div class="top-header-left">
					<ul class="info">
						<li><a href="tel:1234567890"><span class="glyphicon glyphicon-earphone"></span> 1234567890</a></li>
						<li><a href="mailto:admin@gmail.com"><span class="glyphicon glyphicon-envelope"></span> admin@gmail.com</a></li>
					</ul>
				</div>
				<div class="top-header-right">
					<ul class="info">
						<li><a href="#" data-toggle="modal" data-target="#signin"><span class="glyphicon glyphicon-user"></span> log in</a></li>
						<li><a href="#" data-toggle="modal" data-target="#signup"> Sign up</a></li>
					</ul>
				</div>
				
			</div>
			
				<div class="example3">
				  <nav class="navbar navbar-inverse navbar-static-top">
					<div class="container">
					  <div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://www.microshare.in/"><img src="assets/images/logo.png" alt="Microshare software Development">
						</a>
					  </div>
					  <div id="navbar3" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
						  <li class="active"><a href="#">Home</a></li>
						  <li><a href="#">About</a></li>
						  <li><a href="#">Contact</a></li>
						  <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
							  <li><a href="#">Action</a></li>
							  <li><a href="#">Another action</a></li>
							  <li><a href="#">Something else here</a></li>
							  <li class="divider"></li>
							  <li class="dropdown-header">Nav header</li>
							  <li><a href="#">Separated link</a></li>
							  <li><a href="#">One more separated link</a></li>
							</ul>
						  </li>				   
						</ul>
					  </div> <!--/.nav-collapse -->
					</div> <!--/.container-fluid -->
				  </nav>
				</div> <!-- nav end -->
		</header>

		
		<!-- slider start -->
			
			<div id="myCarousel" class="carousel slide mt-20" data-ride="carousel">
			  <!-- Indicators -->
			  <ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>
			  </ol>

			  <!-- Wrapper for slides -->
			  <div class="carousel-inner">
				<div class="item active">
				  <img src="assets/images/slider/1.jpg" alt="software Development">
				</div>

				<div class="item">
				 <img src="assets/images/slider/2.jpg" alt="software Development">
				</div>

				<div class="item">
				 <img src="assets/images/slider/3.jpg" alt="software Development">
				</div>
			  </div>

			  <!-- Left and right controls -->
			  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left"></span>
				<span class="sr-only">Previous</span>
			  </a>
			  <a class="right carousel-control" href="#myCarousel" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right"></span>
				<span class="sr-only">Next</span>
			  </a>
			</div>
		<!-- slider END -->
		
		
	<!-- login form section -->	
		<div class="container">			
		  <!-- Modal -->
		  <div class="modal fade" id="signup" role="dialog">
			<div class="modal-dialog">			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Registration Form</h4>
				</div>
				<div class="modal-body">
					  <form name="registration" method="post" action="" enctype="multipart/form-data">
							<fieldset>
								<div class="col-sm-12">
									<div class="form-group">
										<label>User Name *</label>
										<input type="text" name="fname" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label> E-mail</label>
										<input type="email" name="email" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label>Password</label>
										<input type="text" name="password" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label> Contact No</label>
										<input type="text" name="contact" class="form-control" required>
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="form-group">
										<button class="btn-send" type="reset">Reset</button>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group text-right">
										<button class="btn-send" type="submit" name="signup" >Create an account</button>
									</div>
								</div>								
							</fieldset>
				  </form>
				</div>				
			  </div>      
			</div>
		  </div>  
		  
		  <div class="modal fade" id="signin" role="dialog">
			<div class="modal-dialog">
				
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Log in to user</h4>
				</div>
				<div class="modal-body">
					  <form name="login" action="" method="post">
							<fieldset>
								<div class="col-sm-12">
									<div class="form-group">
										<label>User email address *</label>
										<input type="text" name="uemail" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label>Password</label>
										<input type="password" name="password" class="form-control" required>
									</div>
								</div>
								
								<div class="col-sm-4">
									<div class="form-group">
										<button class="btn-send" name="login" type="submit">login</button>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group text-right">
										<button class="btn-send"><a href="#" data-toggle="modal" data-target="#forgot">Forgot Password</a></button>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group text-right">
										<button class="btn-send"><a href="#" data-toggle="modal" data-target="#change">Change Password</a></button>
									</div>
								</div>
								
							</fieldset>
						</form>
				</div>				
			  </div>      
			</div>
		  </div> 
<!--- forgot password ---->
		<div class="modal fade" id="forgot" role="dialog">
			<div class="modal-dialog">			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Forgot Password</h4>
				</div>
				<div class="modal-body">
					  <form name="login" action="" method="post">
							<fieldset>
								<div class="col-sm-12">
									<div class="form-group">
										<label>User email address *</label>
										<input type="email" name="femail" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<button class="btn-send" name="send" type="submit">Submit Email</button>
									</div>
								</div>
							</fieldset>
						</form>
				</div>				
			  </div>      
			</div>
		  </div>
<!--- forgot password ---->

<!--- change password ---->
		<div class="modal fade" id="change" role="dialog">
			<div class="modal-dialog">			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Forgot Password</h4>
				</div>
				<div class="modal-body">
					  <form name="change" action="" method="post">
							<fieldset>
								<div class="col-sm-12">
									<div class="form-group">
										<label>Old password *</label>
										<input type="password" name="oldpassword" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label>New password *</label>
										<input type="password" name="newpassword" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label>Confirm Password *</label>
										<input type="password" name="repeatnewpassword" class="form-control" required>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<button class="btn-send" name="change" type="submit" value="Change password">Submit Email</button>
									</div>
								</div>
							</fieldset>
						</form>
				</div>				
			  </div>      
			</div>
		  </div>
<!--- change password ---->
		  
		</div>  
		<!-- login form section -->
	
<footer>
	<p>&copy; 2018 <a href="http://www.microshare.in">www.microshare.in</a></p>
</footer>
	
</body>
</html> 