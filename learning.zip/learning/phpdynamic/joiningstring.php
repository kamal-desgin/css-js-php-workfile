<?php
$certificate= '25\\';  // workshopcode
$certificate.= 'CHE\\'; // city of workshop
$certificate.= 'M\\'; // course code
$certificate.= '001\\'; // Roll no
$certificate.= date('y'); // Year

echo "$certificate"; 
?>