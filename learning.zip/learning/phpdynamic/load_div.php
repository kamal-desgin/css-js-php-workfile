<script src="ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"; type="text/javascript"> </script>
<button id="fcluns" type="button" onclick="loadpage(this.id)">FC LUNs</button>
<div id="Table"></div>
<script type="text/javascript"> 
function loadpage(clicked_id){
 if (clicked_id =="fcluns"){
    $("Table").load("getfcLuns.php?name=<?php $Host=$_GET['name']; echo $Host; ?>");
}
 }
 </script>