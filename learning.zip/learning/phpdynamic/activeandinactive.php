https://stackoverflow.com/questions/21966384/active-and-inactive?rq=1
https://stackoverflow.com/questions/48291909/inactive-and-active-php-mysql?rq=1

<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
	<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dynamic";

// Create connection
$db_handle = mysql_connect($servername, $username, $password);
$db_found = mysql_select_db($dbname, $db_handle);


if ($db_found) {

$SQL = "SELECT * FROM active";
$result = mysql_query($SQL);

while ( $db_field = mysql_fetch_assoc($result) ) {

if($db_field['status'] == 'Active')
{
    echo "<a href='activate.php?status=Inactive' ><img src =  'inactive.jpg' /></a>";
}
else
{
        echo "<a href='activate.php?status=Active' ><img src =  'active.jpg' /></a>";
}
}

mysql_close($db_handle);

}
else {

print "Database NOT Found ";
mysql_close($db_handle);

}

?>
    </body>
</html>