<?php
include "config.php";

$sql="INSERT INTO details(Name, Age, Mail) VALUES ('{$_POST["name"]}','{$_POST["age"]}','{$_POST["mail"]}')";
$con->query($sql);

?>

<!DOCTYPE html>
<html>
	<head>
		<title>php Post method</title>
	</head>
	<body>
		<form id="frm">
			<input type="text" id="name" placeholder="Name">
			<input type="text" id="age" placeholder="age">
			<input type="text" id="mail" placeholder="mail">
			<button type="submit" name="save" id="save" >save </button>
		</form>
		
		
		<script src="assets/jquery.min.js"></script>
		<script>
			$("document").ready(function(){
				// alert("hi");
				$("#save").click(function(){
					var name=$("#name").val();
					var age=$("#age").val();
					var mail=$("#mail").val();
					$.post("post.php",{ name:name,age:age,mail:mail },function(data){
						alert(data);
					$(#frm)[0].reset();
					});
				});
			});
		</script>
		
		
	</body>
</html>
