<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery filter attribute</a>
					</div>
				</div>
			</nav>
		</header>
		
		<form>
			<label>Name </label>
			<input type="text" id="name"> 
			<label>Age </label>
			<input type="text" id="age">
			<label>City </label>
			<input type="text" id="city">
			<button type="button" id="submit"> Save details</button>
		</form>
		<p id="out">--</p>
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#submit").on('click',function(){			
					var na=$("#name").val();
					var ag=$("#age").val();
					var ci=$("#city").val();
				$.post("save.php", //url
				{
					name:na,
					age:ag,
					city:ci
				},
				function(data){
					$("#out").html(data);
					//alert("hi");
				});
			});
		});
		</script>
	</body>
</html>