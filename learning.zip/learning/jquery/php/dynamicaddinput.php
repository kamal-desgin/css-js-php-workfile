<?php
	//print_r($_POST);
	$con=new mysqli("localhost","root","","dynamic");
	$n=count($_POST["course"]);
	if($n>=1)
	{
		for($i=0; $i<$n; $i++)
		{
			if(trim($_POST["course"][$i])!='') //trim used white space remove  //[$i]no values in this course don't save database
			{
			echo $sql="INSERT INTO courses(COURSE) values ('{$_POST["course"][$i]}')";
			 $con->query($sql);
			}
		}
		echo "saved";
	}
	else
	{
		echo "Error: No recourd Found";
	}
?>