<?php
	$con=new mysqli("localhost","root","","dynamic");
	 if(isset($_POST["id"]))
	 {
		foreach($_POST["id"] as $id)
		{
			$sql="DELETE FROM student WHERE stud_id=$id";
			$con->query($sql);
		}
	 }
?>