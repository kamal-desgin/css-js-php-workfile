<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Dynamic add and remove input field in jquery with php and mysql</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
						<h4>Dynamic input field add and remove with Php and mysql </h4> <br>
						<form id="frm">
							<table id="inputfield">
								<tr>
									<td>
										<input type="text" name="course[]" class="form-control" placeholder="Enter your courses" />
									</td>
									<td>
										<button type="button" id="add"  class="btn btn-primary">+ Add More</button>
									</td>
								</tr>
							</table>
								<button type="button" id="submit" class="btn btn-success" >submit</button>
						</form>
						<p> </p>
				</div>
			</div>
		</div>
		
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
		//alert("hi");
			$("#add").click(function(){
				$("#inputfield").append('<tr><td><input type="text" name="course[]" class="form-control" placeholder="Enter your courses" /> </td><td><button type="button" class="del"  class="btn btn-danger"> - Remove</button></td></tr>');
			});
			$(document).on('click','.del',function(){
				$(this).closest("tr").remove();
			});
			
			$("#submit").click(function(){
				$.ajax({
						url:"dynamicaddinput.php",
						type:"post",
						data:$("#frm").serialize(),
						success:function(data) 
						{
							$("p").html(data);
							$("#frm")[0].reset();
						}
				});
			});
			
			
		});
		// dynamicaddinput.php
		</script>
	</body>
</html>