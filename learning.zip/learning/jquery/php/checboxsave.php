<?php
  $con=new mysqli("localhost","root","","dynamic");		
  for($i=0; $i<count($_POST["subject"]); $i++)
  {
	$sql="INSERT INTO subjects(SUBJECT) VALUES ('{$_POST["subject"][$i]}'); ";
	$con->query($sql);
	echo"<p>{$_POST["subject"][$i]} </p>";
  }
?>