<?php
 $result=array();
 $con=new mysqli("localhost","root","","dynamic");
 $sql="select * from reguser WHERE REG='{$_POST["re"]}'";
 
 $res=$con->query($sql);
	if($res->num_rows>0)  //res values to store result array variable
	{
		$result=$res->fetch_assoc();
		$result["ERROR"]=0;
	}
	else
	{
		$result["ERROR"]=1;
	}
	echo json_encode($result);
	?>