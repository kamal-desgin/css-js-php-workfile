<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		
		
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Live search using jquery with php and mysql</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
						<h4>live search using Jquery</h4> <br>
							<form id="frm" autocomplete="off">
								<div class="fom-group col-md-9">
									<input type="text" id="txt" class="form-control" placeholder="search here">
								</div>
								<div class="fom-group col-md-3">
									<button type="submit" class="form-control"><i class="glyphicon glyphicon-search"></i>search </button>
								</div>								
							</form>							
							<div id="box"></div>
				</div>
			</div>
		</div>
		
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#txt").keyup(function(){
				var txt=$("#txt").val();
				if(txt!="")
				{
					$.post("search.php",{s:txt},function(data){  //s index value txt variable value store in s and data arguments pass
						$("#box").html(data);					
					});
				}
			});
		});// search.php
		</script>
	</body>
</html>