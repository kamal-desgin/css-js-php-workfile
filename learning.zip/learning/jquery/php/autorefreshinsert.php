<?php
	$con=new mysqli ("localhost","root","","dynamic");
	echo $sql="INSERT INTO datas(comment,logs) VALUES ('{$_POST["text"]}',now())";
	$con->query($sql);
?>