<?php
	//print_r($_POST);
	$con=new mysqli("localhost","root","","dynamic");	
	$sql="SELECT * FROM reguser WHERE NAME LIKE '{$_POST["s"]}%' ";	//while card search				
	$res=$con->query($sql);	
		echo "<table class='table table-bordered'>
			<tr>
				<th>REGNO</th>
				<th>NAME</th>
				<th>CITY</th>
			</tr>";
			
	if($res->num_rows>0)
	{
		while($row=$res->fetch_assoc())
		{
			echo"
				<tr>
					<td>{$row["REG"]} </td>
					<td>{$row["NAME"]} </td>
					<td>{$row["CITY"]} </td>
				</tr>";
		}
		echo "</table>";
	}
	else
	{
		echo "No Record Found";
	}
?>
	