<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery JSON Parse with Php and mysql</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-md-offset-4 col-sm-4 col-xs-12">
				 <h3>JSON Parse with Php and mysql </h3>
				 <form>
					<div class="well sm-well">
						<fieldset>
							<div class="form-group">
								<label>Register No</label>
								<input type="text" id="reg" name="reg" class="form-control" placeholder="Enter your Register No" />
							</div>
							<div class="form-group">
								<label>Name</label>
								<input type="text" id="name" name="name" class="form-control" placeholder="Your Name" />
							</div>
							<div class="form-group">
								<label>City</label>
								<input type="text" id="city" name="city" class="form-control" placeholder="Your city" />
							</div>
						<p> </p>
						</fieldset>
					</div>
				 </form>
				</div>
			</div>
		</div>
		
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
		//alert("hi");
			$("#reg").keyup(function(){
				  var reg=$(this).val();
				  $.post("getdetails.php",{re:reg},function(data){
					$("p").html(data);
						var res=JSON.parse(data);
						
						if(res.ERROR==1)
						 {
							$("p").html("No Records Found");
							$("#name").val("");
							$("#city").val("");
						 }
						 else if(res.ERROR==0)
						 {
							$("#name").val(res.NAME); // don't use val("res.NAME"); not working
							$("#city").val(res.CITY);
							$("p").html("Record Found");
						 }
				  });
				});
		
		});
		</script>
	</body>
</html>