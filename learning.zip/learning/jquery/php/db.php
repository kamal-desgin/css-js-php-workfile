<?php
	//connection
	$con = new mysqli ("localhost","root","","dynamic");
	echo $sql="INSERT INTO reg(name,email,dob,password,cpassword,phone) VALUES ('{$_POST["name"]}','{$_POST["email"]}','{$_POST["dob"]}','{$_POST["password"]}','{$_POST["cpassword"]}','{$_POST["phone"]}')";
	if($con->query($sql))
	{
		echo "saved";
	}
	else
	{
		echo "Error";
	}
?>