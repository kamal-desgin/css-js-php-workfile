<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		<style>
			input {
				width: 100px;
			}
		</style>
		
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Multiple Input Field Validation using Jquery</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
						<h4>Multiple Input Field Validation using Jquery </h4> <br>
						<?php
							$con=new mysqli("localhost","root","","dynamic");
							$sql="SELECT * FROM reguser";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								echo "<from id='frm'><table class='table-bordered table'>";
									echo "<tr>
												<th>SNO</th>
												<th>REGNO</th>
												<th>NAME</th>
												<th>ID</th>
												<th>Mark-1</th>
												<th>Mark-2</th>
										 </tr>";
										 $i=0;
										 while($row=$res->fetch_assoc())
										{
											$i++;
											echo"
												<tr>
													<td>{$i} </td>
													<td>{$row["REG"]} </td>
													<td>{$row["NAME"]} </td>
													<td><input type='text' readonly disabled name='id[]' value='{$row["ID"]}'></td>
													<td><input type='text' name='m1[]'></td>
													<td><input type='text' name='m2[]'></td>
												</tr>";
										}
										echo "<tr><td colspan='6'>
														<button type='button' id='submit' class='btn btn-success pull-right'>Save Marks</button>
													</td></tr> 
											</table></from>";
							}
							else
							{
								echo "<p>No Record Found</p>";
							}
						?>
						<p> </p>
				</div>
			</div>
		</div>
		
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		
		
		<script type="text/javascript">
		 $(document).ready(function(){		
			$(document).on("click","#submit",function(e){	//e arguments to insert		
				var isValid=true;
				$('input[type="text"]').each(function(){
				if($.trim($(this).val())=='')
					{
						isValid=false;
						$(this).css({
							"border":"1px solid red",
							"background":"#ffcece"
						});
					}
					 else
					{
						$(this).css({
							"border":"",
							"background":""
						});
					} 
				});
				
				 if(isValid==false)
				{
					e.preventDefault();
				}
				else
				{
					$.ajax({
						url: "marksave.php",
						type: "post",
						data: $("#frm").serialize(),
						success:function(data){
							$("p").html(data);
						}
					});
				} 
			});			
		});
		</script>
	</body>
</html> 
<!--report.php, marksave.php -->