<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Multiple Record delete using jquery with php and mysql</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
						<h4>Multiple Record delete </h4> <br>
							<?php
								$con=new mysqli("localhost","root","","dynamic");
								$sql="select * from student";
								$res=$con->query($sql);
								if($res->num_rows>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>* </th>
												<th>SNO </th>
												<th>NAME </th>
												<th>AGE </th>
												<th>CONTACT </th>
												<th>CITY </th>
											</tr>";
											
										$i=0;
										while($row=$res->fetch_assoc())
										{
											$i++;
											echo "<tr id='".$row["stud_id"]."'>
												  <td><input type='checkbox' name='id[]' class='record' value='{$row["stud_id"]}'></rd>
												  <td>{$i}</td>
												  <td>{$row["name"]}</td>
												  <td>{$row["age"]}</td>
												  <td>{$row["contact"]}</td>
												  <td>{$row["city"]}</td>
												</tr>";
										}
										echo "</table> <button type='button' class='btn btn-success' id='del'> Delete Datas</button>";
								}
								else
								{
									echo"No Record Found";
								}
							?>
				</div>
			</div>
		</div>
		
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#del").click(function(){
					if(confirm("Are you sure to delete"))
					{
						var id=[];
						$(':checkbox:checked').each(function(i){
							id[i]=$(this).val();
						});
						
						if(id.length==0)
						{
							alert("Please selct the record to delete");   
						}
						else
						{
							$.ajax({
								url: "delete.php",
								type:"post",
								data:{id:id},
								success:function(data)
								{
									for(var i=0; i<id.lengh; i++)
									{
										$('tr#'+id[i]+'').remove();
									}
								}
							});
						}
					}
					else
					{
						return false;
					}
				});
		});
		// delete.php
		</script>
	</body>
</html>