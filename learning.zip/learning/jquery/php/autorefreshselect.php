<?php
	$con=new mysqli ("localhost","root","","dynamic");
	$sql="select * from datas order by id DESC";
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		while($row=$res->fetch_assoc())
		{
			echo"<p>{$row["comment"]} <b>{$row["logs"]}</b> </p>";
		}
	}
	else
	{
		echo "<p> No Comment Available</p>";
	}
?>