<?php
	$con=new mysqli("localhost","root","","dynamic");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery Select box using</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-md-offset-4 col-sm-4 col-xs-12">
				 <h3>Dependent ListBox </h3>
				 <form>
					<div class="well sm-well">
						<fieldset>
							<div class="form-group">
								<label>Select state</label>
									<select id="state" class="form-control">
										<option value="">Select</option>
										<?php
											$sql="select * from state";
											$res=$con->query($sql);
											while($row=$res->fetch_assoc())
											{
												echo "<option value='{$row["state_id"]}'>{$row["state_name"]}</option>";
											}
										?>										
									</select>
							</div>
							<div class="form-group">
								<label>Select State</label>
								<select id="districts" class="form-control">
									<option value="">Select</option>
								</select>
							</div>	
							
							<button id="sname">State Name</button>
							<button id="sid">State ID</button>
							
						</fieldset>
					</div>
				 </form>
				</div>
			</div>
		</div>
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			//alert("hi");
			$("#state").change(function(){
				cid=$(this).val();  //country value stored cid 
				$.post("state.php",{id:cid},function(data){ // page,index value,function
						$("#districts").html(data);
					});
			});
			
			$("#sid").click(function(){
				alert($("#state").val());
			});
			
			$("#sname").click(function(){
				alert($("#state option:selected").text());
			});
			
		});
		</script>
	</body>
</html>