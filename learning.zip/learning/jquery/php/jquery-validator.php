<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Jquery Form Validate</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
		<div class="row">
		<div class="col-md-6 col-md-offset-3 col-xs-12">
			<div class="well sm-well">
			<h3> Jquery Form Validate Using(jquery validator)</h3> <br>
				<form id="frm" autocomplete="off">
					<div class="form-group">
						<label for="name">Name</label>
						<input type="text" name="name" id="name"  class="form-control" placeholder="your name"  />
					</div>
					<div class="form-group">
						<label for="email">Email</label>
						<input type="email" name="email" id="email" class="form-control" placeholder="your email"  />
					</div>
					<div class="form-group">
						<label for="dob">Date of Birth</label>
						<input type="text" name="dob" id="dob" class="form-control" placeholder="YYYY-MM-DD"  />
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="text" name="password" id="password" class="form-control" placeholder="password"  />
					</div>
					<div class="form-group">
						<label for="cpassword">Confirm Password</label>
						<input type="text" name="cpassword" id="cpassword" class="form-control" placeholder="confirm password"  />
					</div>
					<div class="form-group">
						<label for="phone">Contact No</label>
						<input type="text" name="phone" id="phone" class="form-control" placeholder="phone"  />
					</div>
					
					<div class="form-group">
						<input type="submit" name="submit" id="submit" class="btn btn-success btn-md" value="Register Now" />
					</div>
					
					
				</form>
			</div>
		</div>
		</div>
		</div>
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
			<!-- jquery validate-->
		<script type="text/javascript" src="js/jquery.validate.min.js"></script> 
		
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
		//alert("hi");
			// default validate check function
			$.validator.setDefaults({
				submitHandler: function(){
						//alert("submitted!");
						$.ajax({
							url: "db.php",
							type: "post",
							data:$("#frm").serialize(),
							success:function(data)
							{
								alert(data);
							}
						});
						
						
					}
			});
			
			//form id validate part
			$("#frm").validate({
				rules:{
					name:"required",
					dob:{
						 required:true,	
						 date:true
						},
					email:{
						  required:true,
						  email:true
						},
					password:{
							required:true,
							minlength:5
						},
					cpassword: {
							required:true,
							minlength:5,
							equalTo:"#password"
						},
					phone: {
							required:true,
							digits:true,
							minlength:10,
							maxlength:10
						}
				},
				//form id validate error message showpart
				messages:{
					name: "Please enter your name",
					dob:{
							required:"Please enter Date of birth",
							date:"Please enter correct date format"
						 },
					email:{
							required:"Please enter your email id",
							email:"Please enter the valid email address"
						 },
					password:{
							required:"Please enter your password",
							minlength:"Password length must be 5 char"
						},	
					cpassword:{
							required:"Please enter your confirm password",
							minlength:"Password length must be 5 char",
							equalTo:"Mismatch password"
						},
					phone:{
							required:"Please enter your contact no",
							digits:"Contact no must be numeric",
							minlength:"Length must 10",
							maxlength:"Length must 10"
						}
				}
			});
		});   //autorefresh.php
		</script>
		
		
	</body>
</html>