<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery filter attribute</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
					<h4>Multiple Checkbox select in Jquery</h4> <br>
					<form id="frm">	
						<div class="checkbox-control">
							<p><input type="checkbox" name="subject[]" value="Tamil">Tamil</p>
							<p><input type="checkbox" name="subject[]" value="English">English</p>
							<p><input type="checkbox" name="subject[]" value="Maths">Maths</p>
							<p><input type="checkbox" name="subject[]" value="Science">Science</p>
							<p><input type="checkbox" name="subject[]" value="Socialscience">Socialscience</p>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-primary btn-md"  id="save">Save Details</button>
						</div>
					</form>
					<p id="out"> </p>
				</div>
			</div>
		</div>
		
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#save").click(function(){
				$.ajax({
					url: "checboxsave.php",
					type: "post",
					data:$("#frm").serialize(),
					success:function(data)
					{
						$("#out").html(data);
						$("#frm")[0].reset();
					}
				});
			});
		}); //checboxsave.php
		</script>
	</body>
</html>