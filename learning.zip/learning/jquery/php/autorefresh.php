<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Jquery Form Validate</a>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="container">
		<div class="row">
		<div class="col-md-4 col-md-offset-4 col-xs-12">
			<div class="well sm-well">
			<h3> Jquery Auto refresh</h3><h4>Data base Comment </h4>
				<form id="frm" autocomplete="off">
					<div class="form-group">
						<label for="name">Your Comment</label>
						<textarea type="text" rows="6" name="text" id="text" class="form-control" placeholder="your Comment" required></textarea>
					</div>
					<div class="form-group">
						<input type="submit" name="submit" id="save" class="btn btn-success btn-block" value="send Message" />
					</div>
				</form>
			</div>
		</div>
		<div class="col-md-8 col-md-offset-2 col-xs-12 well">
			<div id="load">
			</div>
		</div>
		</div>
		</div>
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			//alert("hi");		
			
			$("#save").click(function(){
				$.ajax({
					url:"autorefreshinsert.php",
					type:"post",
					data:$("#frm").serialize(),
					success:function(data)
					{
						$("#frm")[0].reset();
						//alert(data);
					}
				});
			});
			
			setInterval(function(){
				$("#load").load("autorefreshselect.php").fadeIn("slow");
			},1000);
		});
		</script>
		
		
	</body>
</html>