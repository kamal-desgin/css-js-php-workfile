<?php
	$con=new mysqli("localhost","root","","dynamic");
	$sql="select * from districts where state_id={$_POST["id"]}";  //country id value selected then show districts id values
	$res=$con->query($sql);
	
	 // output data of each row
	echo "<option value=''>Select</option>";  //must use value('') single quotes
		while($row=$res->fetch_assoc())
		{
			echo "<option value='{$row["districts_id"]}'>{$row["districts_name"]}</option>";
		}
?>

