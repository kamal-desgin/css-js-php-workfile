<!DOCTYPE html>
<html>
	<head>
		<title>table Jquery Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">	
		<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
		<style>
			input {
				width: 100px;
			}
		</style>
		
		</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">Multiple Input Field Validation using Jquery</a>
					</div>
				</div>
			</nav>
		</header>

<div class="container">
			<div class="row">
				<div class="well sm-well col-md-6 col-md-offset-3 col-sm-8 col-xs-12">
				
				<h4 class="text-center">Multiple Input Field Validation and display using Jquery </h4><br>
<?php
	//print_r($_POST);
	$con=new mysqli("localhost","root","","dynamic");
	
	$sql="SELECT  reguser.REG,reguser.NAME,marks.Mark1,marks.Mark2,
					(marks.Mark1+marks.Mark2) as Total FROM reguser inner join marks on reguser.ID=marks.Id";
					
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		echo"<from id='frm'><table class='table table-bordered'>";
		echo"<tr>
				<th>SNO</th>
				<th>REGNO</th>
				<th>NAME</th>
				<th>Mark-1</th>
				<th>Mark-2</th>
				<th>TOTAL</th>
			</tr>";
			$i=0;
			while($row=$res->fetch_assoc())
			{
				$i++;
				echo"
					<tr>
						<td>{$i} </td>
						<td>{$row["REG"]} </td>
						<td>{$row["NAME"]} </td>
						<td>{$row["Mark1"]} </td>
						<td>{$row["Mark2"]} </td>
						<td>{$row["Total"]} </td>
					</tr>";
			}
			echo "</table>";
	}
	else
	{
		echo "No Record Found";
	}
?>
		</div>
	</div>
</div>

<script type="text/javascript" src="js/jquery.min.js"></script>
		<!--<script type="text/javascript" src="js/jquery-3.3.1.slim.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
		//alert("hi");
		
			
		});
		// dynamicaddinput.php
		</script>
	</body>
</html>