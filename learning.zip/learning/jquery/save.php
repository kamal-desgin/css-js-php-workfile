<?php
	$con=new mysqli("localhost","root","","dynamic");
	//print_r($_POST);
	echo $sql="insert into crud(NAME,AGE,CITY) values ('{$_POST["name"]}','{$_POST["age"]}','{$_POST["city"]}')";
	
	if($con->query($sql))
	{
		echo "Data saved";
	}
	else
	{
		echo "Error in saving Data";
	}
?>