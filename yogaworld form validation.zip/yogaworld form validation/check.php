<?php  
//check.php  
$con = mysqli_connect("localhost", "yuvaaday_festiva", "GdpC(7dXp%yT", "yuvaaday_festivel"); 
if(isset($_POST["email_check"]))
{
 $aadhar = mysqli_real_escape_string($con, $_POST["email_check"]);
 $query = "SELECT * FROM ws_yogaseat_reg_2019 WHERE aadhar = '".$aadhar."'";
 $result = mysqli_query($con, $query);
 echo mysqli_num_rows($result);
}
?>
