
<?php
	 //Connection
	 $host = "localhost"; 
	 $user = "yuvaaday_festiva";
	 $pass = "GdpC(7dXp%yT";
	 $db_name = "yuvaaday_festivel";  
	 
	 
	 define("DBPRE","ws"); //DB prefix
	 define("TITLE","YogaWorldFestivel"); //Title	
	 
	 $yogaseat_reg_table = DBPRE."_yogaseat_reg_2019";
	  
	 //Mai Configs
	 $mail_website_url = "http://www.yogaworldfestival.com";
	 //$mail_bg = "url($mail_website_url/assets/images/home01/mail_bg.jpg) no-repeat"; //Image pah or color code
	 $mail_logo = "$mail_website_url/assets/images/home01/logo.png";
	 $mail_phone = "044 - 42809592";
	 $mail_email = "yogaworldfestival@gmail.com";
	 $mail_copyright = "Yoga World Festival";
	 $mail_copyright_url = $mail_website_url; 
	
	//Admin_mail
	//$admin_email="yogaworldfestival@gmail.com";
	$admin_email = "kamal.microshare@gmail.com";  

	//include("wadmin/config.php");
	$con = mysqli_connect($host, $user, $pass, $db_name) or die(mysqli_error());
	

	session_start();

?>



<?php 	
		//print_r($_POST);
	
		if(isset($_POST['register'])){
			$name = $_POST['name'];
			$email = $_POST['email'];
			$phone = $_POST['phone'];
			$aadhar = $_POST['aadhar'];
			$gender = $_POST['gender'];
			$age = $_POST['age'];
			$address = $_POST['address'];
			$message = $_POST['message'];
			$regValue = $_POST['regValue'];
			
			$created_at = date('Y-m-d g:i:s');
			$status = "A";
			
			//connection
			include "config.php";
			$con = mysqli_connect($host, $user, $pass, $db_name) or die(mysqli_error());
						
			//insert query
			$participant_query = "INSERT INTO `$yogaseat_reg_table` (`seat`,`name`, `email`, `mobile`, `aadhar`, `gender`, `age`, `address`, `message`, `created_at`, `status`) VALUES 
																	('$regValue', '$name', '$email', '$phone', '$aadhar', '$gender', '$age', '$address', '$message', '$created_at', '$status' )";
			
			$participant_res = $con->query($participant_query) or die(mysqli_error($con));
			$last_id = $con->insert_id;			
			$reg_id = "SET-".$last_id;
			
			$update_qry = "update $yogaseat_reg_table set reg_id='$reg_id' where id='$last_id' ";
			$con->query($update_qry) or die(mysqli_error($con));
			
			//$admin_email="poovizhi.microshare@gmail.com";
			
			//Mail
			$mail_h4 = "Volunteer";
			$mail_h1 = "Registration";
			$mail_main_msg = "<center><table width='50%' cellpadding='5'>
								<tr><th>Registration ID</th><th> : </th><td>$reg_id</td></tr>
								<tr><th>Seat No</th><th> : </th><td>$regValue</td></tr>
								<tr><th>Name</th><th> : </th><td>$name</td></tr>
								<tr><th>Email Address</th><th> : </th><td>$email</td></tr>
								<tr><th>Mobile Number</th><th> : </th><td>$phone</td></tr>
								<tr><th>Aadhar No</th><th> : </th><td>$aadhar</td></tr>								
								<tr><th>Address</th><th> : </th><td>$address</td></tr>
								<tr><th>Age</th><th> : </th><td>$age</td></tr>
								<tr><th>Gender </th><th> : </th><td>$gender</td></tr>
								<tr><th>Message</th><th> : </th><td>$message</td></tr>									
							  </table></center>";
			$mail_button = "Visit Now";
			$mail_button_url = $mail_website_url;

			$from_mail = "yogaworldfestival@gmail.com";
			$from_name = "Registration - Volunteer Registration";

			$to_mail = $admin_email.",".$volunteer_email;
			$subject = "Registration | Volunteer Registration";

			//Headers
			$headers .= "Reply-To: The Sender <$from_mail>\r\n";
			$headers .= "Return-Path: $from_name <$from_mail>\r\n";
			$headers .= "From: $from_name <$from_mail>\r\n";

			$headers .= "Organization: Sender Organization\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= "X-Priority: 3\r\n";
			$headers .= "X-Mailer: PHP". phpversion() ."\r\n";

			$htmlcontent = '<div style="background:'.$mail_bg.';width:100%;padding:50px 0;">
			<table style="font-family:Arial,Helvetica,sans-serif;color:#222;font-size:13px;width:80%;margin:0 auto;background:#fff;" cellpadding="12">
				<tr>
					<td colspan="2" style="width:200px;"><img src="'.$mail_logo.'" width="150"></td>
					<td colspan="3" style="text-align:right;line-height:1.7"><b>Contact:</b> '.$mail_phone.' <br><b>Email:</b> '.$mail_email.'</td>
				</tr>
				<tr>
					<td colspan="5" style="background:#11D388;padding:15px 0;text-align:center;color:#fff;">
						<h4>'.$mail_h4.'</h4>
						<h1>'.$mail_h1.'</h1>
					</td>
				</tr>
				<tr>
					<td colspan="5">
						'.$mail_main_msg.'
						<a href="'.$mail_button_url.'" style="background:#243F4F;color:#fff;padding:15px 20px;text-decoration:none;font-weight:bold;margin:0 auto;display:table;border-radius:7px;">'.$mail_button.'</a>
					</td>
				</tr>
				<tr>
					<td colspan="5" style="background:#11D388;padding:20px 0;">
						<p style="font-size:12px;color:#fff;text-align:center;padding:0 30px;">This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message.</p>
						<p style="font-size:12px;color:#fff;text-align:center;">Copyright &copy; 2017 <a href="'.$mail_copyright_url.'" style="text-decoration:none;font-weight:bold;color:#fff;">'.$mail_copyright.'</a></p>
					</td>
				</tr>
			</table>
			</div>';
			
			// Send email
			$mail_sent = mail($to_mail, $subject, $htmlcontent, $headers);
			
			if($mail_sent === true)
			{
				echo "<script>alert('Registration successful');</script>";
			}
		}
		
	?>