<?php
	//On page 1
	if (!isset($_SESSION)) { session_start(); }
	//$_SESSION['payamount'] = $sel_payment;
	//$_SESSION['seat'] = $regValue;
?>
		
<!DOCTYPE html>
<html>
	<head>
		<title>Yogaworld Festival Seat Booking</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">		

		<!--- Script START --->		
		<script type="text/javascript">
			$(window).on('load',function(){
				$('#myModal').modal('show');
			});	
			$(document).ready(function(){
				//alert("hi");
				
				//checkbox validation
				$('#submit').click(function() {
					checked = $("input[type=checkbox]:checked").length;
					if(!checked) {
						alert("You must Select SEAT First then Continue.");
						return false;
					}
				});				
				//only one checkbox select
				 $('.seatcheck').click(function() {
					$(this).siblings('input:checkbox').prop('checked', false);
				}); 		
			});
		</script>
		
		<!-- Check Box Count -->        
		 <script language="Javascript" type="text/javascript">
			$(document).ready(function(){
				$(function() {
					$('#general i .counter').text(' ');					
					var generallen = $("#keyboard input[name='seat[]']:checked").length;
					if(generallen>0){$("#general i .counter").text('('+generallen+')');}else{$("#general i .counter").text(' ');}
				})
				function updateCounter() {
					var len = $("#keyboard input[name='seat[]']:checked").length;
					if(len>0){$("#general i .counter").text('('+len+')');}else{$("#general i .counter").text(' ');}
				}
					$("#keyboard input:checkbox").on("change", function() {
					updateCounter();
				});
			});		
		</script>
		
		<style>
			@import url('https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap');
/* desktop */
	label {
		display: table-column;
		max-width: 100%;
		margin-bottom: 5px;
		font-weight: 700;
		font-size: .6em;
	}

	input[type=checkbox] {
				display:none;
	}
	 input[type=checkbox] + label
		{
		background: url("http://yogaworldfestival.com/assets/images/checkbox/available.png") no-repeat;
		background-size: 100%;
		height: 43px;
		width: 43px;
		display:inline-block;
		margin: 1px;
		}
	 input[type=checkbox]:checked + label
		{
		background: url("http://yogaworldfestival.com/assets/images/checkbox/selected.png") no-repeat;
		background-size: 100%;
		height: 43px;
		width: 43px;
		display:inline-block;
		padding: 0 0 0 0px;
		margin: 1px;
		}
	#keyboard {
		display: block;
		border: 1px solid #820f0f2e;
		border-radius: 4px;
		width: 100%;
		height: auto;
		padding: 16px;
		background-color: #f7f7f7;
	}
	.gray-bg {
		background-color: #f9f9f9;
		margin: 5px;
		border: 1px solid #e8e8e8;
	}
	
	

/* laptop */
@media (min-width: 1025px) and (max-width: 1280px) {
 input[type=checkbox] {
	 display:none;
	} 
  
 input[type=checkbox] + label:nth-child(2) {	
	transform: rotate(358deg) translate(90px) rotate(3deg);
    background: url(checkbox/guru.png);
    background-size: cover;
    width: 50px;
    height: 60px;
}
  
}

/* Mobile */
@media (max-width: 767px) {
 input[type=checkbox] {
				display:none;
	}
 input[type=checkbox] + label
	{
	background: url("http://yogaworldfestival.com/assets/images/checkbox/student_available.png") no-repeat;
	background-size: 100%;
    height: 40px;
    width: 20px;
	display:inline-block;
	padding: 0 0 0 0px;
	}
 input[type=checkbox]:checked + label
	{
	background: url("http://yogaworldfestival.com/assets/images/checkbox/student_selected.png") no-repeat;
	background-size: 100%;
    height: 40px;
    width: 20px;
	display:inline-block;
	padding: 0 0 0 0px;
}	
	#keyboard {
		display: block;
		margin: 0 auto;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		width: 300px;
		height: 350px;
		border: 1px solid #820f0f2e;
		border-radius: 10px;		
		padding-left: 0;
		background-color: #ffffec;
	}
}

/* input placeholder validation */
	input:not(:placeholder-shown), textarea:not(:placeholder-shown) {
		border-color: hsl(0, 76%, 50%);;
	}
	input:valid, textarea:valid {
		border-color: hsl(120, 76%, 50%);
	}
/* input placeholder validation */
		
.modal-header {
	background-color: #f51941;
	color: #fff;
}
.modal-footer {
    padding: 15px;
    text-align: right;
    border-top: 1px solid #e5e5e5;
    background-color: #e0e0e0;
}
.modal-header .close {
	margin-top: -2px;
	color: #ffffff;
	width: 26px;
	height: 26px;
	opacity: 1;
}			
#modal-body {
	max-height: calc(100vh - 175px);
	overflow-y: auto;
	font-family: 'Poppins', sans-serif;
}
@media (min-width: 1200px){
	.modal-xl {
		width: 97%;
	}
}

		</style>
		
		
	</head>
	<body>
		<header>
			<nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">		
					<div class="navbar-header">
						<a class="navbar-brand">jquery Select box using</a>
					</div>
				</div>
			</nav>
		</header>
		<form method="get" action="seatbooking.php">
		<!-- Modal START-->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog modal-lg modal-xl" role="document">
				<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h3 class="modal-title" id="myModalLabel">Yogaworld Festival Book your Seats </h3>
						  </div>
						  
						  <div class="modal-body" id="modal-body">
							<div class="row"><!--row start-->
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">				 
									<div id="keyboard">
									
									<?php
										
											//Seat Booking Form Start
												$i=0;
												while($i < 1000) {
												$i++;
													echo "<input type='checkbox' class='seatcheck' name='seat' value='seat-{$i}'  title=\"Seat No:{$i}\"  id='seet{$i}' /><label for='seet{$i}'>{$i}</label> ";
												}
										   
										?>
									</div>
								</div>
							</div> <!--row end-->
						  </div>
						  <div class="modal-footer">
							<div class="row">
								<div class="col-md-4 col-sm-4 col-xs-12">
									<ul class="text-left list-inline">
										<li><img src="http://yogaworldfestival.com/assets/images/checkbox/student_available.png" width="25" > <strong>Available</strong> </li>
										<li><img src="http://yogaworldfestival.com/assets/images/checkbox/student_selected.png" width="25" > <strong>Selected</strong> </li>
										<li><img src="http://yogaworldfestival.com/assets/images/checkbox/student_booked.png" width="25" > <strong>Booked</strong> </li>
									</ul>
								</div>
								<div class="col-md-2 col-sm-2 col-xs-12">
									<div class="text-center" id="cart_price">
										<!--<h6>2 Slots selected</h6>
										<h4>Rs.500</h4>-->
									</div>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-12 text-center"> 
									<button type="submit" id="submit" class="btn btn-success">Book Now</button>
									<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
								</div>
							</div>
						  </div>
					</div>
			  </div>
			</div> <!-- Modal EMD-->
		</form> <!-- Form END-->


</body>
</html>