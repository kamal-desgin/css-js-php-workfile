	<?php
	 // include "header.php";
	 
	 //Connection
	 $host = "localhost"; 
	 $user = "root";
	 $pass = "";
	 $db_name = "dynamic";
	 define("DBPRE","ws"); //DB prefix
	 define("TITLE","YogaWorldFestivel"); //Title	
	 
	 $yogaseat_reg_table = DBPRE."_yogaseat_reg_2019";
	  
	 //Mai Configs
	 $mail_website_url = "http://www.yogaworldfestival.com";
	 //$mail_bg = "url($mail_website_url/assets/images/home01/mail_bg.jpg) no-repeat"; //Image pah or color code
	 $mail_logo = "$mail_website_url/assets/images/home01/logo.png";
	 $mail_phone = "044 - 42809592";
	 $mail_email = "yogaworldfestival@gmail.com";
	 $mail_copyright = "Yoga World Festival";
	 $mail_copyright_url = $mail_website_url; 
	
	//Admin_mail
	//$admin_email="yogaworldfestival@gmail.com";
	$admin_email = "kamal.microshare@gmail.com";  

	//include("wadmin/config.php");
	$con = mysqli_connect($host, $user, $pass, $db_name) or die(mysqli_error());
?>