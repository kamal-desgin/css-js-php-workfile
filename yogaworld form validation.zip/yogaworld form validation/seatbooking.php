<?php
	 //Connection
	 $host = "localhost"; 
	 $user = "yuvaaday_festiva";
	 $pass = "GdpC(7dXp%yT";
	 $db_name = "yuvaaday_festivel";  
	 
	 
	 define("DBPRE","ws"); //DB prefix
	 define("TITLE","YogaWorldFestivel"); //Title	
	 
	 $yogaseat_reg_table = DBPRE."_yogaseat_reg_2019";
	  
	 //Mai Configs
	 $mail_website_url = "http://www.yogaworldfestival.com";
	 //$mail_bg = "url($mail_website_url/assets/images/home01/mail_bg.jpg) no-repeat"; //Image pah or color code
	 $mail_logo = "$mail_website_url/assets/images/home01/logo.png";
	 $mail_phone = "044 - 42809592";
	 $mail_email = "yogaworldfestival@gmail.com";
	 $mail_copyright = "Yoga World Festival";
	 $mail_copyright_url = $mail_website_url; 
	
	//Admin_mail
	//$admin_email="yogaworldfestival@gmail.com";
	$admin_email = "kamal.microshare@gmail.com";  

	//include("wadmin/config.php");
	#$con = mysqli_connect($host, $user, $pass, $db_name) or die(mysqli_error());
	
	//On page 2
	session_start();
	$regValue = $_GET['seat'];
?>

			
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <!-- jquery Validator--->
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/additional-methods.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/additional-methods.min.js"></script>
  
  <style>
	  body {
		  margin: 0;
		  padding:0;
		  background:#f9f9f9;
	  }
		.checkform {    
			 position: relative;
			 width:100%;
			 height:100%;
		}
		.title h3 {
			font-size: 24px;
			font-family: none;
			font-weight: 700;
			color: #007cea;
			text-align:center;
		}		
		.right_text { 
			padding:35px;
			width:100%;
			height: auto;
			background: #fff;
			border-radius:6px;
			box-shadow: 2px 2px 2px #ddd;
		}
		.error {
			    color: red;
				font-size: 12px;
				font-weight: normal;
				text-transform: capitalize;
		}
	@media (max-width: 767px) {
		
	}
  </style>
  
		<script>
			//Aadhar No Already used or not check
			$(document).ready(function(){  
			   $('#aadhar').blur(function(){

				 var aadhar = $(this).val();

				 $.ajax({
				  url:'check.php',
				  method:"POST",
				  data:{email_check:aadhar},
				  success:function(data)
				  {
				   if(data != '0')
					   {
						$('#availability').html('<span class="text-danger">User Aadhar Card No not available</span>');
						$('#register').attr("disabled", true);
					   }
				   else			   
					   {
						$('#availability').html('<span class="text-success">User Aadhar Card No Available</span>');
						$('#register').attr("disabled", false);
					   }
				  }
				 });
			  });
		   });  
		</script>
		<script type="text/javascript">
		$(document).ready(function(){
		//alert("hi");
			// default validate check function
			$.validator.setDefaults({
				submitHandler: function(){
						//alert("submitted!");
						$.ajax({
							url: "seatbook.php",
							type: "post",
							data:$("#seatreg").serialize(),
							success:function(data)
							{
								alert("You will now be redirected.");
								window.location.href = "http://www.yogaworldfestival.com/";

							}
						});
					}
			});
			
			//form id validate part
			$("#seatreg").validate({
				rules:{
					name: {
						required:true
					},
					email:{
						  required:true,
						  email:true
					},
					phone: {
						required:true,
						digits:true,
						minlength:12,
						maxlength:12
					},
					aadhar: {
						required:true,
						digits:true,
						minlength:12,
						maxlength:12
					},
					gender: {
						required:true
					},				
					age: {
						required:true,
						digits:true
					},
					address: {
						required:true
					},
					message: {
						required:true
					}
					
				},
				//form id validate error message showpart
				messages:{
					name: "Please enter your name",
					email:{
							required:"Please enter your email id",
							email:"Please enter the valid email address"
						 },
					phone:{
						required:"country code with contact no",
						digits:"Contact no must be numeric",
						minlength:"Length must 12",
						maxlength:"Length must 12"
					},
				    aadhar:{
						required:"Aadhar Card No only",
						digits:"Aadhar Card no must be numeric",
						minlength:"Length must 12",
						maxlength:"Length must 12"
					},
				    gender:{
							required:"Please select gender"
						 },
					age:{
							required:"Please enter your age",
							digits:"Age must be digits"
						},	
					address:{
							required:"fill your address here"
						},
					message:{
							required:"Please enter your message"
						}
					
				}
			});
		});   //autorefresh.php
		</script>

  
</head>
<body>
	<div class="container">
		<div class="row"> 
		<div class="col-md-offset-1 col-md-10 col-sm-10 col-xs-12">
			<div class="checkform right_text">			
					<div class="title">
						<h3>Yoga World Festival Seat Booking-2019 </h3>
					</div>
					 <form id="seatreg" method="post" action="">					 
						<div class="col-md-6 col-sm-6 col-xs-12">
							 <fieldset>
								<div class="form-group hidden">
									<input type="text" name="regValue" value="<?php echo $regValue; ?>" class="form-control"/>
								</div>
								<div class="form-group">
									<label>Name</label>
									<input type="text" name="name" id="name" class="form-control" placeholder="your name" required >
								</div>
								<div class="form-group">
									<label>Email</label>
									<input type="text" name="email" id="email" class="form-control" placeholder="your email" required >
								</div>
								<div class="form-group">
									<label>Contact No with country code</label>
									<input type="text" name="phone" id="phone" class="form-control" placeholder="918056138661" required >
								</div>
								<div class="form-group">
									<label>Aadhar Card No</label>
									<input type="text" name="aadhar" id="aadhar" class="form-control" placeholder="123412341234" required >
									<span id="availability"></span> <!-- Email Available check-->
								</div>
								<div class="form-group">
									<label>Gender</label> <br>
										<label class="radio-inline"><input type="radio" name="gender" id="gender" value="Male"> Male </label>
										<label class="radio-inline"> <input type="radio" name="gender" id="gender" value="Female"> Female </label>
										<label class="radio-inline"> <input type="radio" name="gender" id="gender" value="Other"> Other </label>
								</div>
							 </fieldset>
						 </div>
						 <div class="col-md-6 col-sm-6 col-xs-12">
							  <fieldset>
								
								<div class="form-group">
									<label>Age</label>
									<input type="text" name="age" class="form-control" placeholder="your Aadhar No" required >
								</div>
								<div class="form-group">
									<label>Address</label>
									<textarea type="text" rows="4" cols="250" name="address" class="form-control" placeholder="your address here" required></textarea>
								</div>
								<div class="form-group">
									<label>Message</label>
									<textarea type="text" rows="4" cols="250" name="message" class="form-control" placeholder="your message here" required></textarea>
								</div>
							 </fieldset>
						 </div>
						<div class="row text-center">
							<button type="submit" id="register" name="register" class="btn btn-success btn-lg">Submit Now</button>
						</div>
					</form>
				</div>
			</div>
		</div>
			
	
	  </div>
	</div>
</body>
</html>

<?php
	// remove all session variables
	session_unset(); 
	// destroy the session 
	session_destroy(); 
?>